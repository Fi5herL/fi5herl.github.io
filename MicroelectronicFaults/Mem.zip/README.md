# 記憶體故障模擬器 - 優化版

## 簡介

這是一個改進版的記憶體故障模擬器，專門設計用於教育和研究目的，可以模擬各種記憶體故障並測試不同的記憶體測試演算法。

## 主要改進

### 🏗️ 架構優化
- **模組化設計**: 將程式碼分為多個模組，提高可維護性
- **清晰的分離**: HTML、CSS、JavaScript 完全分離
- **錯誤處理**: 完整的錯誤處理機制

### 🔧 演算法修正
- **Checkerboard Pattern**: 修正為真正的棋盤模式
- **March C-/C**: 修正背景模式和測試序列
- **Galpat**: 完善的互動測試實現
- **Walking Pattern**: 改進的位元和字元測試

### 🎯 模擬精度
- **新增故障類型**: 支援 Transition Faults (0→1, 1→0)
- **改進 Bridging 模擬**: 更真實的 wired-AND 行為
- **MSB-first 顯示**: 符合常見的位元顯示習慣
- **轉換歷史追蹤**: 支援 transition fault 的準確檢測

### 🖥️ 使用者體驗
- **響應式設計**: 支援不同螢幕尺寸
- **鍵盤快捷鍵**: 提高操作效率
- **匯出功能**: 支援日誌和結果匯出
- **演算法說明**: 內建演算法說明系統

## 檔案結構

```
memory-fault-simulator/
├── memory-fault-simulator-optimized.html  # 主要 HTML 檔案
├── styles.css                            # 樣式檔案
├── js/
│   ├── memory-model.js                   # 記憶體模型
│   ├── algorithms.js                     # 演算法庫
│   ├── ui-controller.js                  # UI 控制器
│   └── simulator.js                      # 主控制器
├── README.md                             # 說明文件
└── 參數化記憶體故障模擬器 (修正版).html   # 原始檔案
```

## 使用說明

### 基本操作

1. **設定記憶體大小**
   - 位址數量: 2-64
   - 資料寬度: 2-16 位元
   - 點擊「設定記憶體大小」套用

2. **注入故障**
   - 選擇故障類型 (SA0, SA1, BF_InIn, BF_OutIn, BF_OutOut, TF_0to1, TF_1to0)
   - 輸入故障位置
   - 點擊「注入故障」

3. **選擇演算法**
   - 從下拉選單選擇預設演算法
   - 或建立自訂演算法
   - 設定測試範圍 (可選)

4. **執行測試**
   - 自動執行: 連續執行所有步驟
   - 單步模式: 逐步執行，可詳細觀察每個步驟

### 故障類型說明

- **SA0/SA1**: Stuck-at 故障，位元固定為 0 或 1
- **BF_InIn**: 輸入-輸入橋接故障，兩個輸入連接
- **BF_OutIn**: 輸出-輸入橋接故障，一個輸出控制另一個輸入
- **BF_OutOut**: 輸出-輸出橋接故障，兩個輸出相連 (wired-AND)
- **TF_0to1**: 0→1 轉換故障，無法從 0 變為 1
- **TF_1to0**: 1→0 轉換故障，無法從 1 變為 0

### 演算法說明

#### 基本演算法
- **Write/Read 0x00**: 寫入/讀取全 0 模式
- **Write/Read 0xFF**: 寫入/讀取全 1 模式
- **Write/Read 0x55**: 寫入/讀取 0101 模式
- **Write/Read 0xAA**: 寫入/讀取 1010 模式

#### March 演算法
- **March C-**: 10n 複雜度，檢測 stuck-at、transition、coupling 故障
- **March C**: 10n 複雜度，與 March C- 類似但測試序列稍有不同

#### 模式演算法
- **Checkerboard**: 棋盤模式，檢測位址解碼器故障
- **Walking Pattern**: 行走模式，逐一測試每個位置
- **Galloping Pattern**: 奔騰模式，互動測試，複雜度高但檢測能力強

### 鍵盤快捷鍵

- **Ctrl+Enter**: 開始自動執行
- **Ctrl+Space**: 開始單步模式
- **Ctrl+R**: 重設記憶體

## 技術特點

### 記憶體模型
- 支援任意大小的記憶體配置
- 精確的故障模擬
- 物理和邏輯視圖分離

### 演算法引擎
- 使用 JavaScript Generator 實現步進執行
- 支援自訂演算法編寫
- 完整的 API 介面

### 視覺化
- 雙記憶體視圖 (物理儲存 vs 有效讀取)
- 故障高亮顯示
- 時間軸回放功能

## 開發者資訊

### 擴充演算法

```javascript
// 自訂演算法範例
log('開始執行自訂演算法');

// 可用參數
// startAddr, endAddr: 位址範圍
// startBit, endBit: 位元範圍

// 可用 API
// mem.write(addr, value): 寫入記憶體
// mem.readAndCheck(addr, expectedValue): 讀取並檢查
// mem.size(): 記憶體大小
// mem.allOnes(): 全 1 值
// mem.dataWidth(): 資料寬度

for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.write(i, 0);
    yield* mem.readAndCheck(i, 0);
}

log('自訂演算法執行完成');
```

### 故障注入 API

```javascript
// 注入 stuck-at 故障
simulator.injectFault({
    type: 'SA0',
    addr1: 0,
    bit1: 0
});

// 注入 bridging 故障
simulator.injectFault({
    type: 'BF_OutOut',
    addr1: 0, bit1: 0,
    addr2: 1, bit2: 0
});
```

## 版本歷史

### v2.0 (優化版)
- 完全重構的模組化架構
- 修正所有演算法實現
- 新增 transition fault 支援
- 改進 UI/UX 設計
- 添加匯出功能

### v1.0 (原始版)
- 基本的記憶體故障模擬功能
- 支援 stuck-at 和 bridging fault
- 基本的演算法庫

## 授權

本專案採用 MIT 授權條款。

## 貢獻

歡迎提交問題報告和功能請求。如需貢獻程式碼，請遵循以下準則：

1. 保持模組化設計
2. 添加適當的錯誤處理
3. 更新相關文件
4. 確保向後相容性

## 聯絡資訊

如有問題或建議，請聯絡開發團隊。