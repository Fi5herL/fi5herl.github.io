/**
 * 實用版記憶體故障模擬器
 */

class ScrollableMemorySimulator {
    constructor() {
        this.memory = null;
        this.algorithms = new MemoryAlgorithms();
        this.ui = null;
        this.executionEngine = null;
        this.executionHistory = [];
        this.currentStep = 0;
        this.isRunning = false;
        this.isPaused = false;
        this.executionDelay = 200;
        this.maxDataWidth = 32; // 支援最大32位元
    }

    /**
     * 初始化模擬器
     */
    init() {
        this.ui = new ScrollableUIController(this);
        this.executionEngine = new SimpleExecutionEngine(this);
        
        // 創建預設記憶體
        this.setMemorySize(8, 8);
        
        // 載入演算法
        this.ui.updateAlgorithmSelect();
        this.ui.loadSelectedAlgorithm();
        
        // 更新顯示
        this.ui.updateAllDisplays();
        
        console.log('實用版記憶體故障模擬器已初始化');
    }

    /**
     * 設定記憶體大小
     */
    setMemorySize(addressCount, dataWidth) {
        if (this.isRunning) {
            throw new Error('執行中無法變更記憶體大小');
        }

        // 檢查資料寬度限制
        if (dataWidth > this.maxDataWidth) {
            throw new Error(`資料寬度不能超過 ${this.maxDataWidth} 位元`);
        }

        this.memory = new EnhancedMemoryModel(addressCount, dataWidth);
        this.resetExecution();
        this.ui.log('系統', `記憶體大小設定為 ${addressCount} 位址 × ${dataWidth} 位元`);
    }

    /**
     * 設定位址映射
     */
    setAddressMapping(mapping, description) {
        if (this.isRunning) {
            throw new Error('執行中無法變更映射');
        }

        this.memory.setAddressMapping(mapping, description);
        this.ui.log('系統', `記憶體映射已更新: ${description}`);
    }

    /**
     * 注入故障
     */
    injectFault(faultInfo) {
        if (this.isRunning) {
            throw new Error('執行中無法注入故障');
        }

        return this.memory.injectFault(faultInfo);
    }

    /**
     * 清除故障
     */
    clearFaults() {
        if (this.isRunning) {
            throw new Error('執行中無法清除故障');
        }

        this.memory.clearFaults();
    }

    /**
     * 自動執行
     */
    runAuto() {
        if (this.isRunning) {
            throw new Error('已在執行中');
        }

        this.prepareExecution();
        this.isRunning = true;
        this.isPaused = false;
        
        this.ui.updateControlButtons();
        this.ui.log('系統', '開始自動執行');
        this.autoExecutionLoop();
    }

    /**
     * 單步執行
     */
    runStep() {
        if (this.isRunning) {
            throw new Error('已在執行中');
        }

        this.prepareExecution();
        this.isRunning = true;
        this.isPaused = true;
        
        this.ui.updateControlButtons();
        this.ui.log('系統', '進入單步執行模式');
    }

    /**
     * 執行下一步
     */
    nextStep() {
        if (!this.isPaused) {
            throw new Error('不在單步模式中');
        }

        return this.executionEngine.executeNextStep();
    }

    /**
     * 停止執行
     */
    stop() {
        if (this.isRunning) {
            this.isRunning = false;
            this.isPaused = false;
            this.ui.updateControlButtons();
            this.ui.log('系統', '執行已停止');
        }
    }

    /**
     * 重置
     */
    reset() {
        this.stop();
        this.resetExecution();
        this.ui.log('系統', '模擬器已重置');
        this.ui.updateAllDisplays();
    }

    /**
     * 跳轉到指定步驟
     */
    goToStep(step) {
        if (this.isRunning && !this.isPaused) {
            throw new Error('自動執行中無法跳轉');
        }

        if (step < 0 || step >= this.executionHistory.length) {
            throw new Error('無效的步驟編號');
        }

        this.currentStep = step;
        this.restoreState(step);
        this.ui.updateTimelineDisplay();
        this.ui.updateAllDisplays();
    }

    /**
     * 準備執行
     */
    prepareExecution() {
        if (!this.memory) {
            throw new Error('請先設定記憶體大小');
        }

        const algorithmName = this.ui.getSelectedAlgorithm();
        const algorithmCode = this.algorithms.getAlgorithm(algorithmName);
        
        if (!algorithmCode.trim()) {
            throw new Error('請選擇演算法');
        }

        // 獲取測試範圍
        const range = this.getTestRange();
        
        // 重置執行狀態
        this.resetExecution();
        
        // 準備執行引擎
        this.executionEngine.prepare(algorithmCode, range);
        
        // 設定執行延遲
        this.executionDelay = parseInt(this.ui.getExecutionDelay()) || 200;
        
        this.ui.log('系統', `準備執行演算法: ${algorithmName}`);
        this.ui.log('系統', `測試範圍: 邏輯位址 ${range.startAddr}-${range.endAddr}`);
        
        // 顯示映射資訊
        const mappingInfo = this.memory.getMappingInfo();
        this.ui.log('系統', `當前映射: ${mappingInfo.description}`);
    }

    /**
     * 獲取測試範圍
     */
    getTestRange() {
        const rangeMode = this.ui.getRangeMode();
        let startAddr = 0, endAddr = this.memory.addressCount - 1;

        if (rangeMode === 'range') {
            const range = this.ui.getAddressRange();
            if (range.start !== null && range.end !== null) {
                startAddr = Math.max(0, Math.min(range.start, this.memory.addressCount - 1));
                endAddr = Math.max(startAddr, Math.min(range.end, this.memory.addressCount - 1));
            }
        }

        return { startAddr, endAddr };
    }

    /**
     * 自動執行循環
     */
    autoExecutionLoop() {
        if (!this.isRunning || this.isPaused) return;

        const result = this.executionEngine.executeNextStep();
        
        if (result.done) {
            this.finishExecution();
        } else {
            setTimeout(() => this.autoExecutionLoop(), this.executionDelay);
        }
    }

    /**
     * 完成執行
     */
    finishExecution() {
        this.isRunning = false;
        this.isPaused = false;
        
        this.ui.updateControlButtons();
        this.ui.log('系統', '演算法執行完成');
        this.analyzeResults();
        this.ui.updateAllDisplays();
    }

    /**
     * 分析結果
     */
    analyzeResults() {
        const stats = this.memory.getFaultStatistics();
        const details = this.memory.getFaultDetails();
        
        this.ui.log('系統', `故障檢測完成 - 覆蓋率: ${stats.coverage}%`);
        
        if (stats.total > 0) {
            this.ui.log('分析', `總故障: ${stats.total}, 已檢測: ${stats.detected}, 未檢測: ${stats.undetected}`);
            
            // 記錄未檢測的故障
            const undetectedFaults = details.filter(f => !f.detected);
            if (undetectedFaults.length > 0) {
                this.ui.log('警告', `未檢測故障: ${undetectedFaults.map(f => f.id).join(', ')}`);
            }
        }
        
        // 更新結果顯示
        this.ui.updateResultsDisplay(stats, details);
    }

    /**
     * 重置執行狀態
     */
    resetExecution() {
        this.isRunning = false;
        this.isPaused = false;
        this.currentStep = 0;
        this.executionHistory = [];
        
        if (this.memory) {
            this.memory.reset();
            this.saveState();
        }
        
        this.ui.updateControlButtons();
        this.ui.updateTimelineDisplay();
    }

    /**
     * 保存當前狀態
     */
    saveState() {
        const state = {
            step: this.currentStep,
            memoryState: this.memory ? [...this.memory.cells] : [],
            activeLogicalAddress: this.executionEngine ? this.executionEngine.activeLogicalAddress : null,
            timestamp: Date.now()
        };
        
        this.executionHistory.push(state);
        this.ui.updateTimelineDisplay();
    }

    /**
     * 恢復狀態
     */
    restoreState(step) {
        if (step >= this.executionHistory.length) return;
        
        const state = this.executionHistory[step];
        
        if (this.memory && state.memoryState) {
            this.memory.cells = [...state.memoryState];
        }
        
        if (this.executionEngine) {
            this.executionEngine.activeLogicalAddress = state.activeLogicalAddress;
        }
        
        this.currentStep = step;
    }

    /**
     * 獲取當前活動邏輯位址
     */
    getCurrentActiveLogicalAddress() {
        return this.executionEngine ? this.executionEngine.activeLogicalAddress : null;
    }

    /**
     * 匯出狀態
     */
    exportState() {
        return {
            memory: this.memory ? this.memory.exportState() : null,
            executionHistory: this.executionHistory,
            currentStep: this.currentStep,
            simulatorVersion: '2.0-scrollable',
            timestamp: new Date().toISOString()
        };
    }

    /**
     * 匯入狀態
     */
    importState(stateData) {
        if (this.isRunning) {
            throw new Error('執行中無法匯入狀態');
        }

        try {
            if (stateData.memory) {
                this.setMemorySize(stateData.memory.addressCount, stateData.memory.dataWidth);
                this.memory.cells = [...stateData.memory.cells];
                
                if (stateData.memory.mapping) {
                    this.setAddressMapping(stateData.memory.mapping.mapping, stateData.memory.mapping.description);
                }
                
                stateData.memory.faults.forEach(fault => {
                    this.memory.faults.push({...fault});
                });
            }
            
            if (stateData.executionHistory) {
                this.executionHistory = stateData.executionHistory;
                this.currentStep = stateData.currentStep || 0;
            }
            
            this.ui.updateAllDisplays();
            this.ui.log('系統', '狀態匯入成功');
            
        } catch (error) {
            throw new Error(`狀態匯入失敗: ${error.message}`);
        }
    }
}

/**
 * 簡化版執行引擎
 */
class SimpleExecutionEngine {
    constructor(simulator) {
        this.simulator = simulator;
        this.generator = null;
        this.activeLogicalAddress = null;
        this.memoryAPI = null;
    }

    /**
     * 準備執行
     */
    prepare(algorithmCode, range) {
        this.activeLogicalAddress = null;
        this.memoryAPI = this.createMemoryAPI();
        
        try {
            const GeneratorFunction = Object.getPrototypeOf(function*(){}).constructor;
            const algorithmFunction = new GeneratorFunction(
                'mem', 'log', 'startAddr', 'endAddr',
                algorithmCode
            );
            
            this.generator = algorithmFunction(
                this.memoryAPI,
                (message) => this.simulator.ui.log('演算法', message),
                range.startAddr,
                range.endAddr
            );
            
        } catch (error) {
            throw new Error(`演算法編譯失敗: ${error.message}`);
        }
    }

    /**
     * 執行下一步
     */
    executeNextStep() {
        if (!this.generator) {
            return { done: true };
        }

        try {
            const result = this.generator.next();
            
            if (result.done) {
                return { done: true };
            }

            const { addr, logEntry } = result.value;
            
            this.activeLogicalAddress = addr;
            
            if (logEntry) {
                this.simulator.ui.log(logEntry.op, logEntry.msg, logEntry.type);
            }
            
            this.simulator.saveState();
            this.simulator.ui.updateAllDisplays();
            
            return { done: false };
            
        } catch (error) {
            this.simulator.ui.log('錯誤', `執行錯誤: ${error.message}`, 'error');
            return { done: true };
        }
    }

    /**
     * 創建記憶體API
     */
    createMemoryAPI() {
        return {
            size: () => this.simulator.memory.addressCount,
            allOnes: () => this.simulator.memory.allOnesValue,
            dataWidth: () => this.simulator.memory.dataWidth,
            
            write: function* (logicalAddr, value) {
                const physicalAddr = this.simulator.memory.logicalToPhysical(logicalAddr);
                
                const logEntry = {
                    op: 'write',
                    msg: `寫入 0x${value.toString(16).padStart(Math.ceil(this.simulator.memory.dataWidth/4), '0')} 到 L${logicalAddr}→P${physicalAddr}`,
                    type: 'write'
                };
                
                yield { addr: logicalAddr, logEntry };
                
                this.simulator.memory.write(logicalAddr, value);
            }.bind(this),
            
            readAndCheck: function* (logicalAddr, expectedValue) {
                const physicalAddr = this.simulator.memory.logicalToPhysical(logicalAddr);
                const actualValue = this.simulator.memory.read(logicalAddr);
                
                const expectedHex = expectedValue.toString(16).padStart(Math.ceil(this.simulator.memory.dataWidth/4), '0');
                const actualHex = actualValue.toString(16).padStart(Math.ceil(this.simulator.memory.dataWidth/4), '0');
                
                let message = `讀取 L${logicalAddr}→P${physicalAddr}: 預期 0x${expectedHex}, 實際 0x${actualHex}`;
                let logType = 'read';
                
                if (actualValue !== expectedValue) {
                    message += ' [故障]';
                    logType = 'error';
                    
                    const detectedFaults = this.simulator.memory.detectFaults(logicalAddr, expectedValue, actualValue);
                    detectedFaults.forEach(fault => {
                        this.simulator.ui.log('檢測', `故障 ${fault.id} 已檢測`, 'error');
                    });
                }
                
                const logEntry = { op: 'read', msg: message, type: logType };
                yield { addr: logicalAddr, logEntry };
                
                return actualValue;
            }.bind(this)
        };
    }
}

// 匯出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ScrollableMemorySimulator, SimpleExecutionEngine };
}