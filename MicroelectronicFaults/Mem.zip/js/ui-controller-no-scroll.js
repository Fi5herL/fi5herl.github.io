/**
 * 無卷軸UI控制器 - 支援記憶體映射功能
 */

class NoScrollUIController {
    constructor(simulator) {
        this.simulator = simulator;
        this.elements = {};
        this.state = {
            isRunning: false,
            isPaused: false,
            currentStep: 0,
            totalSteps: 0
        };
        this.toastTimeout = null;
        this.initializeElements();
        this.bindEvents();
    }

    /**
     * 初始化DOM元素引用
     */
    initializeElements() {
        this.elements = {
            // 記憶體設定
            memAddrCount: document.getElementById('mem-addr-count'),
            memDataWidth: document.getElementById('mem-data-width'),
            btnSetSize: document.getElementById('btn-set-size'),
            
            // 記憶體映射
            mappingFile: document.getElementById('mapping-file'),
            mappingType: document.getElementById('mapping-type'),
            btnApplyMapping: document.getElementById('btn-apply-mapping'),
            btnExportMapping: document.getElementById('btn-export-mapping'),
            mappingInfo: document.getElementById('mapping-info'),
            
            // 故障控制
            faultType: document.getElementById('fault-type'),
            faultDomain: document.getElementById('fault-domain'),
            faultAddr1: document.getElementById('fault-addr1'),
            faultBit1: document.getElementById('fault-bit1'),
            faultAddr2: document.getElementById('fault-addr2'),
            faultBit2: document.getElementById('fault-bit2'),
            faultCell2: document.getElementById('fault-cell2'),
            btnInjectFault: document.getElementById('btn-inject-fault'),
            btnClearFaults: document.getElementById('btn-clear-faults'),
            
            // 演算法控制
            algorithmSelect: document.getElementById('algorithm-select'),
            rangeModeSelect: document.getElementById('range-mode-select'),
            addrRangeInputs: document.getElementById('addr-range-inputs'),
            startAddr: document.getElementById('start-addr'),
            endAddr: document.getElementById('end-addr'),
            opDelay: document.getElementById('op-delay'),
            btnRunAuto: document.getElementById('btn-run-auto'),
            btnRunStep: document.getElementById('btn-run-step'),
            btnNextStep: document.getElementById('btn-next-step'),
            
            // 顯示元素
            timeline: document.getElementById('timeline'),
            timelineLabel: document.getElementById('timeline-label'),
            viewLogical: document.getElementById('view-logical'),
            viewPhysical: document.getElementById('view-physical'),
            mappingVisualization: document.getElementById('mapping-visualization'),
            logDisplay: document.getElementById('log-display'),
            resultsDisplay: document.getElementById('results-display'),
            
            // 匯出功能
            btnExportLog: document.getElementById('btn-export-log'),
            btnExportResults: document.getElementById('btn-export-results'),
            btnExportState: document.getElementById('btn-export-state'),
            
            // 其他
            toastContainer: document.getElementById('toast-container')
        };
    }

    /**
     * 綁定事件監聽器
     */
    bindEvents() {
        // 記憶體設定
        this.elements.btnSetSize.addEventListener('click', () => this.handleSetMemorySize());

        // 記憶體映射
        this.elements.mappingFile.addEventListener('change', () => this.handleMappingFileChange());
        this.elements.btnApplyMapping.addEventListener('click', () => this.handleApplyMapping());
        this.elements.btnExportMapping.addEventListener('click', () => this.handleExportMapping());

        // 故障控制
        this.elements.faultType.addEventListener('change', () => this.updateFaultInputs());
        this.elements.btnInjectFault.addEventListener('click', () => this.handleInjectFault());
        this.elements.btnClearFaults.addEventListener('click', () => this.handleClearFaults());

        // 演算法控制
        this.elements.algorithmSelect.addEventListener('change', () => this.loadSelectedAlgorithm());
        this.elements.rangeModeSelect.addEventListener('change', () => this.updateRangeInputs());
        this.elements.btnRunAuto.addEventListener('click', () => this.handleRunAuto());
        this.elements.btnRunStep.addEventListener('click', () => this.handleRunStep());
        this.elements.btnNextStep.addEventListener('click', () => this.handleNextStep());

        // 時間軸
        this.elements.timeline.addEventListener('input', () => this.handleTimelineChange());

        // 匯出功能
        this.elements.btnExportLog.addEventListener('click', () => this.exportLog());
        this.elements.btnExportResults.addEventListener('click', () => this.exportResults());
        this.elements.btnExportState.addEventListener('click', () => this.exportState());

        // 鍵盤快捷鍵
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
    }

    /**
     * 處理記憶體大小設定
     */
    handleSetMemorySize() {
        try {
            const addrCount = parseInt(this.elements.memAddrCount.value);
            const dataWidth = parseInt(this.elements.memDataWidth.value);

            if (isNaN(addrCount) || addrCount < 2 || addrCount > 16) {
                throw new Error('位址數量必須在 2-16 之間');
            }

            if (isNaN(dataWidth) || dataWidth < 2 || dataWidth > 8) {
                throw new Error('資料寬度必須在 2-8 之間');
            }

            this.simulator.setMemorySize(addrCount, dataWidth);
            this.updateAllDisplays();
            this.showToast('記憶體大小設定成功', 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理映射檔案變更
     */
    handleMappingFileChange() {
        const file = this.elements.mappingFile.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const content = e.target.result;
                const mapping = this.parseMappingFile(content, file.name);
                this.simulator.setAddressMapping(mapping.data, mapping.description);
                this.updateAllDisplays();
                this.showToast('映射檔案載入成功', 'success');
            } catch (error) {
                this.showToast(`檔案載入失敗: ${error.message}`, 'error');
            }
        };
        reader.readAsText(file);
    }

    /**
     * 解析映射檔案
     */
    parseMappingFile(content, filename) {
        const extension = filename.split('.').pop().toLowerCase();
        
        if (extension === 'csv') {
            return this.parseCSVMapping(content);
        } else if (extension === 'json') {
            return this.parseJSONMapping(content);
        } else {
            throw new Error('不支援的檔案格式，請使用CSV或JSON');
        }
    }

    /**
     * 解析CSV映射
     */
    parseCSVMapping(content) {
        const lines = content.trim().split('\n');
        const header = lines[0].toLowerCase().split(',');
        
        if (header.length !== 2 || !header.includes('logical') || !header.includes('physical')) {
            throw new Error('CSV格式錯誤，需要包含 logical 和 physical 欄位');
        }
        
        const logicalIndex = header.indexOf('logical');
        const physicalIndex = header.indexOf('physical');
        const mapping = {};
        
        for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(',');
            if (values.length !== 2) continue;
            
            const logical = parseInt(values[logicalIndex]);
            const physical = parseInt(values[physicalIndex]);
            
            if (isNaN(logical) || isNaN(physical)) {
                throw new Error(`第 ${i + 1} 行：無效的數字格式`);
            }
            
            mapping[logical] = physical;
        }
        
        return {
            data: mapping,
            description: `CSV映射 (${Object.keys(mapping).length} 項目)`
        };
    }

    /**
     * 解析JSON映射
     */
    parseJSONMapping(content) {
        const data = JSON.parse(content);
        
        if (!data.mapping || typeof data.mapping !== 'object') {
            throw new Error('JSON格式錯誤，需要包含 mapping 物件');
        }
        
        const mapping = {};
        for (const [logical, physical] of Object.entries(data.mapping)) {
            const logicalNum = parseInt(logical);
            const physicalNum = parseInt(physical);
            
            if (isNaN(logicalNum) || isNaN(physicalNum)) {
                throw new Error(`無效的映射項目: ${logical} -> ${physical}`);
            }
            
            mapping[logicalNum] = physicalNum;
        }
        
        return {
            data: mapping,
            description: data.description || `JSON映射 (${Object.keys(mapping).length} 項目)`
        };
    }

    /**
     * 處理套用映射
     */
    handleApplyMapping() {
        try {
            const mappingType = this.elements.mappingType.value;
            const presetMapping = this.simulator.memory.getPresetMapping(mappingType);
            
            this.simulator.setAddressMapping(presetMapping.mapping, presetMapping.description);
            this.updateAllDisplays();
            this.showToast(`${presetMapping.description} 套用成功`, 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理匯出映射
     */
    handleExportMapping() {
        try {
            const format = prompt('選擇匯出格式 (csv/json):', 'csv');
            if (!format) return;
            
            let content, filename, mimeType;
            
            if (format.toLowerCase() === 'csv') {
                content = this.simulator.memory.exportMappingCSV();
                filename = `memory-mapping-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.csv`;
                mimeType = 'text/csv';
            } else if (format.toLowerCase() === 'json') {
                content = this.simulator.memory.exportMappingJSON();
                filename = `memory-mapping-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`;
                mimeType = 'application/json';
            } else {
                throw new Error('不支援的格式');
            }
            
            this.downloadFile(content, filename, mimeType);
            this.showToast('映射檔案匯出成功', 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 更新故障輸入界面
     */
    updateFaultInputs() {
        const faultType = this.elements.faultType.value;
        const isBridging = faultType.startsWith('BF_');
        
        this.elements.faultCell2.style.display = isBridging ? 'flex' : 'none';
        
        if (faultType === 'BF_OutIn') {
            this.elements.faultAddr1.placeholder = '攻擊者位址';
            this.elements.faultBit1.placeholder = '攻擊者位元';
            this.elements.faultAddr2.placeholder = '受害者位址';
            this.elements.faultBit2.placeholder = '受害者位元';
        } else if (isBridging) {
            this.elements.faultAddr1.placeholder = '位址 1';
            this.elements.faultBit1.placeholder = '位元 1';
            this.elements.faultAddr2.placeholder = '位址 2';
            this.elements.faultBit2.placeholder = '位元 2';
        } else {
            this.elements.faultAddr1.placeholder = '位址';
            this.elements.faultBit1.placeholder = '位元';
        }
    }

    /**
     * 處理故障注入
     */
    handleInjectFault() {
        try {
            const faultType = this.elements.faultType.value;
            const faultDomain = this.elements.faultDomain.value;
            const addr1 = parseInt(this.elements.faultAddr1.value);
            const bit1 = parseInt(this.elements.faultBit1.value);

            if (isNaN(addr1) || isNaN(bit1)) {
                throw new Error('請輸入有效的位址和位元');
            }

            let faultInfo = { type: faultType, domain: faultDomain, addr1, bit1 };

            if (faultType.startsWith('BF_')) {
                const addr2 = parseInt(this.elements.faultAddr2.value);
                const bit2 = parseInt(this.elements.faultBit2.value);

                if (isNaN(addr2) || isNaN(bit2)) {
                    throw new Error('請輸入有效的第二組位址和位元');
                }

                faultInfo.addr2 = addr2;
                faultInfo.bit2 = bit2;
            }

            const fault = this.simulator.injectFault(faultInfo);
            this.updateAllDisplays();
            this.log('系統', `故障注入成功: ${fault.id}`, 'info');
            this.showToast(`故障注入成功`, 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理清除故障
     */
    handleClearFaults() {
        try {
            this.simulator.clearFaults();
            this.updateAllDisplays();
            this.log('系統', '所有故障已清除', 'info');
            this.showToast('所有故障已清除', 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 載入選定的演算法
     */
    loadSelectedAlgorithm() {
        const algorithmName = this.elements.algorithmSelect.value;
        // 這裡可以添加演算法載入邏輯
        this.updateRangeInputs();
    }

    /**
     * 更新範圍輸入界面
     */
    updateRangeInputs() {
        const rangeMode = this.elements.rangeModeSelect.value;
        
        this.elements.addrRangeInputs.style.display = 
            rangeMode === 'addr' ? 'block' : 'none';

        if (this.simulator.memory) {
            this.elements.startAddr.max = this.simulator.memory.addressCount - 1;
            this.elements.endAddr.max = this.simulator.memory.addressCount - 1;
        }
    }

    /**
     * 處理自動執行
     */
    handleRunAuto() {
        try {
            this.simulator.runAuto();
            this.updateControlButtons();
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理單步執行
     */
    handleRunStep() {
        try {
            this.simulator.runStep();
            this.updateControlButtons();
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理下一步
     */
    handleNextStep() {
        try {
            this.simulator.nextStep();
            this.updateControlButtons();
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理時間軸變化
     */
    handleTimelineChange() {
        const step = parseInt(this.elements.timeline.value);
        this.simulator.goToStep(step);
        this.updateAllDisplays();
    }

    /**
     * 更新所有顯示
     */
    updateAllDisplays() {
        this.updateMemoryViews();
        this.updateMappingInfo();
        this.updateMappingVisualization();
        this.updateTimeline();
        this.updateResults();
    }

    /**
     * 更新記憶體視圖
     */
    updateMemoryViews() {
        if (!this.simulator.memory) return;

        this.elements.viewLogical.innerHTML = '';
        this.elements.viewPhysical.innerHTML = '';

        const activeLogicalAddress = this.simulator.getCurrentActiveLogicalAddress();
        const activePhysicalAddress = activeLogicalAddress !== null ? 
            this.simulator.memory.logicalToPhysical(activeLogicalAddress) : null;

        // 渲染邏輯視圖
        this._renderMemoryView(this.elements.viewLogical, 'logical', activeLogicalAddress);
        
        // 渲染物理視圖
        this._renderMemoryView(this.elements.viewPhysical, 'physical', activePhysicalAddress);
    }

    /**
     * 渲染記憶體視圖
     */
    _renderMemoryView(container, viewType, activeAddress) {
        const memory = this.simulator.memory;
        
        for (let i = 0; i < memory.addressCount; i++) {
            const row = document.createElement('div');
            row.className = 'memory-row';
            
            if (i === activeAddress) {
                row.classList.add('active');
            }

            const label = document.createElement('div');
            label.className = 'addr-label';
            label.textContent = `${viewType === 'logical' ? 'L' : 'P'}${i}:`;
            row.appendChild(label);

            const bitsContainer = document.createElement('div');
            bitsContainer.className = 'word-bits';

            // 獲取該位址的值
            let wordValue;
            if (viewType === 'logical') {
                wordValue = memory.read(i);
            } else {
                wordValue = memory.cells[i];
            }
            
            // 從高位到低位顯示（MSB-first）
            for (let j = memory.dataWidth - 1; j >= 0; j--) {
                const bit = document.createElement('div');
                bit.className = 'bit';
                const bitValue = (wordValue >> j) & 1;
                bit.textContent = bitValue;
                bit.classList.add(bitValue === 0 ? 'bit-0' : 'bit-1');

                // 添加故障標示
                const bitFaults = this._getBitFaults(i, j, viewType);
                if (bitFaults.length > 0) {
                    bitFaults.forEach(fault => {
                        if (fault.type.startsWith('SA')) {
                            bit.classList.add(`fault-${fault.type.toLowerCase()}`);
                        } else if (fault.type.startsWith('BF')) {
                            bit.classList.add('fault-bf');
                        } else if (fault.type.startsWith('TF')) {
                            bit.classList.add('fault-tf');
                        }
                    });

                    const tooltip = document.createElement('span');
                    tooltip.className = 'fault-tooltip';
                    tooltip.textContent = bitFaults.map(f => f.id).join(', ');
                    bit.appendChild(tooltip);
                }

                bitsContainer.appendChild(bit);
            }

            row.appendChild(bitsContainer);
            container.appendChild(row);
        }
    }

    /**
     * 獲取位元相關的故障
     */
    _getBitFaults(addr, bit, viewType) {
        return this.simulator.memory.faults.filter(fault => {
            if (viewType === 'logical') {
                return (fault.logicalAddr1 === addr && fault.logicalBit1 === bit) ||
                       (fault.logicalAddr2 === addr && fault.logicalBit2 === bit);
            } else {
                return (fault.physicalAddr1 === addr && fault.physicalBit1 === bit) ||
                       (fault.physicalAddr2 === addr && fault.physicalBit2 === bit);
            }
        });
    }

    /**
     * 更新映射資訊
     */
    updateMappingInfo() {
        if (!this.simulator.memory) return;

        const mappingInfo = this.simulator.memory.getMappingInfo();
        this.elements.mappingInfo.textContent = mappingInfo.description;
    }

    /**
     * 更新映射視覺化
     */
    updateMappingVisualization() {
        if (!this.simulator.memory) return;

        const mappingInfo = this.simulator.memory.getMappingInfo();
        const mapping = mappingInfo.mapping;
        
        let visualText = '';
        if (mapping.length <= 8) {
            visualText = mapping.map(item => `L${item.logical}→P${item.physical}`).join(' ');
        } else {
            visualText = `${mapping.length} 項映射關係 (${mappingInfo.description})`;
        }
        
        this.elements.mappingVisualization.textContent = visualText;
    }

    /**
     * 更新時間軸
     */
    updateTimeline() {
        this.elements.timeline.max = this.state.totalSteps - 1;
        this.elements.timeline.value = this.state.currentStep;
        this.elements.timelineLabel.textContent = `Step ${this.state.currentStep} / ${this.state.totalSteps - 1}`;
    }

    /**
     * 更新結果顯示
     */
    updateResults() {
        if (!this.simulator.memory) return;

        const stats = this.simulator.memory.getFaultStatistics();
        const details = this.simulator.memory.getFaultDetails();

        let html = `
            <h4>故障統計</h4>
            <p>總計故障: ${stats.total}</p>
            <p>已檢測: ${stats.detected}</p>
            <p>未檢測: ${stats.undetected}</p>
            <p>覆蓋率: <strong>${stats.coverage}%</strong></p>
            <p>存取次數: ${stats.accessCount}</p>
            <p>映射類型: ${stats.mappingType}</p>
        `;

        if (details.length > 0) {
            html += '<h4>故障詳情</h4><ul>';
            details.forEach(fault => {
                const status = fault.detected ? '已檢測' : '未檢測';
                const color = fault.detected ? '#27ae60' : '#e74c3c';
                html += `<li>${fault.id}<br>
                    <small>邏輯: ${fault.logicalLocation} | 物理: ${fault.physicalLocation}</small><br>
                    <span style="color: ${color}; font-weight: bold;">${status}</span>
                </li>`;
            });
            html += '</ul>';
        }

        this.elements.resultsDisplay.innerHTML = html;
    }

    /**
     * 更新控制按鈕狀態
     */
    updateControlButtons() {
        this.elements.btnRunAuto.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.btnRunStep.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.btnNextStep.disabled = !this.state.isPaused;
        this.elements.btnInjectFault.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.btnSetSize.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.btnApplyMapping.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.timeline.disabled = this.state.isRunning || this.state.totalSteps <= 1;
    }

    /**
     * 記錄日誌
     */
    log(source, message, type = 'info') {
        const logEntry = document.createElement('div');
        logEntry.innerHTML = `<span class="log-op">[${source}]</span> <span class="log-${type}">${message}</span>`;
        this.elements.logDisplay.appendChild(logEntry);
        this.elements.logDisplay.scrollTop = this.elements.logDisplay.scrollHeight;
    }

    /**
     * 顯示提示訊息
     */
    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        this.elements.toastContainer.appendChild(toast);
        
        // 自動移除
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 3000);
    }

    /**
     * 匯出日誌
     */
    exportLog() {
        const logs = this.elements.logDisplay.innerText;
        this.downloadFile(logs, 
            `memory-test-log-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`,
            'text/plain');
    }

    /**
     * 匯出結果
     */
    exportResults() {
        if (!this.simulator.memory) return;

        const results = this.simulator.memory.exportState();
        this.downloadFile(JSON.stringify(results, null, 2),
            `memory-test-results-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`,
            'application/json');
    }

    /**
     * 匯出狀態
     */
    exportState() {
        const state = this.simulator.exportCompleteState();
        this.downloadFile(JSON.stringify(state, null, 2),
            `memory-simulator-state-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`,
            'application/json');
    }

    /**
     * 下載檔案
     */
    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
    }

    /**
     * 處理鍵盤快捷鍵
     */
    handleKeyboard(e) {
        if (e.ctrlKey) {
            switch (e.key) {
                case 'Enter':
                    e.preventDefault();
                    if (this.state.isPaused) {
                        this.handleNextStep();
                    } else if (!this.state.isRunning) {
                        this.handleRunAuto();
                    }
                    break;
                case ' ':
                    e.preventDefault();
                    if (!this.state.isRunning) {
                        this.handleRunStep();
                    }
                    break;
                case 'r':
                    e.preventDefault();
                    this.handleSetMemorySize();
                    break;
            }
        }
    }

    /**
     * 更新演算法選擇框
     */
    updateAlgorithmSelect() {
        const algorithms = this.simulator.algorithms.getAllAlgorithms();
        
        this.elements.algorithmSelect.innerHTML = '';
        
        Object.keys(algorithms).forEach(name => {
            const option = document.createElement('option');
            option.value = name;
            option.textContent = name;
            this.elements.algorithmSelect.appendChild(option);
        });
    }

    /**
     * 更新狀態
     */
    updateState(newState) {
        this.state = { ...this.state, ...newState };
        this.updateControlButtons();
        this.updateTimeline();
    }
}

// 如果在 Node.js 環境中，匯出模組
if (typeof module !== 'undefined' && module.exports) {
    module.exports = NoScrollUIController;
}