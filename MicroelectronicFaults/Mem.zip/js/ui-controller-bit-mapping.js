/**
 * 位元級映射UI控制器
 */

class BitMappingUIController {
    constructor(simulator) {
        this.simulator = simulator;
        this.elements = this.initializeElements();
        this.bindEvents();
    }

    /**
     * 初始化DOM元素
     */
    initializeElements() {
        return {
            // 記憶體設定
            memAddrCount: document.getElementById('mem-addr-count'),
            memDataWidth: document.getElementById('mem-data-width'),
            btnSetSize: document.getElementById('btn-set-size'),
            
            // 位元級映射控制
            bitMappingType: document.getElementById('bit-mapping-type'),
            bitMappingFile: document.getElementById('bit-mapping-file'),
            btnApplyBitMapping: document.getElementById('btn-apply-bit-mapping'),
            btnExportBitMapping: document.getElementById('btn-export-bit-mapping'),
            btnShowBitMapping: document.getElementById('btn-show-bit-mapping'),
            bitMappingStatus: document.getElementById('bit-mapping-status'),
            
            // 故障控制
            faultType: document.getElementById('fault-type'),
            faultDomain: document.getElementById('fault-domain'),
            faultAddr1: document.getElementById('fault-addr1'),
            faultBit1: document.getElementById('fault-bit1'),
            faultAddr2: document.getElementById('fault-addr2'),
            faultBit2: document.getElementById('fault-bit2'),
            faultSecondGroup: document.getElementById('fault-second-group'),
            btnShowBitMappingForFault: document.getElementById('btn-show-bit-mapping-for-fault'),
            btnInjectFault: document.getElementById('btn-inject-fault'),
            btnClearFaults: document.getElementById('btn-clear-faults'),
            
            // 演算法控制
            algorithmSelect: document.getElementById('algorithm-select'),
            rangeMode: document.getElementById('range-mode'),
            rangeInputs: document.getElementById('range-inputs'),
            startAddr: document.getElementById('start-addr'),
            endAddr: document.getElementById('end-addr'),
            execDelay: document.getElementById('exec-delay'),
            btnRunAuto: document.getElementById('btn-run-auto'),
            btnRunStep: document.getElementById('btn-run-step'),
            btnNextStep: document.getElementById('btn-next-step'),
            
            // 快速操作
            btnReset: document.getElementById('btn-reset'),
            btnStop: document.getElementById('btn-stop'),
            btnExportLog: document.getElementById('btn-export-log'),
            btnExportResults: document.getElementById('btn-export-results'),
            
            // 位元映射視覺化
            btnToggleMappingView: document.getElementById('btn-toggle-mapping-view'),
            showMappingLines: document.getElementById('show-mapping-lines'),
            bitMappingVisualization: document.getElementById('bit-mapping-visualization'),
            
            // 顯示元素
            timelineSlider: document.getElementById('timeline-slider'),
            timelineLabel: document.getElementById('timeline-label'),
            logicalMemory: document.getElementById('logical-memory'),
            physicalMemory: document.getElementById('physical-memory'),
            executionLog: document.getElementById('execution-log'),
            analysisResults: document.getElementById('analysis-results'),
            
            // 模態框
            bitMappingModal: document.getElementById('bit-mapping-modal'),
            bitMappingTable: document.getElementById('bit-mapping-table'),
            fileFormatHelp: document.getElementById('file-format-help')
        };
    }

    /**
     * 綁定事件
     */
    bindEvents() {
        // 記憶體設定
        this.elements.btnSetSize.addEventListener('click', () => this.handleSetMemorySize());
        this.elements.memDataWidth.addEventListener('change', () => this.updateBitInputMaxValues());

        // 位元映射控制
        this.elements.btnApplyBitMapping.addEventListener('click', () => this.handleApplyBitMapping());
        this.elements.btnExportBitMapping.addEventListener('click', () => this.handleExportBitMapping());
        this.elements.btnShowBitMapping.addEventListener('click', () => this.handleShowBitMapping());
        this.elements.bitMappingFile.addEventListener('change', () => this.handleBitMappingFileChange());

        // 故障控制
        this.elements.faultType.addEventListener('change', () => this.updateFaultInputs());
        this.elements.btnShowBitMappingForFault.addEventListener('click', () => this.handleShowBitMappingForFault());
        this.elements.btnInjectFault.addEventListener('click', () => this.handleInjectFault());
        this.elements.btnClearFaults.addEventListener('click', () => this.handleClearFaults());

        // 演算法控制
        this.elements.algorithmSelect.addEventListener('change', () => this.loadSelectedAlgorithm());
        this.elements.rangeMode.addEventListener('change', () => this.updateRangeInputs());
        this.elements.btnRunAuto.addEventListener('click', () => this.handleRunAuto());
        this.elements.btnRunStep.addEventListener('click', () => this.handleRunStep());
        this.elements.btnNextStep.addEventListener('click', () => this.handleNextStep());

        // 快速操作
        this.elements.btnReset.addEventListener('click', () => this.handleReset());
        this.elements.btnStop.addEventListener('click', () => this.handleStop());
        this.elements.btnExportLog.addEventListener('click', () => this.handleExportLog());
        this.elements.btnExportResults.addEventListener('click', () => this.handleExportResults());

        // 位元映射視覺化
        this.elements.btnToggleMappingView.addEventListener('click', () => this.toggleMappingView());
        this.elements.showMappingLines.addEventListener('change', () => this.updateMappingVisualization());

        // 時間軸
        this.elements.timelineSlider.addEventListener('input', () => this.handleTimelineChange());
    }

    /**
     * 處理記憶體大小設定
     */
    handleSetMemorySize() {
        try {
            showLoading();
            
            const addrCount = parseInt(this.elements.memAddrCount.value);
            const dataWidth = parseInt(this.elements.memDataWidth.value);

            if (isNaN(addrCount) || addrCount < 2 || addrCount > 16) {
                throw new Error('位址數量必須在 2-16 之間');
            }

            if (isNaN(dataWidth) || dataWidth < 2 || dataWidth > 16) {
                throw new Error('資料寬度必須在 2-16 之間');
            }

            this.simulator.setMemorySize(addrCount, dataWidth);
            this.updateAllDisplays();
            this.updateInputConstraints();
            showMessage('記憶體大小設定成功', 'success');
            
        } catch (error) {
            showMessage(error.message, 'error');
        } finally {
            hideLoading();
        }
    }

    /**
     * 更新輸入約束
     */
    updateInputConstraints() {
        if (!this.simulator.memory) return;

        const maxAddr = this.simulator.memory.addressCount - 1;
        const maxBit = this.simulator.memory.dataWidth - 1;

        // 更新故障輸入約束
        [this.elements.faultAddr1, this.elements.faultAddr2].forEach(input => {
            input.max = maxAddr;
        });

        [this.elements.faultBit1, this.elements.faultBit2].forEach(input => {
            input.max = maxBit;
        });

        // 更新範圍輸入約束
        this.elements.startAddr.max = maxAddr;
        this.elements.endAddr.max = maxAddr;
    }

    /**
     * 更新位元輸入最大值
     */
    updateBitInputMaxValues() {
        const dataWidth = parseInt(this.elements.memDataWidth.value);
        if (!isNaN(dataWidth) && dataWidth > 0) {
            const maxBit = dataWidth - 1;
            [this.elements.faultBit1, this.elements.faultBit2].forEach(input => {
                input.max = maxBit;
            });
        }
    }

    /**
     * 處理位元映射套用
     */
    handleApplyBitMapping() {
        try {
            const mappingType = this.elements.bitMappingType.value;
            const presetMapping = this.simulator.memory.getPresetBitMapping(mappingType);
            
            this.simulator.setBitMapping(presetMapping.mapping, presetMapping.description);
            this.updateAllDisplays();
            showMessage('位元映射套用成功', 'success');
            
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理位元映射匯出
     */
    handleExportBitMapping() {
        try {
            const format = prompt('選擇匯出格式 (csv/json):', 'csv');
            if (!format) return;
            
            let content, filename, mimeType;
            
            if (format.toLowerCase() === 'csv') {
                content = this.simulator.memory.exportBitMappingCSV();
                filename = `bit-mapping-${Date.now()}.csv`;
                mimeType = 'text/csv';
            } else if (format.toLowerCase() === 'json') {
                content = this.simulator.memory.exportBitMappingJSON();
                filename = `bit-mapping-${Date.now()}.json`;
                mimeType = 'application/json';
            } else {
                throw new Error('不支援的格式');
            }
            
            this.downloadFile(content, filename, mimeType);
            showMessage('位元映射匯出成功', 'success');
            
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理顯示位元映射
     */
    handleShowBitMapping() {
        try {
            this.showBitMappingModal();
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理位元映射檔案變更
     */
    handleBitMappingFileChange() {
        const file = this.elements.bitMappingFile.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const content = e.target.result;
                const mapping = this.parseBitMappingFile(content, file.name);
                this.simulator.setBitMapping(mapping.data, mapping.description);
                this.updateAllDisplays();
                showMessage('位元映射檔案載入成功', 'success');
            } catch (error) {
                showMessage(`檔案載入失敗: ${error.message}`, 'error');
            }
        };
        reader.readAsText(file);
    }

    /**
     * 解析位元映射檔案
     */
    parseBitMappingFile(content, filename) {
        const extension = filename.split('.').pop().toLowerCase();
        
        if (extension === 'csv') {
            return this.parseBitMappingCSV(content);
        } else if (extension === 'json') {
            return this.parseBitMappingJSON(content);
        } else {
            throw new Error('不支援的檔案格式');
        }
    }

    /**
     * 解析位元映射CSV
     */
    parseBitMappingCSV(content) {
        const lines = content.trim().split('\n');
        const header = lines[0].toLowerCase().split(',');
        
        const expectedColumns = ['logical_addr', 'logical_bit', 'physical_addr', 'physical_bit'];
        if (!expectedColumns.every(col => header.includes(col))) {
            throw new Error('CSV格式錯誤：需要 logical_addr,logical_bit,physical_addr,physical_bit 欄位');
        }
        
        const mapping = {};
        
        for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(',');
            if (values.length < 4) continue;
            
            const logicalAddr = parseInt(values[header.indexOf('logical_addr')]);
            const logicalBit = parseInt(values[header.indexOf('logical_bit')]);
            const physicalAddr = parseInt(values[header.indexOf('physical_addr')]);
            const physicalBit = parseInt(values[header.indexOf('physical_bit')]);
            
            if (isNaN(logicalAddr) || isNaN(logicalBit) || isNaN(physicalAddr) || isNaN(physicalBit)) {
                throw new Error(`第 ${i + 1} 行：無效的數字格式`);
            }
            
            const logicalKey = `${logicalAddr}_${logicalBit}`;
            const physicalKey = `${physicalAddr}_${physicalBit}`;
            mapping[logicalKey] = physicalKey;
        }
        
        return {
            data: mapping,
            description: `CSV位元映射 (${Object.keys(mapping).length} 位元)`
        };
    }

    /**
     * 解析位元映射JSON
     */
    parseBitMappingJSON(content) {
        const data = JSON.parse(content);
        
        if (!data.mapping || typeof data.mapping !== 'object') {
            throw new Error('JSON格式錯誤：需要 mapping 欄位');
        }
        
        return {
            data: data.mapping,
            description: data.description || 'JSON位元映射'
        };
    }

    /**
     * 更新故障輸入
     */
    updateFaultInputs() {
        const faultType = this.elements.faultType.value;
        const isBridging = faultType.startsWith('BF_');
        
        this.elements.faultSecondGroup.style.display = isBridging ? 'block' : 'none';
        
        // 更新佔位符
        if (faultType === 'BF_OutIn') {
            this.elements.faultAddr1.placeholder = '攻擊者位址';
            this.elements.faultBit1.placeholder = '攻擊者位元';
            this.elements.faultAddr2.placeholder = '受害者位址';
            this.elements.faultBit2.placeholder = '受害者位元';
        } else {
            this.elements.faultAddr1.placeholder = '位址';
            this.elements.faultBit1.placeholder = '位元';
            this.elements.faultAddr2.placeholder = '位址2';
            this.elements.faultBit2.placeholder = '位元2';
        }
    }

    /**
     * 處理顯示故障位元映射
     */
    handleShowBitMappingForFault() {
        try {
            const addr1 = parseInt(this.elements.faultAddr1.value);
            const bit1 = parseInt(this.elements.faultBit1.value);
            
            if (isNaN(addr1) || isNaN(bit1)) {
                throw new Error('請輸入有效的位址和位元');
            }
            
            const domain = this.elements.faultDomain.value;
            let mappingInfo;
            
            if (domain === 'logical') {
                const physical = this.simulator.memory.logicalBitToPhysical(addr1, bit1);
                mappingInfo = `邏輯位元 L${addr1},${bit1} → 物理位元 P${physical.addr},${physical.bit}`;
            } else {
                const logical = this.simulator.memory.physicalBitToLogical(addr1, bit1);
                mappingInfo = `物理位元 P${addr1},${bit1} → 邏輯位元 L${logical.addr},${logical.bit}`;
            }
            
            showMessage(mappingInfo, 'info');
            
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理故障注入
     */
    handleInjectFault() {
        try {
            const faultType = this.elements.faultType.value;
            const faultDomain = this.elements.faultDomain.value;
            const addr1 = parseInt(this.elements.faultAddr1.value);
            const bit1 = parseInt(this.elements.faultBit1.value);

            if (isNaN(addr1) || isNaN(bit1)) {
                throw new Error('請輸入有效的位址和位元');
            }

            let faultInfo = { type: faultType, domain: faultDomain, addr1, bit1 };

            if (faultType.startsWith('BF_')) {
                const addr2 = parseInt(this.elements.faultAddr2.value);
                const bit2 = parseInt(this.elements.faultBit2.value);

                if (isNaN(addr2) || isNaN(bit2)) {
                    throw new Error('請輸入有效的第二組位址和位元');
                }

                faultInfo.addr2 = addr2;
                faultInfo.bit2 = bit2;
            }

            const fault = this.simulator.injectFault(faultInfo);
            this.updateAllDisplays();
            this.log('系統', `故障注入成功: ${fault.id}`);
            showMessage('故障注入成功', 'success');
            
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理清除故障
     */
    handleClearFaults() {
        try {
            this.simulator.clearFaults();
            this.updateAllDisplays();
            this.log('系統', '所有故障已清除');
            showMessage('所有故障已清除', 'success');
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 載入選定的演算法
     */
    loadSelectedAlgorithm() {
        this.updateRangeInputs();
    }

    /**
     * 更新範圍輸入
     */
    updateRangeInputs() {
        const rangeMode = this.elements.rangeMode.value;
        this.elements.rangeInputs.style.display = rangeMode === 'range' ? 'block' : 'none';
    }

    /**
     * 處理自動執行
     */
    handleRunAuto() {
        try {
            this.simulator.runAuto();
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理單步執行
     */
    handleRunStep() {
        try {
            this.simulator.runStep();
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理下一步
     */
    handleNextStep() {
        try {
            this.simulator.nextStep();
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理重置
     */
    handleReset() {
        try {
            this.simulator.reset();
            showMessage('系統已重置', 'success');
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理停止
     */
    handleStop() {
        try {
            this.simulator.stop();
            showMessage('執行已停止', 'info');
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理匯出日誌
     */
    handleExportLog() {
        try {
            const logs = this.elements.executionLog.innerText;
            this.downloadFile(logs, `bit-mapping-log-${Date.now()}.txt`, 'text/plain');
            showMessage('日誌匯出成功', 'success');
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理匯出結果
     */
    handleExportResults() {
        try {
            const results = this.simulator.exportState();
            this.downloadFile(JSON.stringify(results, null, 2), `bit-mapping-results-${Date.now()}.json`, 'application/json');
            showMessage('結果匯出成功', 'success');
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 處理時間軸變更
     */
    handleTimelineChange() {
        const step = parseInt(this.elements.timelineSlider.value);
        try {
            this.simulator.goToStep(step);
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }

    /**
     * 切換映射視圖
     */
    toggleMappingView() {
        // 切換位元映射視覺化的顯示模式
        this.updateMappingVisualization();
    }

    /**
     * 更新映射視覺化
     */
    updateMappingVisualization() {
        if (!this.simulator.memory) return;

        const container = this.elements.bitMappingVisualization;
        const showLines = this.elements.showMappingLines.checked;
        
        // 清除現有內容
        container.innerHTML = '';
        
        // 創建映射視覺化
        const mappingInfo = this.simulator.memory.getBitMappingInfo();
        
        if (mappingInfo.mapping.length === 0) {
            container.innerHTML = '<p>無位元映射資訊</p>';
            return;
        }
        
        // 創建視覺化元素
        const visualDiv = document.createElement('div');
        visualDiv.className = 'mapping-visual';
        
        // 映射統計
        const statsDiv = document.createElement('div');
        statsDiv.className = 'mapping-stats';
        statsDiv.innerHTML = `
            <h4>位元映射統計</h4>
            <p>映射類型: ${mappingInfo.type}</p>
            <p>描述: ${mappingInfo.description}</p>
            <p>位元總數: ${mappingInfo.mapping.length}</p>
        `;
        
        visualDiv.appendChild(statsDiv);
        
        // 映射預覽 - 根據複選框狀態顯示
        if (showLines) {
            const previewDiv = document.createElement('div');
            previewDiv.className = 'mapping-preview';
            
            const previewTitle = document.createElement('h5');
            previewTitle.textContent = '映射預覽：';
            previewDiv.appendChild(previewTitle);
            
            const gridDiv = document.createElement('div');
            gridDiv.className = 'mapping-grid';
            
            // 顯示前12個映射關係
            const previewCount = Math.min(12, mappingInfo.mapping.length);
            for (let i = 0; i < previewCount; i++) {
                const item = mappingInfo.mapping[i];
                const itemDiv = document.createElement('div');
                itemDiv.className = `mapping-item ${mappingInfo.type === 'identity' ? 'identity' : 'custom'}`;
                itemDiv.innerHTML = `
                    L${item.logicalAddr},${item.logicalBit}<br>
                    ↓<br>
                    P${item.physicalAddr},${item.physicalBit}
                `;
                gridDiv.appendChild(itemDiv);
            }
            
            if (mappingInfo.mapping.length > 12) {
                const moreDiv = document.createElement('div');
                moreDiv.className = 'mapping-item';
                moreDiv.innerHTML = `... 還有 ${mappingInfo.mapping.length - 12} 個映射`;
                gridDiv.appendChild(moreDiv);
            }
            
            previewDiv.appendChild(gridDiv);
            visualDiv.appendChild(previewDiv);
        } else {
            // 簡化顯示
            const summaryDiv = document.createElement('div');
            summaryDiv.innerHTML = `
                <p style="text-align: center; margin-top: 16px; color: #666;">
                    勾選「顯示詳細預覽」查看位元映射關係
                </p>
            `;
            visualDiv.appendChild(summaryDiv);
        }
        
        container.appendChild(visualDiv);
    }

    /**
     * 顯示位元映射模態框
     */
    showBitMappingModal() {
        if (!this.simulator.memory) return;

        const mappingInfo = this.simulator.memory.getBitMappingInfo();
        const tableBody = this.elements.bitMappingTable.querySelector('tbody');
        
        // 清除現有內容
        tableBody.innerHTML = '';
        
        // 填充表格
        mappingInfo.mapping.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>L${item.logicalAddr},${item.logicalBit}</td>
                <td>P${item.physicalAddr},${item.physicalBit}</td>
                <td>${item.logical} → ${item.physical}</td>
            `;
            tableBody.appendChild(row);
        });
        
        // 顯示模態框
        this.elements.bitMappingModal.style.display = 'flex';
    }

    /**
     * 更新所有顯示
     */
    updateAllDisplays() {
        this.updateMemoryDisplays();
        this.updateBitMappingStatus();
        this.updateMappingVisualization();
        this.updateTimelineDisplay();
    }

    /**
     * 更新記憶體顯示
     */
    updateMemoryDisplays() {
        if (!this.simulator.memory) return;

        const activeAddr = this.simulator.getCurrentActiveLogicalAddress();
        
        this.renderMemoryView(this.elements.logicalMemory, 'logical', activeAddr);
        this.renderMemoryView(this.elements.physicalMemory, 'physical', activeAddr);
    }

    /**
     * 渲染記憶體視圖
     */
    renderMemoryView(container, viewType, activeLogicalAddr) {
        container.innerHTML = '';
        
        const memory = this.simulator.memory;
        const isLogical = viewType === 'logical';
        
        for (let i = 0; i < memory.addressCount; i++) {
            const row = document.createElement('div');
            row.className = 'memory-row';
            
            // 確定顯示的位址和是否為活動位址
            const displayAddr = i;
            const isActive = activeLogicalAddr !== null && i === activeLogicalAddr;
            
            if (isActive) {
                row.classList.add('active');
            }

            // 位址標籤
            const addrLabel = document.createElement('div');
            addrLabel.className = 'addr-label';
            addrLabel.textContent = `${isLogical ? 'L' : 'P'}${displayAddr}:`;
            row.appendChild(addrLabel);

            // 記憶體位元
            const bitsContainer = document.createElement('div');
            bitsContainer.className = 'memory-bits';

            // 獲取該位址的值
            let wordValue;
            if (isLogical) {
                wordValue = memory.read(i);
            } else {
                wordValue = memory.cells[i];
            }

            // 從高位到低位顯示位元
            for (let j = memory.dataWidth - 1; j >= 0; j--) {
                const bit = document.createElement('div');
                bit.className = 'memory-bit';
                
                const bitValue = (wordValue >> j) & 1;
                bit.textContent = bitValue;
                bit.classList.add(bitValue === 0 ? 'bit-0' : 'bit-1');

                // 添加故障標示
                const bitFaults = this.getBitFaults(i, j, viewType);
                if (bitFaults.length > 0) {
                    bitFaults.forEach(fault => {
                        if (fault.type.startsWith('SA')) {
                            bit.classList.add(`fault-${fault.type.toLowerCase()}`);
                        } else if (fault.type.startsWith('BF')) {
                            bit.classList.add('fault-bf');
                        } else if (fault.type.startsWith('TF')) {
                            bit.classList.add('fault-tf');
                        }
                    });

                    // 添加提示
                    const tooltip = document.createElement('div');
                    tooltip.className = 'fault-tooltip';
                    tooltip.textContent = bitFaults.map(f => f.id).join(', ');
                    bit.appendChild(tooltip);
                }

                bitsContainer.appendChild(bit);
            }

            row.appendChild(bitsContainer);
            container.appendChild(row);
        }
    }

    /**
     * 獲取位元故障
     */
    getBitFaults(addr, bit, viewType) {
        return this.simulator.memory.faults.filter(fault => {
            if (viewType === 'logical') {
                return (fault.logicalAddr1 === addr && fault.logicalBit1 === bit) ||
                       (fault.logicalAddr2 === addr && fault.logicalBit2 === bit);
            } else {
                return (fault.physicalAddr1 === addr && fault.physicalBit1 === bit) ||
                       (fault.physicalAddr2 === addr && fault.physicalBit2 === bit);
            }
        });
    }

    /**
     * 更新位元映射狀態
     */
    updateBitMappingStatus() {
        if (!this.simulator.memory) return;

        const mappingInfo = this.simulator.memory.getBitMappingInfo();
        this.elements.bitMappingStatus.textContent = mappingInfo.description;
    }

    /**
     * 更新時間軸顯示
     */
    updateTimelineDisplay() {
        const totalSteps = this.simulator.executionHistory.length;
        const currentStep = this.simulator.currentStep;
        
        this.elements.timelineSlider.max = Math.max(0, totalSteps - 1);
        this.elements.timelineSlider.value = currentStep;
        this.elements.timelineSlider.disabled = totalSteps <= 1;
        
        this.elements.timelineLabel.textContent = `Step ${currentStep} / ${Math.max(0, totalSteps - 1)}`;
    }

    /**
     * 更新控制按鈕狀態
     */
    updateControlButtons() {
        const isRunning = this.simulator.isRunning;
        const isPaused = this.simulator.isPaused;
        
        this.elements.btnRunAuto.disabled = isRunning || isPaused;
        this.elements.btnRunStep.disabled = isRunning || isPaused;
        this.elements.btnNextStep.disabled = !isPaused;
        this.elements.btnStop.disabled = !isRunning;
        
        // 設定相關按鈕在執行時禁用
        this.elements.btnSetSize.disabled = isRunning;
        this.elements.btnApplyBitMapping.disabled = isRunning;
        this.elements.btnInjectFault.disabled = isRunning;
        this.elements.btnClearFaults.disabled = isRunning;
    }

    /**
     * 更新結果顯示
     */
    updateResultsDisplay(stats, details) {
        let html = `
            <h4>故障統計</h4>
            <p>總計故障: ${stats.total}</p>
            <p>已檢測: ${stats.detected}</p>
            <p>未檢測: ${stats.undetected}</p>
            <p>覆蓋率: <strong>${stats.coverage}%</strong></p>
            <p>存取次數: ${stats.accessCount}</p>
            <p>映射類型: ${stats.mappingType}</p>
        `;

        if (details.length > 0) {
            html += '<h4>故障詳情</h4><ul>';
            details.forEach(fault => {
                const status = fault.detected ? '已檢測' : '未檢測';
                const statusClass = fault.detected ? 'success' : 'error';
                html += `
                    <li>
                        <strong>${fault.id}</strong><br>
                        <small>邏輯: ${fault.logicalLocation}</small><br>
                        <small>物理: ${fault.physicalLocation}</small><br>
                        <span class="${statusClass}">${status}</span>
                    </li>
                `;
            });
            html += '</ul>';
        }

        this.elements.analysisResults.innerHTML = html;
    }

    /**
     * 記錄日誌
     */
    log(source, message, type = 'info') {
        const logEntry = document.createElement('div');
        logEntry.className = `log-entry log-${type}`;
        
        const timestamp = new Date().toLocaleTimeString();
        const stepNumber = this.simulator.currentStep;
        logEntry.innerHTML = `<span style="color: #666;">[Step ${stepNumber}] [${timestamp}]</span> <strong>[${source}]</strong> ${message}`;
        
        this.elements.executionLog.appendChild(logEntry);
        this.elements.executionLog.scrollTop = this.elements.executionLog.scrollHeight;
    }

    /**
     * 獲取當前日誌項目
     */
    getLogEntries() {
        const entries = [];
        const logEntries = this.elements.executionLog.querySelectorAll('.log-entry');
        logEntries.forEach(entry => {
            entries.push({
                className: entry.className,
                innerHTML: entry.innerHTML
            });
        });
        return entries;
    }

    /**
     * 恢復日誌項目
     */
    restoreLogEntries(logEntries) {
        // 清空現有日誌
        this.elements.executionLog.innerHTML = '';
        
        // 恢復日誌項目
        logEntries.forEach(entry => {
            const logEntry = document.createElement('div');
            logEntry.className = entry.className;
            logEntry.innerHTML = entry.innerHTML;
            this.elements.executionLog.appendChild(logEntry);
        });
        
        this.elements.executionLog.scrollTop = this.elements.executionLog.scrollHeight;
    }

    /**
     * 清空日誌
     */
    clearLog() {
        this.elements.executionLog.innerHTML = '';
    }

    /**
     * 獲取選定的演算法
     */
    getSelectedAlgorithm() {
        return this.elements.algorithmSelect.value;
    }

    /**
     * 獲取執行延遲
     */
    getExecutionDelay() {
        return this.elements.execDelay.value;
    }

    /**
     * 獲取範圍模式
     */
    getRangeMode() {
        return this.elements.rangeMode.value;
    }

    /**
     * 獲取位址範圍
     */
    getAddressRange() {
        return {
            start: parseInt(this.elements.startAddr.value) || null,
            end: parseInt(this.elements.endAddr.value) || null
        };
    }

    /**
     * 更新演算法選擇
     */
    updateAlgorithmSelect() {
        const algorithms = this.simulator.algorithms.getAllAlgorithms();
        
        this.elements.algorithmSelect.innerHTML = '';
        
        Object.keys(algorithms).forEach(name => {
            const option = document.createElement('option');
            option.value = name;
            option.textContent = name;
            this.elements.algorithmSelect.appendChild(option);
        });
    }

    /**
     * 下載檔案
     */
    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
    }
}

// 匯出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = BitMappingUIController;
}