/**
 * 記憶體模型 - 改進版
 * 支援多種故障類型和更準確的物理模擬
 */

class MemoryModel {
    constructor(addressCount, dataWidth) {
        this.addressCount = addressCount;
        this.dataWidth = dataWidth;
        this.allOnesValue = (1 << dataWidth) - 1;
        this.cells = new Array(addressCount).fill(0);
        this.faults = [];
        this.transitionHistory = new Map(); // 記錄轉換歷史用於 transition fault
        this.accessCount = 0;
    }

    /**
     * 重置記憶體狀態
     */
    reset() {
        this.cells.fill(0);
        this.faults.forEach(f => f.detected = false);
        this.transitionHistory.clear();
        this.accessCount = 0;
    }

    /**
     * 清除所有故障
     */
    clearFaults() {
        this.faults = [];
        this.transitionHistory.clear();
    }

    /**
     * 位元操作輔助方法
     */
    _getBit(addr, bit) {
        return (this.cells[addr] >> bit) & 1;
    }

    _setBit(addr, bit, val) {
        if (val) {
            this.cells[addr] |= (1 << bit);
        } else {
            this.cells[addr] &= ~(1 << bit);
        }
    }

    _getBitString(addr, bit) {
        return `A${addr}B${bit}`;
    }

    /**
     * 注入故障 - 改進版
     */
    injectFault(faultInfo) {
        // 驗證故障參數
        if (!this._validateFaultParams(faultInfo)) {
            throw new Error('無效的故障參數');
        }

        let faultId;
        
        // 根據故障類型生成ID
        if (faultInfo.type.startsWith('BF_')) {
            const p1 = this._getBitString(faultInfo.addr1, faultInfo.bit1);
            const p2 = this._getBitString(faultInfo.addr2, faultInfo.bit2);
            faultId = `${faultInfo.type}-${[p1, p2].sort().join('-')}`;
        } else {
            faultId = `${faultInfo.type}-${this._getBitString(faultInfo.addr1, faultInfo.bit1)}`;
        }

        // 檢查是否已存在相同故障
        if (this.faults.some(f => f.id === faultId)) {
            throw new Error('故障已存在');
        }

        // 添加故障
        const fault = {
            id: faultId,
            detected: false,
            detectionCount: 0,
            ...faultInfo
        };

        this.faults.push(fault);
        return fault;
    }

    /**
     * 驗證故障參數
     */
    _validateFaultParams(faultInfo) {
        const { type, addr1, bit1, addr2, bit2 } = faultInfo;
        
        // 檢查基本參數
        if (addr1 < 0 || addr1 >= this.addressCount || 
            bit1 < 0 || bit1 >= this.dataWidth) {
            return false;
        }

        // 檢查bridging fault的第二組參數
        if (type.startsWith('BF_')) {
            if (addr2 < 0 || addr2 >= this.addressCount || 
                bit2 < 0 || bit2 >= this.dataWidth) {
                return false;
            }
            // 不能是同一個位元
            if (addr1 === addr2 && bit1 === bit2) {
                return false;
            }
        }

        return true;
    }

    /**
     * 讀取記憶體 - 改進版
     */
    read(address) {
        this.accessCount++;
        
        let finalWord = 0;
        for (let i = 0; i < this.dataWidth; i++) {
            if (this._readBit(address, i)) {
                finalWord |= (1 << i);
            }
        }
        
        return finalWord;
    }

    /**
     * 位元讀取 - 處理各種故障類型
     */
    _readBit(addr, bit, visited = new Set()) {
        const currentCellID = this._getBitString(addr, bit);
        
        // 防止無限迴圈
        if (visited.has(currentCellID)) {
            return 0;
        }
        visited.add(currentCellID);

        // 檢查 Bridging fault (Output-Input)
        const outInFault = this.faults.find(f => 
            f.type === 'BF_OutIn' && f.addr2 === addr && f.bit2 === bit
        );
        if (outInFault) {
            // 受害者的輸出被攻擊者的輸出影響
            return this._readBit(outInFault.addr1, outInFault.bit1, visited);
        }

        // 檢查 Bridging fault (Output-Output)
        const outOutFault = this.faults.find(f => 
            f.type === 'BF_OutOut' && 
            ((f.addr1 === addr && f.bit1 === bit) || (f.addr2 === addr && f.bit2 === bit))
        );
        if (outOutFault) {
            const isParticipant1 = (f) => f.addr1 === addr && f.bit1 === bit;
            const otherAddr = isParticipant1(outOutFault) ? outOutFault.addr2 : outOutFault.addr1;
            const otherBit = isParticipant1(outOutFault) ? outOutFault.bit2 : outOutFault.bit1;
            
            const ownOutput = this._getOwnOutput(addr, bit);
            const otherOutput = this._getOwnOutput(otherAddr, otherBit);
            
            // 改進：使用更真實的bridging行為 (wired-AND)
            return ownOutput & otherOutput;
        }

        // 檢查 Transition fault
        const transitionFault = this.faults.find(f => 
            (f.type === 'TF_0to1' || f.type === 'TF_1to0') && 
            f.addr1 === addr && f.bit1 === bit
        );
        if (transitionFault) {
            const historyKey = `${addr}_${bit}`;
            const lastValue = this.transitionHistory.get(historyKey) || 0;
            const currentValue = this._getOwnOutput(addr, bit);
            
            // 如果發生了故障類型對應的轉換，則故障生效
            if ((transitionFault.type === 'TF_0to1' && lastValue === 0 && currentValue === 1) ||
                (transitionFault.type === 'TF_1to0' && lastValue === 1 && currentValue === 0)) {
                return lastValue; // 保持舊值，模擬轉換失敗
            }
        }

        return this._getOwnOutput(addr, bit);
    }

    /**
     * 獲取位元的原始輸出（不考慮bridging）
     */
    _getOwnOutput(addr, bit) {
        const storedBit = this._getBit(addr, bit);
        
        // 檢查 Stuck-at fault
        const stuckFault = this.faults.find(f => 
            (f.type === 'SA0' || f.type === 'SA1') && 
            f.addr1 === addr && f.bit1 === bit
        );
        
        if (stuckFault) {
            return stuckFault.type === 'SA1' ? 1 : 0;
        }
        
        return storedBit;
    }

    /**
     * 寫入記憶體 - 改進版
     */
    write(address, value) {
        this.accessCount++;
        
        for (let i = 0; i < this.dataWidth; i++) {
            const bitToWrite = (value >> i) & 1;
            
            // 記錄轉換歷史
            const historyKey = `${address}_${i}`;
            const oldValue = this._getBit(address, i);
            this.transitionHistory.set(historyKey, oldValue);
            
            this._writeBit(address, i, bitToWrite);
            
            // 處理 Bridging fault (Input-Input)
            const inInFault = this.faults.find(f => 
                f.type === 'BF_InIn' && 
                ((f.addr1 === address && f.bit1 === i) || (f.addr2 === address && f.bit2 === i))
            );
            
            if (inInFault) {
                // 確定哪一個是攻擊者，哪一個是受害者
                const isAggressor = (f) => f.addr1 === address && f.bit1 === i;
                const victimAddr = isAggressor(inInFault) ? inInFault.addr2 : inInFault.addr1;
                const victimBit = isAggressor(inInFault) ? inInFault.bit2 : inInFault.bit1;
                
                // 受害者也被寫入相同的值
                this._writeBit(victimAddr, victimBit, bitToWrite);
            }
        }
    }

    /**
     * 位元寫入 - 處理寫入相關故障
     */
    _writeBit(addr, bit, val) {
        // 檢查是否受到 Output-Input bridging fault 影響
        const outInVictim = this.faults.find(f => 
            f.type === 'BF_OutIn' && f.addr2 === addr && f.bit2 === bit
        );
        if (outInVictim) {
            return; // 被攻擊者控制，無法寫入
        }

        // 檢查是否有 Stuck-at fault
        const stuckFault = this.faults.find(f => 
            (f.type === 'SA0' || f.type === 'SA1') && 
            f.addr1 === addr && f.bit1 === bit
        );
        if (stuckFault) {
            return; // stuck-at fault 阻止寫入
        }

        // 檢查 Transition fault
        const transitionFault = this.faults.find(f => 
            (f.type === 'TF_0to1' || f.type === 'TF_1to0') && 
            f.addr1 === addr && f.bit1 === bit
        );
        if (transitionFault) {
            const oldValue = this._getBit(addr, bit);
            // 如果嘗試進行故障類型對應的轉換，則阻止寫入
            if ((transitionFault.type === 'TF_0to1' && oldValue === 0 && val === 1) ||
                (transitionFault.type === 'TF_1to0' && oldValue === 1 && val === 0)) {
                return; // 轉換失敗
            }
        }

        // 正常寫入
        this._setBit(addr, bit, val);
    }

    /**
     * 故障檢測 - 改進版
     */
    detectFaults(addr, expectedVal, actualVal) {
        const changedBits = expectedVal ^ actualVal;
        const detectedFaults = [];
        
        for (let i = 0; i < this.dataWidth; i++) {
            if ((changedBits >> i) & 1) {
                // 找出影響此位元的故障
                const affectedFaults = this.faults.filter(fault => {
                    if (fault.detected) return false;
                    
                    return (fault.addr1 === addr && fault.bit1 === i) || 
                           (fault.addr2 === addr && fault.bit2 === i);
                });
                
                affectedFaults.forEach(fault => {
                    if (!fault.detected) {
                        fault.detected = true;
                        fault.detectionCount++;
                        detectedFaults.push(fault);
                    }
                });
            }
        }
        
        return detectedFaults;
    }

    /**
     * 獲取故障統計資訊
     */
    getFaultStatistics() {
        const total = this.faults.length;
        const detected = this.faults.filter(f => f.detected).length;
        const coverage = total > 0 ? (detected / total) * 100 : 0;
        
        return {
            total,
            detected,
            undetected: total - detected,
            coverage: coverage.toFixed(2),
            accessCount: this.accessCount
        };
    }

    /**
     * 獲取故障詳細資訊
     */
    getFaultDetails() {
        return this.faults.map(fault => ({
            id: fault.id,
            type: fault.type,
            location: fault.type.startsWith('BF_') ? 
                `${fault.addr1},${fault.bit1} ↔ ${fault.addr2},${fault.bit2}` :
                `${fault.addr1},${fault.bit1}`,
            detected: fault.detected,
            detectionCount: fault.detectionCount
        }));
    }

    /**
     * 匯出記憶體狀態
     */
    exportState() {
        return {
            addressCount: this.addressCount,
            dataWidth: this.dataWidth,
            cells: [...this.cells],
            faults: this.faults.map(f => ({...f})),
            statistics: this.getFaultStatistics(),
            timestamp: new Date().toISOString()
        };
    }
}

// 如果在 Node.js 環境中，匯出模組
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MemoryModel;
}