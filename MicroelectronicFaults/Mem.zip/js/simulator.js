/**
 * 記憶體故障模擬器主控制器
 */

class MemoryFaultSimulator {
    constructor() {
        this.memory = null;
        this.algorithms = new MemoryAlgorithms();
        this.ui = null;
        this.executionEngine = null;
        this.executionHistory = [];
        this.currentStep = 0;
        this.isRunning = false;
        this.isPaused = false;
        this.executionDelay = 100;
    }

    /**
     * 初始化模擬器
     */
    init() {
        this.ui = new UIController(this);
        this.executionEngine = new ExecutionEngine(this);
        
        // 創建預設記憶體
        this.setMemorySize(8, 4);
        
        // 載入演算法到UI
        this.ui.updateAlgorithmSelect();
        this.ui.loadSelectedAlgorithm();
        
        // 初始化顯示
        this.ui.updateDisplay();
        
        console.log('記憶體故障模擬器已初始化');
    }

    /**
     * 設定記憶體大小
     */
    setMemorySize(addressCount, dataWidth) {
        if (this.isRunning) {
            throw new Error('執行中無法變更記憶體大小');
        }

        this.memory = new MemoryModel(addressCount, dataWidth);
        this.resetExecution();
        this.ui.log('系統', `記憶體大小設定為 ${addressCount} 位址 × ${dataWidth} 位元`, 'info');
    }

    /**
     * 注入故障
     */
    injectFault(faultInfo) {
        if (this.isRunning) {
            throw new Error('執行中無法注入故障');
        }

        return this.memory.injectFault(faultInfo);
    }

    /**
     * 清除故障
     */
    clearFaults() {
        if (this.isRunning) {
            throw new Error('執行中無法清除故障');
        }

        this.memory.clearFaults();
    }

    /**
     * 自動執行演算法
     */
    runAuto() {
        if (this.isRunning) {
            throw new Error('已在執行中');
        }

        this.prepareExecution();
        this.isRunning = true;
        this.isPaused = false;
        
        this.ui.updateState({
            isRunning: true,
            isPaused: false
        });

        this.ui.log('系統', '開始自動執行', 'info');
        this.autoExecutionLoop();
    }

    /**
     * 單步執行模式
     */
    runStep() {
        if (this.isRunning) {
            throw new Error('已在執行中');
        }

        this.prepareExecution();
        this.isRunning = true;
        this.isPaused = true;
        
        this.ui.updateState({
            isRunning: true,
            isPaused: true
        });

        this.ui.log('系統', '進入單步執行模式', 'info');
    }

    /**
     * 執行下一步
     */
    nextStep() {
        if (!this.isPaused) {
            throw new Error('不在單步模式中');
        }

        return this.executionEngine.executeNextStep();
    }

    /**
     * 跳轉到指定步驟
     */
    goToStep(step) {
        if (this.isRunning && !this.isPaused) {
            throw new Error('自動執行中無法跳轉');
        }

        if (step < 0 || step >= this.executionHistory.length) {
            throw new Error('無效的步驟編號');
        }

        this.currentStep = step;
        this.restoreState(step);
        this.ui.updateState({ currentStep: step });
    }

    /**
     * 準備執行
     */
    prepareExecution() {
        if (!this.memory) {
            throw new Error('請先設定記憶體大小');
        }

        const algorithmName = this.ui.elements.algorithmSelect.value;
        const algorithmCode = this.ui.elements.algorithmCode.value;
        
        if (!algorithmCode.trim()) {
            throw new Error('請選擇演算法');
        }

        // 獲取測試範圍
        const range = this.getTestRange();
        
        // 重置執行狀態
        this.resetExecution();
        
        // 準備執行引擎
        this.executionEngine.prepare(algorithmCode, range);
        
        // 設定執行延遲
        this.executionDelay = parseInt(this.ui.elements.opDelay.value) || 100;
        
        this.ui.log('系統', `準備執行演算法: ${algorithmName}`, 'info');
        this.ui.log('系統', `測試範圍: 位址 ${range.startAddr}-${range.endAddr}, 位元 ${range.startBit}-${range.endBit}`, 'info');
    }

    /**
     * 獲取測試範圍
     */
    getTestRange() {
        const rangeMode = this.ui.elements.rangeModeSelect.value;
        let startAddr = 0, endAddr = this.memory.addressCount - 1;
        let startBit = 0, endBit = this.memory.dataWidth - 1;

        if (rangeMode === 'addr' || rangeMode === 'bit') {
            const startAddrValue = parseInt(this.ui.elements.startAddr.value);
            const endAddrValue = parseInt(this.ui.elements.endAddr.value);
            
            if (!isNaN(startAddrValue) && !isNaN(endAddrValue)) {
                startAddr = Math.max(0, Math.min(startAddrValue, this.memory.addressCount - 1));
                endAddr = Math.max(startAddr, Math.min(endAddrValue, this.memory.addressCount - 1));
            }
        }

        if (rangeMode === 'bit') {
            const startBitValue = parseInt(this.ui.elements.startBit.value);
            const endBitValue = parseInt(this.ui.elements.endBit.value);
            
            if (!isNaN(startBitValue) && !isNaN(endBitValue)) {
                startBit = Math.max(0, Math.min(startBitValue, this.memory.dataWidth - 1));
                endBit = Math.max(startBit, Math.min(endBitValue, this.memory.dataWidth - 1));
            }
        }

        return { startAddr, endAddr, startBit, endBit };
    }

    /**
     * 自動執行循環
     */
    autoExecutionLoop() {
        if (!this.isRunning || this.isPaused) return;

        const result = this.executionEngine.executeNextStep();
        
        if (result.done) {
            this.finishExecution();
        } else {
            setTimeout(() => this.autoExecutionLoop(), this.executionDelay);
        }
    }

    /**
     * 完成執行
     */
    finishExecution() {
        this.isRunning = false;
        this.isPaused = false;
        
        this.ui.updateState({
            isRunning: false,
            isPaused: false
        });

        this.ui.log('系統', '演算法執行完成', 'info');
        this.analyzeResults();
        this.ui.updateDisplay();
    }

    /**
     * 分析結果
     */
    analyzeResults() {
        const stats = this.memory.getFaultStatistics();
        const details = this.memory.getFaultDetails();
        
        this.ui.log('系統', `故障檢測完成 - 覆蓋率: ${stats.coverage}%`, 'info');
        
        if (stats.total > 0) {
            this.ui.log('分析', `總故障: ${stats.total}, 已檢測: ${stats.detected}, 未檢測: ${stats.undetected}`, 'info');
            
            // 記錄未檢測的故障
            const undetectedFaults = details.filter(f => !f.detected);
            if (undetectedFaults.length > 0) {
                this.ui.log('警告', `未檢測故障: ${undetectedFaults.map(f => f.id).join(', ')}`, 'fail');
            }
        }
    }

    /**
     * 重置執行狀態
     */
    resetExecution() {
        this.isRunning = false;
        this.isPaused = false;
        this.currentStep = 0;
        this.executionHistory = [];
        
        if (this.memory) {
            this.memory.reset();
            this.saveState();
        }
        
        this.ui.updateState({
            isRunning: false,
            isPaused: false,
            currentStep: 0,
            totalSteps: 1
        });
    }

    /**
     * 保存當前狀態
     */
    saveState() {
        const state = {
            step: this.currentStep,
            memoryState: this.memory ? [...this.memory.cells] : [],
            activeAddress: this.executionEngine ? this.executionEngine.activeAddress : null,
            logEntries: []
        };
        
        this.executionHistory.push(state);
        this.ui.updateState({ totalSteps: this.executionHistory.length });
    }

    /**
     * 恢復狀態
     */
    restoreState(step) {
        if (step >= this.executionHistory.length) return;
        
        const state = this.executionHistory[step];
        
        if (this.memory && state.memoryState) {
            this.memory.cells = [...state.memoryState];
        }
        
        if (this.executionEngine) {
            this.executionEngine.activeAddress = state.activeAddress;
        }
        
        this.currentStep = step;
    }

    /**
     * 獲取當前活動位址
     */
    getCurrentActiveAddress() {
        return this.executionEngine ? this.executionEngine.activeAddress : null;
    }

    /**
     * 停止執行
     */
    stop() {
        if (this.isRunning) {
            this.isRunning = false;
            this.isPaused = false;
            
            this.ui.updateState({
                isRunning: false,
                isPaused: false
            });
            
            this.ui.log('系統', '執行已停止', 'info');
        }
    }
}

/**
 * 執行引擎 - 負責執行演算法程式碼
 */
class ExecutionEngine {
    constructor(simulator) {
        this.simulator = simulator;
        this.generator = null;
        this.activeAddress = null;
        this.memoryAPI = null;
    }

    /**
     * 準備執行
     */
    prepare(algorithmCode, range) {
        this.activeAddress = null;
        this.memoryAPI = this.createMemoryAPI();
        
        try {
            // 創建生成器函數
            const GeneratorFunction = Object.getPrototypeOf(function*(){}).constructor;
            const algorithmFunction = new GeneratorFunction(
                'mem', 'log', 'startAddr', 'endAddr', 'startBit', 'endBit',
                algorithmCode
            );
            
            // 創建執行生成器
            this.generator = algorithmFunction(
                this.memoryAPI,
                (message) => this.simulator.ui.log('演算法', message, 'info'),
                range.startAddr,
                range.endAddr,
                range.startBit,
                range.endBit
            );
            
        } catch (error) {
            throw new Error(`演算法編譯失敗: ${error.message}`);
        }
    }

    /**
     * 執行下一步
     */
    executeNextStep() {
        if (!this.generator) {
            return { done: true };
        }

        try {
            const result = this.generator.next();
            
            if (result.done) {
                return { done: true };
            }

            const { addr, logEntry } = result.value;
            
            // 更新活動位址
            this.activeAddress = addr;
            
            // 記錄日誌
            if (logEntry) {
                this.simulator.ui.log(logEntry.op, logEntry.msg, logEntry.type);
            }
            
            // 保存狀態
            this.simulator.saveState();
            
            // 更新顯示
            this.simulator.ui.updateDisplay();
            
            return { done: false };
            
        } catch (error) {
            this.simulator.ui.log('錯誤', `執行錯誤: ${error.message}`, 'fail');
            return { done: true };
        }
    }

    /**
     * 創建記憶體API
     */
    createMemoryAPI() {
        return {
            size: () => this.simulator.memory.addressCount,
            allOnes: () => this.simulator.memory.allOnesValue,
            dataWidth: () => this.simulator.memory.dataWidth,
            
            write: function* (addr, value) {
                const logEntry = {
                    op: 'WRITE',
                    msg: `寫入 ${value.toString(2).padStart(this.simulator.memory.dataWidth, '0')} 到位址 ${addr}`,
                    type: 'ok'
                };
                
                yield { addr, logEntry };
                
                this.simulator.memory.write(addr, value);
            }.bind(this),
            
            readAndCheck: function* (addr, expectedValue) {
                const actualValue = this.simulator.memory.read(addr);
                const expectedStr = expectedValue.toString(2).padStart(this.simulator.memory.dataWidth, '0');
                const actualStr = actualValue.toString(2).padStart(this.simulator.memory.dataWidth, '0');
                
                let message = `讀取位址 ${addr}: 預期 ${expectedStr}, 實際 ${actualStr}`;
                let logType = 'ok';
                
                if (actualValue !== expectedValue) {
                    message += ' → 偵測到故障！';
                    logType = 'fail';
                    
                    // 標記故障為已檢測
                    const detectedFaults = this.simulator.memory.detectFaults(addr, expectedValue, actualValue);
                    detectedFaults.forEach(fault => {
                        this.simulator.ui.log('檢測', `故障 ${fault.id} 已被檢測`, 'fail');
                    });
                }
                
                const logEntry = { op: 'READ', msg: message, type: logType };
                yield { addr, logEntry };
                
                return actualValue;
            }.bind(this)
        };
    }
}

// 如果在 Node.js 環境中，匯出模組
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MemoryFaultSimulator, ExecutionEngine };
}