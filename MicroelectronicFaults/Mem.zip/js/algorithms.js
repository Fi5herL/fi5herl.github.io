/**
 * 記憶體測試演算法庫 - 修正版
 * 包含各種標準記憶體測試演算法的正確實現
 */

class MemoryAlgorithms {
    constructor() {
        this.algorithms = this._loadDefaultAlgorithms();
        this.customAlgorithms = this._loadCustomAlgorithms();
    }

    /**
     * 載入預設演算法
     */
    _loadDefaultAlgorithms() {
        return {
            "Write/Read 0x00": this._generateBasicPattern(0, "Write/Read 0x00"),
            "Write/Read 0xFF": this._generateBasicPattern('ALL_ONES', "Write/Read 0xFF"),
            "Write/Read 0x55": this._generateBasicPattern('PATTERN_55', "Write/Read 0x55"),
            "Write/Read 0xAA": this._generateBasicPattern('PATTERN_AA', "Write/Read 0xAA"),
            "March C- (Word)": this._generateMarchCMinus(false),
            "March C- (Bit)": this._generateMarchCMinus(true),
            "March C (Word)": this._generateMarchC(false),
            "March C (Bit)": this._generateMarchC(true),
            "Checkerboard": this._generateCheckerboard(),
            "Walkpat (Word)": this._generateWalkingPattern(false),
            "Walkpat (Bit)": this._generateWalkingPattern(true),
            "Galpat (Word)": this._generateGallopingPattern(false),
            "Galpat (Bit)": this._generateGallopingPattern(true)
        };
    }

    /**
     * 載入自訂演算法
     */
    _loadCustomAlgorithms() {
        try {
            const stored = localStorage.getItem('customMemoryAlgorithms');
            return stored ? JSON.parse(stored) : {};
        } catch (error) {
            console.warn('載入自訂演算法失敗:', error);
            return {};
        }
    }

    /**
     * 儲存自訂演算法
     */
    saveCustomAlgorithms() {
        try {
            localStorage.setItem('customMemoryAlgorithms', JSON.stringify(this.customAlgorithms));
        } catch (error) {
            console.error('儲存自訂演算法失敗:', error);
        }
    }

    /**
     * 生成基本模式測試
     */
    _generateBasicPattern(pattern, name) {
        return `// ${name} 演算法
log('執行 ${name} 測試...');

let testPattern;
if ('${pattern}' === 'ALL_ONES') {
    testPattern = mem.allOnes();
} else if ('${pattern}' === 'PATTERN_55') {
    // 生成 0x55 模式 (0101...)
    testPattern = 0;
    for (let i = 0; i < mem.dataWidth(); i += 2) {
        testPattern |= (1 << i);
    }
} else if ('${pattern}' === 'PATTERN_AA') {
    // 生成 0xAA 模式 (1010...)
    testPattern = 0;
    for (let i = 1; i < mem.dataWidth(); i += 2) {
        testPattern |= (1 << i);
    }
} else {
    testPattern = ${pattern};
}

// 階段 1: 寫入測試模式
log('階段 1: 寫入測試模式');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.write(i, testPattern);
}

// 階段 2: 讀取並驗證
log('階段 2: 讀取並驗證');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.readAndCheck(i, testPattern);
}

log('${name} 測試完成');`;
    }

    /**
     * 生成 March C- 演算法（修正版）
     */
    _generateMarchCMinus(isBitOriented) {
        if (isBitOriented) {
            return `// March C- 演算法 (位元導向) - 修正版
log('執行 March C- 測試 (位元導向)...');

const ALL_ONES = mem.allOnes();

// 對每個位元進行測試
const startBit = 0;
const endBit = mem.dataWidth() - 1;
for (let k = startBit; k <= endBit; k++) {
    log(\`-- 測試位元 \${k} --\`);
    
    const testBit = (1 << k);           // 測試位元為 1
    const background = ALL_ONES ^ testBit; // 背景為其他位元全 1
    
    // M0: 寫入背景模式
    log('M0: 寫入背景模式');
    for (let i = startAddr; i <= endAddr; i++) {
        yield* mem.write(i, background);
    }
    
    // M1: 向上讀取背景，寫入測試位元
    log('M1: 向上讀取背景，寫入測試位元');
    for (let i = startAddr; i <= endAddr; i++) {
        yield* mem.readAndCheck(i, background);
        yield* mem.write(i, testBit);
    }
    
    // M2: 向上讀取測試位元，寫入背景
    log('M2: 向上讀取測試位元，寫入背景');
    for (let i = startAddr; i <= endAddr; i++) {
        yield* mem.readAndCheck(i, testBit);
        yield* mem.write(i, background);
    }
    
    // M3: 向下讀取背景，寫入測試位元
    log('M3: 向下讀取背景，寫入測試位元');
    for (let i = endAddr; i >= startAddr; i--) {
        yield* mem.readAndCheck(i, background);
        yield* mem.write(i, testBit);
    }
    
    // M4: 向下讀取測試位元，寫入背景
    log('M4: 向下讀取測試位元，寫入背景');
    for (let i = endAddr; i >= startAddr; i--) {
        yield* mem.readAndCheck(i, testBit);
        yield* mem.write(i, background);
    }
    
    // M5: 向上讀取背景
    log('M5: 向上讀取背景');
    for (let i = startAddr; i <= endAddr; i++) {
        yield* mem.readAndCheck(i, background);
    }
}

log('March C- 測試完成');`;
        } else {
            return `// March C- 演算法 (字元導向) - 修正版
log('執行 March C- 測試 (字元導向)...');

const ALL_ONES = mem.allOnes();

// M0: 寫入背景模式 (0)
log('M0: 寫入背景模式');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.write(i, 0);
}

// M1: 向上讀取 0，寫入全 1
log('M1: 向上讀取 0，寫入全 1');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.readAndCheck(i, 0);
    yield* mem.write(i, ALL_ONES);
}

// M2: 向上讀取全 1，寫入 0
log('M2: 向上讀取全 1，寫入 0');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.readAndCheck(i, ALL_ONES);
    yield* mem.write(i, 0);
}

// M3: 向下讀取 0，寫入全 1
log('M3: 向下讀取 0，寫入全 1');
for (let i = endAddr; i >= startAddr; i--) {
    yield* mem.readAndCheck(i, 0);
    yield* mem.write(i, ALL_ONES);
}

// M4: 向下讀取全 1，寫入 0
log('M4: 向下讀取全 1，寫入 0');
for (let i = endAddr; i >= startAddr; i--) {
    yield* mem.readAndCheck(i, ALL_ONES);
    yield* mem.write(i, 0);
}

// M5: 向上讀取 0
log('M5: 向上讀取 0');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.readAndCheck(i, 0);
}

log('March C- 測試完成');`;
        }
    }

    /**
     * 生成 March C 演算法（修正版）
     */
    _generateMarchC(isBitOriented) {
        if (isBitOriented) {
            return `// March C 演算法 (位元導向) - 修正版
log('執行 March C 測試 (位元導向)...');

const ALL_ONES = mem.allOnes();

// 對每個位元進行測試
const startBit = 0;
const endBit = mem.dataWidth() - 1;
for (let k = startBit; k <= endBit; k++) {
    log(\`-- 測試位元 \${k} --\`);
    
    const testBit = (1 << k);           // 測試位元為 1
    const background = ALL_ONES ^ testBit; // 背景為其他位元全 1
    
    // M0: 寫入測試位元
    log('M0: 寫入測試位元');
    for (let i = startAddr; i <= endAddr; i++) {
        yield* mem.write(i, testBit);
    }
    
    // M1: 向上讀取測試位元，寫入背景
    log('M1: 向上讀取測試位元，寫入背景');
    for (let i = startAddr; i <= endAddr; i++) {
        yield* mem.readAndCheck(i, testBit);
        yield* mem.write(i, background);
    }
    
    // M2: 向上讀取背景，寫入測試位元
    log('M2: 向上讀取背景，寫入測試位元');
    for (let i = startAddr; i <= endAddr; i++) {
        yield* mem.readAndCheck(i, background);
        yield* mem.write(i, testBit);
    }
    
    // M3: 向下讀取測試位元，寫入背景
    log('M3: 向下讀取測試位元，寫入背景');
    for (let i = endAddr; i >= startAddr; i--) {
        yield* mem.readAndCheck(i, testBit);
        yield* mem.write(i, background);
    }
    
    // M4: 向下讀取背景，寫入測試位元
    log('M4: 向下讀取背景，寫入測試位元');
    for (let i = endAddr; i >= startAddr; i--) {
        yield* mem.readAndCheck(i, background);
        yield* mem.write(i, testBit);
    }
    
    // M5: 向上讀取測試位元
    log('M5: 向上讀取測試位元');
    for (let i = startAddr; i <= endAddr; i++) {
        yield* mem.readAndCheck(i, testBit);
    }
}

log('March C 測試完成');`;
        } else {
            return `// March C 演算法 (字元導向) - 修正版
log('執行 March C 測試 (字元導向)...');

const ALL_ONES = mem.allOnes();

// M0: 寫入 0
log('M0: 寫入 0');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.write(i, 0);
}

// M1: 向上讀取 0，寫入全 1
log('M1: 向上讀取 0，寫入全 1');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.readAndCheck(i, 0);
    yield* mem.write(i, ALL_ONES);
}

// M2: 向上讀取全 1，寫入 0
log('M2: 向上讀取全 1，寫入 0');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.readAndCheck(i, ALL_ONES);
    yield* mem.write(i, 0);
}

// M3: 向下讀取 0，寫入全 1
log('M3: 向下讀取 0，寫入全 1');
for (let i = endAddr; i >= startAddr; i--) {
    yield* mem.readAndCheck(i, 0);
    yield* mem.write(i, ALL_ONES);
}

// M4: 向下讀取全 1，寫入 0
log('M4: 向下讀取全 1，寫入 0');
for (let i = endAddr; i >= startAddr; i--) {
    yield* mem.readAndCheck(i, ALL_ONES);
    yield* mem.write(i, 0);
}

// M5: 向上讀取 0
log('M5: 向上讀取 0');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.readAndCheck(i, 0);
}

log('March C 測試完成');`;
        }
    }

    /**
     * 生成棋盤模式演算法（修正版）
     */
    _generateCheckerboard() {
        return `// Checkerboard 演算法 - 修正版
log('執行 Checkerboard 測試...');

const ALL_ONES = mem.allOnes();

// 生成棋盤模式
// 偶數位址: 0x55 (01010101...)
// 奇數位址: 0xAA (10101010...)
let pattern1 = 0; // 0x55 模式
let pattern2 = 0; // 0xAA 模式

for (let i = 0; i < mem.dataWidth(); i++) {
    if (i % 2 === 0) {
        pattern1 |= (1 << i); // 偶數位元為 1
    } else {
        pattern2 |= (1 << i); // 奇數位元為 1
    }
}

// 確保模式在資料寬度範圍內
pattern1 &= ALL_ONES;
pattern2 &= ALL_ONES;

// 階段 1: 寫入棋盤模式
log('階段 1: 寫入棋盤模式');
for (let i = startAddr; i <= endAddr; i++) {
    const pattern = (i % 2 === 0) ? pattern1 : pattern2;
    yield* mem.write(i, pattern);
}

// 階段 2: 讀取並驗證棋盤模式
log('階段 2: 讀取並驗證棋盤模式');
for (let i = startAddr; i <= endAddr; i++) {
    const expectedPattern = (i % 2 === 0) ? pattern1 : pattern2;
    yield* mem.readAndCheck(i, expectedPattern);
}

// 階段 3: 寫入反向棋盤模式
log('階段 3: 寫入反向棋盤模式');
for (let i = startAddr; i <= endAddr; i++) {
    const pattern = (i % 2 === 0) ? pattern2 : pattern1;
    yield* mem.write(i, pattern);
}

// 階段 4: 讀取並驗證反向棋盤模式
log('階段 4: 讀取並驗證反向棋盤模式');
for (let i = startAddr; i <= endAddr; i++) {
    const expectedPattern = (i % 2 === 0) ? pattern2 : pattern1;
    yield* mem.readAndCheck(i, expectedPattern);
}

log('Checkerboard 測試完成');`;
    }

    /**
     * 生成行走模式演算法（修正版）
     */
    _generateWalkingPattern(isBitOriented) {
        if (isBitOriented) {
            return `// Walking Pattern 演算法 (位元導向) - 修正版
log('執行 Walking Pattern 測試 (位元導向)...');

// 清空所有記憶體
log('初始化: 清空所有記憶體');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.write(i, 0);
}

// 對每個位址的每個位元進行測試
const startBit = 0;
const endBit = mem.dataWidth() - 1;
for (let addr = startAddr; addr <= endAddr; addr++) {
    for (let bit = startBit; bit <= endBit; bit++) {
        log(\`-- 測試位址 \${addr} 位元 \${bit} --\`);
        
        const testPattern = (1 << bit);
        
        // 寫入測試位元
        yield* mem.write(addr, testPattern);
        
        // 讀取所有位址，驗證只有測試位址有測試位元
        for (let checkAddr = startAddr; checkAddr <= endAddr; checkAddr++) {
            const expected = (checkAddr === addr) ? testPattern : 0;
            yield* mem.readAndCheck(checkAddr, expected);
        }
        
        // 清除測試位元
        yield* mem.write(addr, 0);
    }
}

log('Walking Pattern 測試完成');`;
        } else {
            return `// Walking Pattern 演算法 (字元導向) - 修正版
log('執行 Walking Pattern 測試 (字元導向)...');

const ALL_ONES = mem.allOnes();

// 清空所有記憶體
log('初始化: 清空所有記憶體');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.write(i, 0);
}

// 對每個位址進行測試
for (let addr = startAddr; addr <= endAddr; addr++) {
    log(\`-- 測試位址 \${addr} --\`);
    
    // 寫入全 1 到測試位址
    yield* mem.write(addr, ALL_ONES);
    
    // 讀取所有位址，驗證只有測試位址有全 1
    for (let checkAddr = startAddr; checkAddr <= endAddr; checkAddr++) {
        const expected = (checkAddr === addr) ? ALL_ONES : 0;
        yield* mem.readAndCheck(checkAddr, expected);
    }
    
    // 清除測試位址
    yield* mem.write(addr, 0);
}

log('Walking Pattern 測試完成');`;
        }
    }

    /**
     * 生成奔騰模式演算法（修正版）
     */
    _generateGallopingPattern(isBitOriented) {
        if (isBitOriented) {
            return `// Galloping Pattern 演算法 (位元導向) - 修正版
log('執行 Galloping Pattern 測試 (位元導向)...');

// 對每個位址的每個位元進行測試
const startBit = 0;
const endBit = mem.dataWidth() - 1;
for (let baseAddr = startAddr; baseAddr <= endAddr; baseAddr++) {
    for (let baseBit = startBit; baseBit <= endBit; baseBit++) {
        log(\`-- 基準位址 \${baseAddr} 位元 \${baseBit} --\`);
        
        // 初始化: 所有位址寫入 0
        for (let i = startAddr; i <= endAddr; i++) {
            yield* mem.write(i, 0);
        }
        
        const testPattern = (1 << baseBit);
        
        // 寫入測試位元到基準位址
        yield* mem.write(baseAddr, testPattern);
        
        // 對所有其他位址的所有位元進行測試
        for (let testAddr = startAddr; testAddr <= endAddr; testAddr++) {
            for (let testBit = startBit; testBit <= endBit; testBit++) {
                // 跳過基準位址的基準位元
                if (testAddr === baseAddr && testBit === baseBit) continue;
                
                // 讀取測試位址（應該是 0）
                yield* mem.readAndCheck(testAddr, 0);
                
                // 讀取基準位址（應該還是測試位元）
                yield* mem.readAndCheck(baseAddr, testPattern);
            }
        }
    }
}

log('Galloping Pattern 測試完成');`;
        } else {
            return `// Galloping Pattern 演算法 (字元導向) - 修正版
log('執行 Galloping Pattern 測試 (字元導向)...');

const ALL_ONES = mem.allOnes();

// 初始化: 所有位址寫入 0
log('初始化: 所有位址寫入 0');
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.write(i, 0);
}

// 對每個位址進行測試
for (let baseAddr = startAddr; baseAddr <= endAddr; baseAddr++) {
    log(\`-- 基準位址 \${baseAddr} --\`);
    
    // 寫入全 1 到基準位址
    yield* mem.write(baseAddr, ALL_ONES);
    
    // 對所有其他位址進行測試
    for (let testAddr = startAddr; testAddr <= endAddr; testAddr++) {
        if (testAddr === baseAddr) continue;
        
        // 讀取測試位址（應該是 0）
        yield* mem.readAndCheck(testAddr, 0);
        
        // 讀取基準位址（應該還是全 1）
        yield* mem.readAndCheck(baseAddr, ALL_ONES);
    }
    
    // 清除基準位址
    yield* mem.write(baseAddr, 0);
}

log('Galloping Pattern 測試完成');`;
        }
    }

    /**
     * 獲取所有演算法
     */
    getAllAlgorithms() {
        return { ...this.algorithms, ...this.customAlgorithms };
    }

    /**
     * 獲取演算法程式碼
     */
    getAlgorithm(name) {
        return this.algorithms[name] || this.customAlgorithms[name] || '';
    }

    /**
     * 新增自訂演算法
     */
    addCustomAlgorithm(name, code) {
        if (!name || !code) {
            throw new Error('演算法名稱和程式碼不能為空');
        }
        
        if (this.algorithms[name]) {
            throw new Error('不能覆蓋預設演算法');
        }
        
        this.customAlgorithms[name] = code;
        this.saveCustomAlgorithms();
    }

    /**
     * 刪除自訂演算法
     */
    deleteCustomAlgorithm(name) {
        if (this.algorithms[name]) {
            throw new Error('不能刪除預設演算法');
        }
        
        delete this.customAlgorithms[name];
        this.saveCustomAlgorithms();
    }

    /**
     * 獲取演算法說明
     */
    getAlgorithmDescription(name) {
        const descriptions = {
            "Write/Read 0x00": "基本測試：寫入全0，然後讀取驗證。能檢測基本的stuck-at-1故障。",
            "Write/Read 0xFF": "基本測試：寫入全1，然後讀取驗證。能檢測基本的stuck-at-0故障。",
            "Write/Read 0x55": "基本測試：寫入0101模式，然後讀取驗證。能檢測某些bridging故障。",
            "Write/Read 0xAA": "基本測試：寫入1010模式，然後讀取驗證。能檢測某些bridging故障。",
            "March C- (Word)": "March C-演算法字元版本。能檢測stuck-at、transition、coupling等故障。測試複雜度：O(10n)。",
            "March C- (Bit)": "March C-演算法位元版本。對每個位元逐一測試，檢測能力更強。測試複雜度：O(10nw)。",
            "March C (Word)": "March C演算法字元版本。比March C-稍簡單，但檢測能力相當。測試複雜度：O(10n)。",
            "March C (Bit)": "March C演算法位元版本。對每個位元逐一測試。測試複雜度：O(10nw)。",
            "Checkerboard": "棋盤模式測試。在相鄰位址寫入互補的棋盤模式，能有效檢測位址解碼器故障。",
            "Walkpat (Word)": "行走模式測試字元版本。逐一測試每個位址，能檢測位址解碼器故障。",
            "Walkpat (Bit)": "行走模式測試位元版本。逐一測試每個位元，能檢測位址/資料解碼器故障。",
            "Galpat (Word)": "奔騰模式測試字元版本。對每個位址與其他所有位址進行互動測試，能檢測複雜的coupling故障。",
            "Galpat (Bit)": "奔騰模式測試位元版本。對每個位元與其他所有位元進行互動測試，檢測能力最強但時間複雜度高。"
        };
        
        return descriptions[name] || "自訂演算法";
    }

    /**
     * 獲取演算法建議使用範圍
     */
    getRecommendedRange(name) {
        const bitOrientedAlgorithms = [
            "March C- (Bit)", "March C (Bit)", 
            "Walkpat (Bit)", "Galpat (Bit)"
        ];
        
        return {
            supportsBitRange: bitOrientedAlgorithms.includes(name),
            supportsAddressRange: true,
            complexity: this._getComplexity(name)
        };
    }

    /**
     * 獲取演算法複雜度
     */
    _getComplexity(name) {
        const complexities = {
            "Write/Read 0x00": "O(2n)",
            "Write/Read 0xFF": "O(2n)",
            "Write/Read 0x55": "O(2n)",
            "Write/Read 0xAA": "O(2n)",
            "March C- (Word)": "O(10n)",
            "March C- (Bit)": "O(10nw)",
            "March C (Word)": "O(10n)",
            "March C (Bit)": "O(10nw)",
            "Checkerboard": "O(4n)",
            "Walkpat (Word)": "O(n²)",
            "Walkpat (Bit)": "O(n²w)",
            "Galpat (Word)": "O(n²)",
            "Galpat (Bit)": "O(n²w²)"
        };
        
        return complexities[name] || "O(n)";
    }
}

// 如果在 Node.js 環境中，匯出模組
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MemoryAlgorithms;
}