/**
 * 位元級映射記憶體模型
 * 支援每個位元的獨立映射
 */

class BitLevelMemoryModel {
    constructor(addressCount, dataWidth) {
        this.addressCount = addressCount;
        this.dataWidth = dataWidth;
        this.allOnesValue = (1 << dataWidth) - 1;
        this.cells = new Array(addressCount).fill(0);
        this.faults = [];
        this.transitionHistory = new Map();
        this.accessCount = 0;
        
        // 位元級映射: 邏輯位元 -> 物理位元
        this.bitMapping = new Map(); // key: "logicalAddr_logicalBit", value: "physicalAddr_physicalBit"
        this.reverseBitMapping = new Map(); // 反向映射
        this.bitMappingDescription = "恆等映射";
        
        // 初始化恆等映射
        this.initializeIdentityBitMapping();
    }

    /**
     * 初始化恆等位元映射
     */
    initializeIdentityBitMapping() {
        this.bitMapping.clear();
        this.reverseBitMapping.clear();
        
        for (let addr = 0; addr < this.addressCount; addr++) {
            for (let bit = 0; bit < this.dataWidth; bit++) {
                const logicalKey = `${addr}_${bit}`;
                const physicalKey = `${addr}_${bit}`;
                
                this.bitMapping.set(logicalKey, physicalKey);
                this.reverseBitMapping.set(physicalKey, logicalKey);
            }
        }
        
        this.bitMappingDescription = "恆等映射 (每個位元對應自己)";
    }

    /**
     * 設定位元級映射
     * @param {Object} mapping - 位元映射 {"logicalAddr_logicalBit": "physicalAddr_physicalBit"}
     * @param {string} description - 映射描述
     */
    setBitMapping(mapping, description = "自訂位元映射") {
        this.bitMapping.clear();
        this.reverseBitMapping.clear();
        
        // 處理不同的輸入格式
        if (typeof mapping === 'object') {
            for (const [logical, physical] of Object.entries(mapping)) {
                this.bitMapping.set(logical, physical);
                this.reverseBitMapping.set(physical, logical);
            }
        }
        
        // 驗證映射的有效性
        if (!this.validateBitMapping()) {
            throw new Error('無效的位元映射：必須是完整的一對一映射');
        }
        
        this.bitMappingDescription = description;
        this.clearFaults();
    }

    /**
     * 驗證位元映射是否有效
     */
    validateBitMapping() {
        const expectedBitCount = this.addressCount * this.dataWidth;
        
        // 檢查映射數量
        if (this.bitMapping.size !== expectedBitCount) {
            return false;
        }
        
        // 檢查是否為雙射
        const logicalBits = new Set();
        const physicalBits = new Set();
        
        for (const [logical, physical] of this.bitMapping.entries()) {
            // 檢查格式
            if (!this.isValidBitKey(logical) || !this.isValidBitKey(physical)) {
                return false;
            }
            
            // 檢查重複
            if (logicalBits.has(logical) || physicalBits.has(physical)) {
                return false;
            }
            
            logicalBits.add(logical);
            physicalBits.add(physical);
        }
        
        return logicalBits.size === expectedBitCount && physicalBits.size === expectedBitCount;
    }

    /**
     * 檢查位元鍵是否有效
     */
    isValidBitKey(key) {
        const parts = key.split('_');
        if (parts.length !== 2) return false;
        
        const addr = parseInt(parts[0]);
        const bit = parseInt(parts[1]);
        
        return !isNaN(addr) && !isNaN(bit) && 
               addr >= 0 && addr < this.addressCount &&
               bit >= 0 && bit < this.dataWidth;
    }

    /**
     * 邏輯位元到物理位元的映射
     */
    logicalBitToPhysical(logicalAddr, logicalBit) {
        const logicalKey = `${logicalAddr}_${logicalBit}`;
        const physicalKey = this.bitMapping.get(logicalKey);
        
        if (!physicalKey) {
            throw new Error(`無效的邏輯位元: ${logicalKey}`);
        }
        
        const parts = physicalKey.split('_');
        return {
            addr: parseInt(parts[0]),
            bit: parseInt(parts[1])
        };
    }

    /**
     * 物理位元到邏輯位元的映射
     */
    physicalBitToLogical(physicalAddr, physicalBit) {
        const physicalKey = `${physicalAddr}_${physicalBit}`;
        const logicalKey = this.reverseBitMapping.get(physicalKey);
        
        if (!logicalKey) {
            throw new Error(`無效的物理位元: ${physicalKey}`);
        }
        
        const parts = logicalKey.split('_');
        return {
            addr: parseInt(parts[0]),
            bit: parseInt(parts[1])
        };
    }

    /**
     * 獲取預設位元映射
     */
    getPresetBitMapping(type) {
        const mapping = {};
        
        switch (type) {
            case 'identity':
                for (let addr = 0; addr < this.addressCount; addr++) {
                    for (let bit = 0; bit < this.dataWidth; bit++) {
                        mapping[`${addr}_${bit}`] = `${addr}_${bit}`;
                    }
                }
                return { mapping, description: "恆等映射 (每個位元對應自己)" };
                
            case 'bit_reverse':
                // 位元順序反轉
                for (let addr = 0; addr < this.addressCount; addr++) {
                    for (let bit = 0; bit < this.dataWidth; bit++) {
                        const reversedBit = this.dataWidth - 1 - bit;
                        mapping[`${addr}_${bit}`] = `${addr}_${reversedBit}`;
                    }
                }
                return { mapping, description: "位元反轉映射 (LSB↔MSB)" };
                
            case 'addr_interleave':
                // 位址交錯，位元保持
                for (let addr = 0; addr < this.addressCount; addr++) {
                    for (let bit = 0; bit < this.dataWidth; bit++) {
                        const physicalAddr = addr % 2 === 0 ? addr / 2 : (addr - 1) / 2 + Math.floor(this.addressCount / 2);
                        mapping[`${addr}_${bit}`] = `${physicalAddr}_${bit}`;
                    }
                }
                return { mapping, description: "位址交錯映射 (位元保持)" };
                
            case 'bit_interleave':
                // 位元交錯
                for (let addr = 0; addr < this.addressCount; addr++) {
                    for (let bit = 0; bit < this.dataWidth; bit++) {
                        const physicalBit = bit % 2 === 0 ? bit / 2 : (bit - 1) / 2 + Math.floor(this.dataWidth / 2);
                        mapping[`${addr}_${bit}`] = `${addr}_${physicalBit}`;
                    }
                }
                return { mapping, description: "位元交錯映射 (偶數位元在前)" };
                
            case 'random':
                // 隨機映射
                const allLogicalBits = [];
                const allPhysicalBits = [];
                
                for (let addr = 0; addr < this.addressCount; addr++) {
                    for (let bit = 0; bit < this.dataWidth; bit++) {
                        allLogicalBits.push(`${addr}_${bit}`);
                        allPhysicalBits.push(`${addr}_${bit}`);
                    }
                }
                
                // 隨機打亂物理位元
                for (let i = allPhysicalBits.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [allPhysicalBits[i], allPhysicalBits[j]] = [allPhysicalBits[j], allPhysicalBits[i]];
                }
                
                for (let i = 0; i < allLogicalBits.length; i++) {
                    mapping[allLogicalBits[i]] = allPhysicalBits[i];
                }
                
                return { mapping, description: "隨機映射 (完全隨機排列)" };
                
            default:
                return this.getPresetBitMapping('identity');
        }
    }

    /**
     * 讀取記憶體（使用邏輯位址）
     */
    read(logicalAddress) {
        this.accessCount++;
        
        let finalWord = 0;
        for (let i = 0; i < this.dataWidth; i++) {
            if (this._readLogicalBit(logicalAddress, i)) {
                finalWord |= (1 << i);
            }
        }
        
        return finalWord;
    }

    /**
     * 讀取邏輯位元
     */
    _readLogicalBit(logicalAddr, logicalBit) {
        try {
            const physical = this.logicalBitToPhysical(logicalAddr, logicalBit);
            return this._readPhysicalBit(physical.addr, physical.bit);
        } catch (error) {
            console.error('讀取邏輯位元失敗:', error);
            return 0;
        }
    }

    /**
     * 讀取物理位元（處理故障）
     */
    _readPhysicalBit(physicalAddr, physicalBit, visited = new Set()) {
        const currentKey = `${physicalAddr}_${physicalBit}`;
        
        if (visited.has(currentKey)) {
            return 0;
        }
        visited.add(currentKey);

        // 檢查各種故障類型
        const stuckFault = this.faults.find(f => 
            (f.type === 'SA0' || f.type === 'SA1') && 
            f.physicalAddr1 === physicalAddr && f.physicalBit1 === physicalBit
        );
        
        if (stuckFault) {
            return stuckFault.type === 'SA1' ? 1 : 0;
        }

        // 檢查 Bridging fault (Output-Input)
        const outInFault = this.faults.find(f => 
            f.type === 'BF_OutIn' && 
            f.physicalAddr2 === physicalAddr && f.physicalBit2 === physicalBit
        );
        if (outInFault) {
            return this._readPhysicalBit(outInFault.physicalAddr1, outInFault.physicalBit1, visited);
        }

        // 檢查 Bridging fault (Output-Output)
        const outOutFault = this.faults.find(f => 
            f.type === 'BF_OutOut' && 
            ((f.physicalAddr1 === physicalAddr && f.physicalBit1 === physicalBit) || 
             (f.physicalAddr2 === physicalAddr && f.physicalBit2 === physicalBit))
        );
        if (outOutFault) {
            const isParticipant1 = (f) => f.physicalAddr1 === physicalAddr && f.physicalBit1 === physicalBit;
            const otherAddr = isParticipant1(outOutFault) ? outOutFault.physicalAddr2 : outOutFault.physicalAddr1;
            const otherBit = isParticipant1(outOutFault) ? outOutFault.physicalBit2 : outOutFault.physicalBit1;
            
            const ownOutput = this._getPhysicalBitValue(physicalAddr, physicalBit);
            const otherOutput = this._getPhysicalBitValue(otherAddr, otherBit);
            
            return ownOutput & otherOutput;
        }

        // 檢查 Transition fault
        const transitionFault = this.faults.find(f => 
            (f.type === 'TF_0to1' || f.type === 'TF_1to0') && 
            f.physicalAddr1 === physicalAddr && f.physicalBit1 === physicalBit
        );
        if (transitionFault) {
            const historyKey = `${physicalAddr}_${physicalBit}`;
            const lastValue = this.transitionHistory.get(historyKey) || 0;
            const currentValue = this._getPhysicalBitValue(physicalAddr, physicalBit);
            
            if ((transitionFault.type === 'TF_0to1' && lastValue === 0 && currentValue === 1) ||
                (transitionFault.type === 'TF_1to0' && lastValue === 1 && currentValue === 0)) {
                return lastValue;
            }
        }

        return this._getPhysicalBitValue(physicalAddr, physicalBit);
    }

    /**
     * 獲取物理位元值
     */
    _getPhysicalBitValue(physicalAddr, physicalBit) {
        return (this.cells[physicalAddr] >> physicalBit) & 1;
    }

    /**
     * 寫入記憶體（使用邏輯位址）
     */
    write(logicalAddress, value) {
        this.accessCount++;
        
        for (let i = 0; i < this.dataWidth; i++) {
            const bitToWrite = (value >> i) & 1;
            this._writeLogicalBit(logicalAddress, i, bitToWrite);
        }
    }

    /**
     * 寫入邏輯位元
     */
    _writeLogicalBit(logicalAddr, logicalBit, value) {
        try {
            const physical = this.logicalBitToPhysical(logicalAddr, logicalBit);
            this._writePhysicalBit(physical.addr, physical.bit, value);
        } catch (error) {
            console.error('寫入邏輯位元失敗:', error);
        }
    }

    /**
     * 寫入物理位元（處理故障）
     */
    _writePhysicalBit(physicalAddr, physicalBit, value) {
        // 記錄轉換歷史
        const historyKey = `${physicalAddr}_${physicalBit}`;
        const oldValue = this._getPhysicalBitValue(physicalAddr, physicalBit);
        this.transitionHistory.set(historyKey, oldValue);

        // 檢查故障
        const outInVictim = this.faults.find(f => 
            f.type === 'BF_OutIn' && 
            f.physicalAddr2 === physicalAddr && f.physicalBit2 === physicalBit
        );
        if (outInVictim) {
            return; // 被攻擊者控制，無法寫入
        }

        const stuckFault = this.faults.find(f => 
            (f.type === 'SA0' || f.type === 'SA1') && 
            f.physicalAddr1 === physicalAddr && f.physicalBit1 === physicalBit
        );
        if (stuckFault) {
            return; // stuck-at fault 阻止寫入
        }

        const transitionFault = this.faults.find(f => 
            (f.type === 'TF_0to1' || f.type === 'TF_1to0') && 
            f.physicalAddr1 === physicalAddr && f.physicalBit1 === physicalBit
        );
        if (transitionFault) {
            if ((transitionFault.type === 'TF_0to1' && oldValue === 0 && value === 1) ||
                (transitionFault.type === 'TF_1to0' && oldValue === 1 && value === 0)) {
                return; // 轉換失敗
            }
        }

        // 正常寫入
        if (value) {
            this.cells[physicalAddr] |= (1 << physicalBit);
        } else {
            this.cells[physicalAddr] &= ~(1 << physicalBit);
        }

        // 處理 Bridging fault (Input-Input)
        const inInFault = this.faults.find(f => 
            f.type === 'BF_InIn' && 
            ((f.physicalAddr1 === physicalAddr && f.physicalBit1 === physicalBit) || 
             (f.physicalAddr2 === physicalAddr && f.physicalBit2 === physicalBit))
        );
        
        if (inInFault) {
            const isAggressor = (f) => f.physicalAddr1 === physicalAddr && f.physicalBit1 === physicalBit;
            const victimAddr = isAggressor(inInFault) ? inInFault.physicalAddr2 : inInFault.physicalAddr1;
            const victimBit = isAggressor(inInFault) ? inInFault.physicalBit2 : inInFault.physicalBit1;
            
            // 受害者也被寫入相同的值
            if (value) {
                this.cells[victimAddr] |= (1 << victimBit);
            } else {
                this.cells[victimAddr] &= ~(1 << victimBit);
            }
        }
    }

    /**
     * 注入故障（支援位元級映射）
     */
    injectFault(faultInfo) {
        const { domain = 'logical' } = faultInfo;
        let processedFault = { ...faultInfo };
        
        // 處理位元級映射
        if (domain === 'logical') {
            const physical1 = this.logicalBitToPhysical(faultInfo.addr1, faultInfo.bit1);
            processedFault.physicalAddr1 = physical1.addr;
            processedFault.physicalBit1 = physical1.bit;
            processedFault.logicalAddr1 = faultInfo.addr1;
            processedFault.logicalBit1 = faultInfo.bit1;
            
            if (faultInfo.addr2 !== undefined) {
                const physical2 = this.logicalBitToPhysical(faultInfo.addr2, faultInfo.bit2);
                processedFault.physicalAddr2 = physical2.addr;
                processedFault.physicalBit2 = physical2.bit;
                processedFault.logicalAddr2 = faultInfo.addr2;
                processedFault.logicalBit2 = faultInfo.bit2;
            }
        } else {
            const logical1 = this.physicalBitToLogical(faultInfo.addr1, faultInfo.bit1);
            processedFault.physicalAddr1 = faultInfo.addr1;
            processedFault.physicalBit1 = faultInfo.bit1;
            processedFault.logicalAddr1 = logical1.addr;
            processedFault.logicalBit1 = logical1.bit;
            
            if (faultInfo.addr2 !== undefined) {
                const logical2 = this.physicalBitToLogical(faultInfo.addr2, faultInfo.bit2);
                processedFault.physicalAddr2 = faultInfo.addr2;
                processedFault.physicalBit2 = faultInfo.bit2;
                processedFault.logicalAddr2 = logical2.addr;
                processedFault.logicalBit2 = logical2.bit;
            }
        }
        
        // 生成故障ID
        let faultId;
        if (processedFault.type.startsWith('BF_')) {
            const p1 = `${domain}A${processedFault.addr1}B${processedFault.bit1}`;
            const p2 = `${domain}A${processedFault.addr2}B${processedFault.bit2}`;
            faultId = `${processedFault.type}-${[p1, p2].sort().join('-')}`;
        } else {
            faultId = `${processedFault.type}-${domain}A${processedFault.addr1}B${processedFault.bit1}`;
        }

        // 檢查重複
        if (this.faults.some(f => f.id === faultId)) {
            throw new Error('故障已存在');
        }

        // 添加故障
        const fault = {
            id: faultId,
            detected: false,
            detectionCount: 0,
            domain,
            ...processedFault
        };

        this.faults.push(fault);
        return fault;
    }

    /**
     * 故障檢測
     */
    detectFaults(logicalAddr, expectedVal, actualVal) {
        const changedBits = expectedVal ^ actualVal;
        const detectedFaults = [];
        
        for (let i = 0; i < this.dataWidth; i++) {
            if ((changedBits >> i) & 1) {
                // 找出影響此邏輯位元的故障
                const physical = this.logicalBitToPhysical(logicalAddr, i);
                
                const affectedFaults = this.faults.filter(fault => {
                    if (fault.detected) return false;
                    
                    return (fault.physicalAddr1 === physical.addr && fault.physicalBit1 === physical.bit) || 
                           (fault.physicalAddr2 === physical.addr && fault.physicalBit2 === physical.bit);
                });
                
                affectedFaults.forEach(fault => {
                    if (!fault.detected) {
                        fault.detected = true;
                        fault.detectionCount++;
                        detectedFaults.push(fault);
                    }
                });
            }
        }
        
        return detectedFaults;
    }

    /**
     * 重置記憶體狀態
     */
    reset() {
        this.cells.fill(0);
        this.faults.forEach(f => f.detected = false);
        this.transitionHistory.clear();
        this.accessCount = 0;
    }

    /**
     * 清除所有故障
     */
    clearFaults() {
        this.faults = [];
        this.transitionHistory.clear();
    }

    /**
     * 獲取位元映射資訊
     */
    getBitMappingInfo() {
        const mappingArray = [];
        for (let addr = 0; addr < this.addressCount; addr++) {
            for (let bit = 0; bit < this.dataWidth; bit++) {
                const logicalKey = `${addr}_${bit}`;
                const physicalKey = this.bitMapping.get(logicalKey);
                if (physicalKey) {
                    const parts = physicalKey.split('_');
                    mappingArray.push({
                        logical: logicalKey,
                        physical: physicalKey,
                        logicalAddr: addr,
                        logicalBit: bit,
                        physicalAddr: parseInt(parts[0]),
                        physicalBit: parseInt(parts[1])
                    });
                }
            }
        }
        
        return {
            mapping: mappingArray,
            description: this.bitMappingDescription,
            type: this.detectBitMappingType()
        };
    }

    /**
     * 檢測位元映射類型
     */
    detectBitMappingType() {
        // 檢查是否為恆等映射
        let isIdentity = true;
        for (let addr = 0; addr < this.addressCount; addr++) {
            for (let bit = 0; bit < this.dataWidth; bit++) {
                const logicalKey = `${addr}_${bit}`;
                const physicalKey = this.bitMapping.get(logicalKey);
                if (physicalKey !== logicalKey) {
                    isIdentity = false;
                    break;
                }
            }
            if (!isIdentity) break;
        }
        if (isIdentity) return 'identity';
        
        // 檢查是否為位元反轉
        let isBitReverse = true;
        for (let addr = 0; addr < this.addressCount; addr++) {
            for (let bit = 0; bit < this.dataWidth; bit++) {
                const logicalKey = `${addr}_${bit}`;
                const expectedPhysicalKey = `${addr}_${this.dataWidth - 1 - bit}`;
                const actualPhysicalKey = this.bitMapping.get(logicalKey);
                if (actualPhysicalKey !== expectedPhysicalKey) {
                    isBitReverse = false;
                    break;
                }
            }
            if (!isBitReverse) break;
        }
        if (isBitReverse) return 'bit_reverse';
        
        return 'custom';
    }

    /**
     * 匯出位元映射為CSV格式
     */
    exportBitMappingCSV() {
        let csv = 'logical_addr,logical_bit,physical_addr,physical_bit\n';
        for (let addr = 0; addr < this.addressCount; addr++) {
            for (let bit = 0; bit < this.dataWidth; bit++) {
                const logicalKey = `${addr}_${bit}`;
                const physicalKey = this.bitMapping.get(logicalKey);
                if (physicalKey) {
                    const parts = physicalKey.split('_');
                    csv += `${addr},${bit},${parts[0]},${parts[1]}\n`;
                }
            }
        }
        return csv;
    }

    /**
     * 匯出位元映射為JSON格式
     */
    exportBitMappingJSON() {
        const mapping = {};
        for (const [logical, physical] of this.bitMapping.entries()) {
            mapping[logical] = physical;
        }
        
        return JSON.stringify({
            mapping,
            description: this.bitMappingDescription,
            addressCount: this.addressCount,
            dataWidth: this.dataWidth,
            type: 'bit_level',
            timestamp: new Date().toISOString()
        }, null, 2);
    }

    /**
     * 獲取故障統計資訊
     */
    getFaultStatistics() {
        const total = this.faults.length;
        const detected = this.faults.filter(f => f.detected).length;
        const coverage = total > 0 ? (detected / total) * 100 : 0;
        
        return {
            total,
            detected,
            undetected: total - detected,
            coverage: coverage.toFixed(2),
            accessCount: this.accessCount,
            mappingType: this.detectBitMappingType()
        };
    }

    /**
     * 獲取故障詳細資訊
     */
    getFaultDetails() {
        return this.faults.map(fault => ({
            id: fault.id,
            type: fault.type,
            domain: fault.domain,
            logicalLocation: fault.type.startsWith('BF_') ? 
                `L${fault.logicalAddr1},${fault.logicalBit1} ↔ L${fault.logicalAddr2},${fault.logicalBit2}` :
                `L${fault.logicalAddr1},${fault.logicalBit1}`,
            physicalLocation: fault.type.startsWith('BF_') ? 
                `P${fault.physicalAddr1},${fault.physicalBit1} ↔ P${fault.physicalAddr2},${fault.physicalBit2}` :
                `P${fault.physicalAddr1},${fault.physicalBit1}`,
            detected: fault.detected,
            detectionCount: fault.detectionCount
        }));
    }

    /**
     * 匯出記憶體狀態
     */
    exportState() {
        return {
            addressCount: this.addressCount,
            dataWidth: this.dataWidth,
            cells: [...this.cells],
            faults: this.faults.map(f => ({...f})),
            bitMapping: this.getBitMappingInfo(),
            statistics: this.getFaultStatistics(),
            timestamp: new Date().toISOString()
        };
    }
}

// 匯出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = BitLevelMemoryModel;
}