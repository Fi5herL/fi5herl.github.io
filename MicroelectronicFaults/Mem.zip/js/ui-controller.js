/**
 * UI控制器 - 負責處理使用者介面互動
 */

class UIController {
    constructor(simulator) {
        this.simulator = simulator;
        this.elements = {};
        this.state = {
            isRunning: false,
            isPaused: false,
            currentStep: 0,
            totalSteps: 0
        };
        this.initializeElements();
        this.bindEvents();
    }

    /**
     * 初始化DOM元素引用
     */
    initializeElements() {
        this.elements = {
            // 記憶體設定
            memAddrCount: document.getElementById('mem-addr-count'),
            memDataWidth: document.getElementById('mem-data-width'),
            btnSetSize: document.getElementById('btn-set-size'),
            
            // 故障控制
            faultType: document.getElementById('fault-type'),
            faultAddr1: document.getElementById('fault-addr1'),
            faultBit1: document.getElementById('fault-bit1'),
            faultAddr2: document.getElementById('fault-addr2'),
            faultBit2: document.getElementById('fault-bit2'),
            faultCell2: document.getElementById('fault-cell2'),
            btnInjectFault: document.getElementById('btn-inject-fault'),
            btnClearFaults: document.getElementById('btn-clear-faults'),
            
            // 演算法控制
            algorithmSelect: document.getElementById('algorithm-select'),
            algorithmCode: document.getElementById('algorithm-code'),
            btnAddAlgo: document.getElementById('btn-add-algo'),
            btnHelp: document.getElementById('btn-help'),
            
            // 範圍控制
            rangeModeSelect: document.getElementById('range-mode-select'),
            addrRangeInputs: document.getElementById('addr-range-inputs'),
            bitRangeInputs: document.getElementById('bit-range-inputs'),
            startAddr: document.getElementById('start-addr'),
            endAddr: document.getElementById('end-addr'),
            startBit: document.getElementById('start-bit'),
            endBit: document.getElementById('end-bit'),
            
            // 執行控制
            opDelay: document.getElementById('op-delay'),
            btnRunAuto: document.getElementById('btn-run-auto'),
            btnRunStep: document.getElementById('btn-run-step'),
            btnNextStep: document.getElementById('btn-next-step'),
            
            // 顯示元素
            timeline: document.getElementById('timeline'),
            timelineLabel: document.getElementById('timeline-label'),
            viewEffective: document.getElementById('view-effective'),
            viewPhysical: document.getElementById('view-physical'),
            logContainer: document.getElementById('log-container'),
            results: document.getElementById('results'),
            
            // 功能按鈕
            btnClearLog: document.getElementById('btn-clear-log'),
            btnExportLog: document.getElementById('btn-export-log'),
            btnExportResults: document.getElementById('btn-export-results'),
            
            // 模態對話框
            helpModal: document.getElementById('help-modal'),
            helpContent: document.getElementById('help-content'),
            closeModal: document.querySelector('.modal .close'),
            
            // 錯誤提示
            errorToast: document.getElementById('error-toast'),
            errorMessage: document.getElementById('error-message'),
            closeToast: document.getElementById('close-toast')
        };
    }

    /**
     * 綁定事件監聽器
     */
    bindEvents() {
        // 記憶體設定事件
        this.elements.btnSetSize.addEventListener('click', () => {
            this.handleSetMemorySize();
        });

        // 故障控制事件
        this.elements.faultType.addEventListener('change', () => {
            this.updateFaultInputs();
        });

        this.elements.btnInjectFault.addEventListener('click', () => {
            this.handleInjectFault();
        });

        this.elements.btnClearFaults.addEventListener('click', () => {
            this.handleClearFaults();
        });

        // 演算法控制事件
        this.elements.algorithmSelect.addEventListener('change', () => {
            this.loadSelectedAlgorithm();
        });

        this.elements.btnAddAlgo.addEventListener('click', () => {
            this.handleAddCustomAlgorithm();
        });

        this.elements.btnHelp.addEventListener('click', () => {
            this.showHelp();
        });

        // 範圍控制事件
        this.elements.rangeModeSelect.addEventListener('change', () => {
            this.updateRangeInputs();
        });

        // 執行控制事件
        this.elements.btnRunAuto.addEventListener('click', () => {
            this.handleRunAuto();
        });

        this.elements.btnRunStep.addEventListener('click', () => {
            this.handleRunStep();
        });

        this.elements.btnNextStep.addEventListener('click', () => {
            this.handleNextStep();
        });

        // 時間軸事件
        this.elements.timeline.addEventListener('input', () => {
            this.handleTimelineChange();
        });

        // 功能按鈕事件
        this.elements.btnClearLog.addEventListener('click', () => {
            this.clearLog();
        });

        this.elements.btnExportLog.addEventListener('click', () => {
            this.exportLog();
        });

        this.elements.btnExportResults.addEventListener('click', () => {
            this.exportResults();
        });

        // 模態對話框事件
        this.elements.closeModal.addEventListener('click', () => {
            this.hideHelp();
        });

        this.elements.helpModal.addEventListener('click', (e) => {
            if (e.target === this.elements.helpModal) {
                this.hideHelp();
            }
        });

        // 錯誤提示事件
        this.elements.closeToast.addEventListener('click', () => {
            this.hideToast();
        });

        // 鍵盤快捷鍵
        document.addEventListener('keydown', (e) => {
            this.handleKeyboard(e);
        });

        // 視窗大小變化
        window.addEventListener('resize', () => {
            this.handleResize();
        });
    }

    /**
     * 處理記憶體大小設定
     */
    handleSetMemorySize() {
        try {
            const addrCount = parseInt(this.elements.memAddrCount.value);
            const dataWidth = parseInt(this.elements.memDataWidth.value);

            if (isNaN(addrCount) || addrCount < 2 || addrCount > 64) {
                throw new Error('位址數量必須在 2-64 之間');
            }

            if (isNaN(dataWidth) || dataWidth < 2 || dataWidth > 16) {
                throw new Error('資料寬度必須在 2-16 之間');
            }

            this.simulator.setMemorySize(addrCount, dataWidth);
            this.updateRangeInputs();
            this.updateMemoryView();
            this.showToast('記憶體大小設定成功', 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 更新故障輸入界面
     */
    updateFaultInputs() {
        const faultType = this.elements.faultType.value;
        const isBridging = faultType.startsWith('BF_');
        
        this.elements.faultCell2.style.display = isBridging ? 'grid' : 'none';
        
        if (faultType === 'BF_OutIn') {
            this.elements.faultAddr1.placeholder = '攻擊者位址';
            this.elements.faultBit1.placeholder = '攻擊者位元';
            this.elements.faultAddr2.placeholder = '受害者位址';
            this.elements.faultBit2.placeholder = '受害者位元';
        } else if (isBridging) {
            this.elements.faultAddr1.placeholder = '位址 1';
            this.elements.faultBit1.placeholder = '位元 1';
            this.elements.faultAddr2.placeholder = '位址 2';
            this.elements.faultBit2.placeholder = '位元 2';
        } else {
            this.elements.faultAddr1.placeholder = '位址';
            this.elements.faultBit1.placeholder = '位元';
        }
    }

    /**
     * 處理故障注入
     */
    handleInjectFault() {
        try {
            const faultType = this.elements.faultType.value;
            const addr1 = parseInt(this.elements.faultAddr1.value);
            const bit1 = parseInt(this.elements.faultBit1.value);

            if (isNaN(addr1) || isNaN(bit1)) {
                throw new Error('請輸入有效的位址和位元');
            }

            let faultInfo = { type: faultType, addr1, bit1 };

            if (faultType.startsWith('BF_')) {
                const addr2 = parseInt(this.elements.faultAddr2.value);
                const bit2 = parseInt(this.elements.faultBit2.value);

                if (isNaN(addr2) || isNaN(bit2)) {
                    throw new Error('請輸入有效的第二組位址和位元');
                }

                faultInfo.addr2 = addr2;
                faultInfo.bit2 = bit2;
            }

            const fault = this.simulator.injectFault(faultInfo);
            this.updateMemoryView();
            this.log('系統', `故障注入成功: ${fault.id}`, 'info');
            this.showToast(`故障注入成功: ${fault.id}`, 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理清除故障
     */
    handleClearFaults() {
        try {
            this.simulator.clearFaults();
            this.updateMemoryView();
            this.log('系統', '所有故障已清除', 'info');
            this.showToast('所有故障已清除', 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 載入選定的演算法
     */
    loadSelectedAlgorithm() {
        const algorithmName = this.elements.algorithmSelect.value;
        const algorithm = this.simulator.algorithms.getAlgorithm(algorithmName);
        this.elements.algorithmCode.value = algorithm;
        this.updateRangeInputs();
    }

    /**
     * 處理新增自訂演算法
     */
    handleAddCustomAlgorithm() {
        const name = prompt('請輸入演算法名稱:');
        if (!name || name.trim() === '') return;

        try {
            const template = `// ${name} - 自訂演算法
log('開始執行 ${name}');

// 可用參數: startAddr, endAddr, startBit, endBit
// 可用方法: mem.write(addr, value), mem.readAndCheck(addr, expectedValue)
// 可用函數: mem.size(), mem.allOnes(), mem.dataWidth()

// 範例: 寫入並讀取測試
for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.write(i, 0);
}

for (let i = startAddr; i <= endAddr; i++) {
    yield* mem.readAndCheck(i, 0);
}

log('${name} 執行完成');`;

            this.simulator.algorithms.addCustomAlgorithm(name, template);
            this.updateAlgorithmSelect();
            this.elements.algorithmSelect.value = name;
            this.loadSelectedAlgorithm();
            this.showToast(`演算法 "${name}" 新增成功`, 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 更新範圍輸入界面
     */
    updateRangeInputs() {
        const rangeMode = this.elements.rangeModeSelect.value;
        const algorithmName = this.elements.algorithmSelect.value;
        const algorithmInfo = this.simulator.algorithms.getRecommendedRange(algorithmName);

        // 顯示/隱藏範圍輸入
        this.elements.addrRangeInputs.style.display = 
            (rangeMode === 'addr' || rangeMode === 'bit') ? 'block' : 'none';
        this.elements.bitRangeInputs.style.display = 
            (rangeMode === 'bit') ? 'block' : 'none';

        // 更新位元範圍選項的可用性
        const bitOption = this.elements.rangeModeSelect.querySelector('option[value="bit"]');
        if (bitOption) {
            bitOption.disabled = !algorithmInfo.supportsBitRange;
            if (!algorithmInfo.supportsBitRange && rangeMode === 'bit') {
                this.elements.rangeModeSelect.value = 'full';
                this.updateRangeInputs();
            }
        }

        // 更新範圍輸入的最大值
        if (this.simulator.memory) {
            this.elements.startAddr.max = this.simulator.memory.addressCount - 1;
            this.elements.endAddr.max = this.simulator.memory.addressCount - 1;
            this.elements.startBit.max = this.simulator.memory.dataWidth - 1;
            this.elements.endBit.max = this.simulator.memory.dataWidth - 1;
        }
    }

    /**
     * 處理自動執行
     */
    handleRunAuto() {
        try {
            this.simulator.runAuto();
            this.updateControlButtons();
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理單步執行
     */
    handleRunStep() {
        try {
            this.simulator.runStep();
            this.updateControlButtons();
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理下一步
     */
    handleNextStep() {
        try {
            this.simulator.nextStep();
            this.updateControlButtons();
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    /**
     * 處理時間軸變化
     */
    handleTimelineChange() {
        const step = parseInt(this.elements.timeline.value);
        this.simulator.goToStep(step);
        this.updateDisplay();
    }

    /**
     * 顯示幫助
     */
    showHelp() {
        const algorithmName = this.elements.algorithmSelect.value;
        const description = this.simulator.algorithms.getAlgorithmDescription(algorithmName);
        const algorithmInfo = this.simulator.algorithms.getRecommendedRange(algorithmName);
        
        this.elements.helpContent.innerHTML = `
            <h4>${algorithmName}</h4>
            <p><strong>描述：</strong>${description}</p>
            <p><strong>時間複雜度：</strong>${algorithmInfo.complexity}</p>
            <p><strong>支援範圍：</strong>
                ${algorithmInfo.supportsAddressRange ? '位址範圍 ' : ''}
                ${algorithmInfo.supportsBitRange ? '位元範圍' : ''}
            </p>
            <hr>
            <h4>使用說明</h4>
            <ul>
                <li>選擇記憶體大小並設定</li>
                <li>注入一個或多個故障</li>
                <li>選擇測試演算法</li>
                <li>設定測試範圍（可選）</li>
                <li>執行測試並觀察結果</li>
            </ul>
        `;
        
        this.elements.helpModal.style.display = 'flex';
    }

    /**
     * 隱藏幫助
     */
    hideHelp() {
        this.elements.helpModal.style.display = 'none';
    }

    /**
     * 顯示提示訊息
     */
    showToast(message, type = 'info') {
        this.elements.errorMessage.textContent = message;
        this.elements.errorToast.className = `toast ${type}`;
        this.elements.errorToast.style.display = 'block';

        // 自動隱藏
        setTimeout(() => {
            this.hideToast();
        }, 5000);
    }

    /**
     * 隱藏提示訊息
     */
    hideToast() {
        this.elements.errorToast.style.display = 'none';
    }

    /**
     * 處理鍵盤快捷鍵
     */
    handleKeyboard(e) {
        if (e.ctrlKey) {
            switch (e.key) {
                case 'Enter':
                    e.preventDefault();
                    if (this.state.isPaused) {
                        this.handleNextStep();
                    } else if (!this.state.isRunning) {
                        this.handleRunAuto();
                    }
                    break;
                case ' ':
                    e.preventDefault();
                    if (!this.state.isRunning) {
                        this.handleRunStep();
                    }
                    break;
                case 'r':
                    e.preventDefault();
                    this.handleSetMemorySize();
                    break;
            }
        }
    }

    /**
     * 處理視窗大小變化
     */
    handleResize() {
        // 響應式佈局調整
        this.updateMemoryView();
    }

    /**
     * 更新演算法選擇框
     */
    updateAlgorithmSelect() {
        const currentValue = this.elements.algorithmSelect.value;
        const algorithms = this.simulator.algorithms.getAllAlgorithms();
        
        this.elements.algorithmSelect.innerHTML = '';
        
        Object.keys(algorithms).forEach(name => {
            const option = document.createElement('option');
            option.value = name;
            option.textContent = name;
            this.elements.algorithmSelect.appendChild(option);
        });
        
        if (algorithms[currentValue]) {
            this.elements.algorithmSelect.value = currentValue;
        }
    }

    /**
     * 更新控制按鈕狀態
     */
    updateControlButtons() {
        this.elements.btnRunAuto.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.btnRunStep.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.btnNextStep.disabled = !this.state.isPaused;
        this.elements.btnInjectFault.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.btnSetSize.disabled = this.state.isRunning || this.state.isPaused;
        this.elements.timeline.disabled = this.state.isRunning || this.state.totalSteps <= 1;
    }

    /**
     * 更新顯示
     */
    updateDisplay() {
        this.updateMemoryView();
        this.updateTimeline();
        this.updateResults();
    }

    /**
     * 更新記憶體視圖
     */
    updateMemoryView() {
        if (!this.simulator.memory) return;

        this.elements.viewEffective.innerHTML = '';
        this.elements.viewPhysical.innerHTML = '';

        const activeAddress = this.simulator.getCurrentActiveAddress();
        
        this._renderMemoryView(this.elements.viewEffective, false, activeAddress);
        this._renderMemoryView(this.elements.viewPhysical, true, activeAddress);
    }

    /**
     * 渲染記憶體視圖
     */
    _renderMemoryView(container, isPhysical, activeAddress) {
        const memory = this.simulator.memory;
        
        for (let i = 0; i < memory.addressCount; i++) {
            const row = document.createElement('div');
            row.className = 'addr-row';
            if (i === activeAddress) {
                row.classList.add('active');
            }

            const label = document.createElement('div');
            label.className = 'addr-label';
            label.textContent = `Addr ${i}:`;
            row.appendChild(label);

            const bitsContainer = document.createElement('div');
            bitsContainer.className = 'word-bits';

            const wordValue = isPhysical ? memory.cells[i] : memory.read(i);
            
            // 從高位到低位顯示（MSB-first）
            for (let j = memory.dataWidth - 1; j >= 0; j--) {
                const bit = document.createElement('div');
                bit.className = 'bit';
                const bitValue = (wordValue >> j) & 1;
                bit.textContent = bitValue;
                bit.classList.add(bitValue === 0 ? 'bit-0' : 'bit-1');

                // 添加故障標示
                const bitFaults = memory.faults.filter(f => 
                    (f.addr1 === i && f.bit1 === j) || 
                    (f.addr2 === i && f.bit2 === j)
                );

                if (bitFaults.length > 0) {
                    bitFaults.forEach(fault => {
                        if (fault.type.startsWith('SA')) {
                            bit.classList.add(`fault-${fault.type.toLowerCase()}`);
                        } else if (fault.type.startsWith('BF')) {
                            bit.classList.add('fault-bf');
                        } else if (fault.type.startsWith('TF')) {
                            bit.classList.add('fault-tf');
                        }
                    });

                    const tooltip = document.createElement('span');
                    tooltip.className = 'fault-tooltip';
                    tooltip.textContent = bitFaults.map(f => f.id).join(', ');
                    bit.appendChild(tooltip);
                }

                bitsContainer.appendChild(bit);
            }

            row.appendChild(bitsContainer);
            container.appendChild(row);
        }
    }

    /**
     * 更新時間軸
     */
    updateTimeline() {
        this.elements.timeline.max = this.state.totalSteps - 1;
        this.elements.timeline.value = this.state.currentStep;
        this.elements.timelineLabel.textContent = `Step ${this.state.currentStep} / ${this.state.totalSteps - 1}`;
    }

    /**
     * 更新結果顯示
     */
    updateResults() {
        if (!this.simulator.memory) return;

        const stats = this.simulator.memory.getFaultStatistics();
        const details = this.simulator.memory.getFaultDetails();

        let html = `
            <h4>故障統計</h4>
            <p>總計故障: ${stats.total}</p>
            <p>已檢測: ${stats.detected}</p>
            <p>未檢測: ${stats.undetected}</p>
            <p>覆蓋率: <strong>${stats.coverage}%</strong></p>
            <p>存取次數: ${stats.accessCount}</p>
        `;

        if (details.length > 0) {
            html += '<h4>故障詳情</h4><ul>';
            details.forEach(fault => {
                const status = fault.detected ? '已檢測' : '未檢測';
                const color = fault.detected ? '#27ae60' : '#e74c3c';
                html += `<li>${fault.id} (${fault.location}): <span style="color: ${color}; font-weight: bold;">${status}</span></li>`;
            });
            html += '</ul>';
        }

        this.elements.results.innerHTML = html;
    }

    /**
     * 記錄日誌
     */
    log(source, message, type = 'info') {
        const logEntry = document.createElement('div');
        logEntry.innerHTML = `<span class="log-op">[${source}]</span> <span class="log-${type}">${message}</span>`;
        this.elements.logContainer.appendChild(logEntry);
        this.elements.logContainer.scrollTop = this.elements.logContainer.scrollHeight;
    }

    /**
     * 清除日誌
     */
    clearLog() {
        this.elements.logContainer.innerHTML = '';
    }

    /**
     * 匯出日誌
     */
    exportLog() {
        const logs = this.elements.logContainer.innerText;
        const blob = new Blob([logs], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `memory-test-log-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    }

    /**
     * 匯出結果
     */
    exportResults() {
        if (!this.simulator.memory) return;

        const results = this.simulator.memory.exportState();
        const blob = new Blob([JSON.stringify(results, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `memory-test-results-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    /**
     * 更新狀態
     */
    updateState(newState) {
        this.state = { ...this.state, ...newState };
        this.updateControlButtons();
        this.updateTimeline();
    }
}

// 如果在 Node.js 環境中，匯出模組
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UIController;
}