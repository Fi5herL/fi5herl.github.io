/**
 * 增強版記憶體模型 - 支援位址映射
 * 支援邏輯位址與物理位址的映射，模擬真實記憶體系統
 */

class EnhancedMemoryModel {
    constructor(addressCount, dataWidth) {
        this.addressCount = addressCount;
        this.dataWidth = dataWidth;
        this.allOnesValue = (1 << dataWidth) - 1;
        this.cells = new Array(addressCount).fill(0);
        this.faults = [];
        this.transitionHistory = new Map();
        this.accessCount = 0;
        
        // 記憶體映射相關
        this.addressMapping = new Map(); // 邏輯位址 -> 物理位址
        this.reverseMapping = new Map(); // 物理位址 -> 邏輯位址
        this.mappingDescription = "恆等映射";
        
        // 初始化為恆等映射
        this.initializeIdentityMapping();
    }

    /**
     * 初始化恆等映射
     */
    initializeIdentityMapping() {
        this.addressMapping.clear();
        this.reverseMapping.clear();
        
        for (let i = 0; i < this.addressCount; i++) {
            this.addressMapping.set(i, i);
            this.reverseMapping.set(i, i);
        }
        
        this.mappingDescription = "恆等映射 (L→P: 0→0, 1→1, ...)";
    }

    /**
     * 設定記憶體映射
     * @param {Map|Object} mapping - 映射表 (邏輯位址 -> 物理位址)
     * @param {string} description - 映射描述
     */
    setAddressMapping(mapping, description = "自訂映射") {
        this.addressMapping.clear();
        this.reverseMapping.clear();
        
        // 處理不同的輸入格式
        if (mapping instanceof Map) {
            this.addressMapping = new Map(mapping);
        } else if (typeof mapping === 'object') {
            for (const [logical, physical] of Object.entries(mapping)) {
                this.addressMapping.set(parseInt(logical), parseInt(physical));
            }
        }
        
        // 驗證映射的有效性
        if (!this.validateMapping()) {
            throw new Error('無效的映射表：必須是雙射函數');
        }
        
        // 建立反向映射
        for (const [logical, physical] of this.addressMapping.entries()) {
            this.reverseMapping.set(physical, logical);
        }
        
        this.mappingDescription = description;
        
        // 清除故障（因為映射改變了）
        this.clearFaults();
    }

    /**
     * 驗證映射表是否有效
     */
    validateMapping() {
        const logicalAddresses = new Set();
        const physicalAddresses = new Set();
        
        for (const [logical, physical] of this.addressMapping.entries()) {
            // 檢查範圍
            if (logical < 0 || logical >= this.addressCount || 
                physical < 0 || physical >= this.addressCount) {
                return false;
            }
            
            // 檢查是否重複
            if (logicalAddresses.has(logical) || physicalAddresses.has(physical)) {
                return false;
            }
            
            logicalAddresses.add(logical);
            physicalAddresses.add(physical);
        }
        
        // 檢查是否為完整映射
        return logicalAddresses.size === this.addressCount && 
               physicalAddresses.size === this.addressCount;
    }

    /**
     * 獲取預設映射類型
     */
    getPresetMapping(type) {
        const mapping = {};
        
        switch (type) {
            case 'identity':
                for (let i = 0; i < this.addressCount; i++) {
                    mapping[i] = i;
                }
                return { mapping, description: "恆等映射 (L→P: 0→0, 1→1, ...)" };
                
            case 'reverse':
                for (let i = 0; i < this.addressCount; i++) {
                    mapping[i] = this.addressCount - 1 - i;
                }
                return { mapping, description: "反向映射 (L→P: 0→7, 1→6, ...)" };
                
            case 'interleave':
                const half = Math.floor(this.addressCount / 2);
                for (let i = 0; i < half; i++) {
                    mapping[i * 2] = i;
                    mapping[i * 2 + 1] = i + half;
                }
                if (this.addressCount % 2 !== 0) {
                    mapping[this.addressCount - 1] = this.addressCount - 1;
                }
                return { mapping, description: "交錯映射 (L→P: 0→0, 1→4, 2→1, 3→5, ...)" };
                
            default:
                return this.getPresetMapping('identity');
        }
    }

    /**
     * 邏輯位址轉物理位址
     */
    logicalToPhysical(logicalAddr) {
        const physicalAddr = this.addressMapping.get(logicalAddr);
        if (physicalAddr === undefined) {
            throw new Error(`無效的邏輯位址: ${logicalAddr}`);
        }
        return physicalAddr;
    }

    /**
     * 物理位址轉邏輯位址
     */
    physicalToLogical(physicalAddr) {
        const logicalAddr = this.reverseMapping.get(physicalAddr);
        if (logicalAddr === undefined) {
            throw new Error(`無效的物理位址: ${physicalAddr}`);
        }
        return logicalAddr;
    }

    /**
     * 重置記憶體狀態
     */
    reset() {
        this.cells.fill(0);
        this.faults.forEach(f => f.detected = false);
        this.transitionHistory.clear();
        this.accessCount = 0;
    }

    /**
     * 清除所有故障
     */
    clearFaults() {
        this.faults = [];
        this.transitionHistory.clear();
    }

    /**
     * 注入故障 - 支援邏輯和物理位址
     */
    injectFault(faultInfo) {
        const { domain = 'logical' } = faultInfo;
        let processedFault = { ...faultInfo };
        
        // 處理位址映射
        if (domain === 'logical') {
            processedFault.physicalAddr1 = this.logicalToPhysical(faultInfo.addr1);
            processedFault.physicalBit1 = faultInfo.bit1;
            processedFault.logicalAddr1 = faultInfo.addr1;
            processedFault.logicalBit1 = faultInfo.bit1;
            
            if (faultInfo.addr2 !== undefined) {
                processedFault.physicalAddr2 = this.logicalToPhysical(faultInfo.addr2);
                processedFault.physicalBit2 = faultInfo.bit2;
                processedFault.logicalAddr2 = faultInfo.addr2;
                processedFault.logicalBit2 = faultInfo.bit2;
            }
        } else {
            processedFault.physicalAddr1 = faultInfo.addr1;
            processedFault.physicalBit1 = faultInfo.bit1;
            processedFault.logicalAddr1 = this.physicalToLogical(faultInfo.addr1);
            processedFault.logicalBit1 = faultInfo.bit1;
            
            if (faultInfo.addr2 !== undefined) {
                processedFault.physicalAddr2 = faultInfo.addr2;
                processedFault.physicalBit2 = faultInfo.bit2;
                processedFault.logicalAddr2 = this.physicalToLogical(faultInfo.addr2);
                processedFault.logicalBit2 = faultInfo.bit2;
            }
        }
        
        // 驗證故障參數
        if (!this._validateFaultParams(processedFault)) {
            throw new Error('無效的故障參數');
        }

        // 生成故障ID
        let faultId;
        if (processedFault.type.startsWith('BF_')) {
            const p1 = `${domain}A${processedFault.addr1}B${processedFault.bit1}`;
            const p2 = `${domain}A${processedFault.addr2}B${processedFault.bit2}`;
            faultId = `${processedFault.type}-${[p1, p2].sort().join('-')}`;
        } else {
            faultId = `${processedFault.type}-${domain}A${processedFault.addr1}B${processedFault.bit1}`;
        }

        // 檢查重複
        if (this.faults.some(f => f.id === faultId)) {
            throw new Error('故障已存在');
        }

        // 添加故障
        const fault = {
            id: faultId,
            detected: false,
            detectionCount: 0,
            domain,
            ...processedFault
        };

        this.faults.push(fault);
        return fault;
    }

    /**
     * 驗證故障參數
     */
    _validateFaultParams(faultInfo) {
        const { physicalAddr1, physicalBit1, physicalAddr2, physicalBit2, type } = faultInfo;
        
        // 檢查基本參數
        if (physicalAddr1 < 0 || physicalAddr1 >= this.addressCount || 
            physicalBit1 < 0 || physicalBit1 >= this.dataWidth) {
            return false;
        }

        // 檢查bridging fault的第二組參數
        if (type.startsWith('BF_')) {
            if (physicalAddr2 < 0 || physicalAddr2 >= this.addressCount || 
                physicalBit2 < 0 || physicalBit2 >= this.dataWidth) {
                return false;
            }
            if (physicalAddr1 === physicalAddr2 && physicalBit1 === physicalBit2) {
                return false;
            }
        }

        return true;
    }

    /**
     * 讀取記憶體（使用邏輯位址）
     */
    read(logicalAddress) {
        this.accessCount++;
        
        const physicalAddress = this.logicalToPhysical(logicalAddress);
        let finalWord = 0;
        
        for (let i = 0; i < this.dataWidth; i++) {
            if (this._readBit(physicalAddress, i)) {
                finalWord |= (1 << i);
            }
        }
        
        return finalWord;
    }

    /**
     * 位元讀取（使用物理位址）
     */
    _readBit(physicalAddr, bit, visited = new Set()) {
        const currentCellID = `${physicalAddr}_${bit}`;
        
        if (visited.has(currentCellID)) {
            return 0;
        }
        visited.add(currentCellID);

        // 檢查 Bridging fault (Output-Input)
        const outInFault = this.faults.find(f => 
            f.type === 'BF_OutIn' && f.physicalAddr2 === physicalAddr && f.physicalBit2 === bit
        );
        if (outInFault) {
            return this._readBit(outInFault.physicalAddr1, outInFault.physicalBit1, visited);
        }

        // 檢查 Bridging fault (Output-Output)
        const outOutFault = this.faults.find(f => 
            f.type === 'BF_OutOut' && 
            ((f.physicalAddr1 === physicalAddr && f.physicalBit1 === bit) || 
             (f.physicalAddr2 === physicalAddr && f.physicalBit2 === bit))
        );
        if (outOutFault) {
            const isParticipant1 = (f) => f.physicalAddr1 === physicalAddr && f.physicalBit1 === bit;
            const otherAddr = isParticipant1(outOutFault) ? outOutFault.physicalAddr2 : outOutFault.physicalAddr1;
            const otherBit = isParticipant1(outOutFault) ? outOutFault.physicalBit2 : outOutFault.physicalBit1;
            
            const ownOutput = this._getOwnOutput(physicalAddr, bit);
            const otherOutput = this._getOwnOutput(otherAddr, otherBit);
            
            return ownOutput & otherOutput;
        }

        // 檢查 Transition fault
        const transitionFault = this.faults.find(f => 
            (f.type === 'TF_0to1' || f.type === 'TF_1to0') && 
            f.physicalAddr1 === physicalAddr && f.physicalBit1 === bit
        );
        if (transitionFault) {
            const historyKey = `${physicalAddr}_${bit}`;
            const lastValue = this.transitionHistory.get(historyKey) || 0;
            const currentValue = this._getOwnOutput(physicalAddr, bit);
            
            if ((transitionFault.type === 'TF_0to1' && lastValue === 0 && currentValue === 1) ||
                (transitionFault.type === 'TF_1to0' && lastValue === 1 && currentValue === 0)) {
                return lastValue;
            }
        }

        return this._getOwnOutput(physicalAddr, bit);
    }

    /**
     * 獲取位元的原始輸出
     */
    _getOwnOutput(physicalAddr, bit) {
        const storedBit = (this.cells[physicalAddr] >> bit) & 1;
        
        const stuckFault = this.faults.find(f => 
            (f.type === 'SA0' || f.type === 'SA1') && 
            f.physicalAddr1 === physicalAddr && f.physicalBit1 === bit
        );
        
        if (stuckFault) {
            return stuckFault.type === 'SA1' ? 1 : 0;
        }
        
        return storedBit;
    }

    /**
     * 寫入記憶體（使用邏輯位址）
     */
    write(logicalAddress, value) {
        this.accessCount++;
        
        const physicalAddress = this.logicalToPhysical(logicalAddress);
        
        for (let i = 0; i < this.dataWidth; i++) {
            const bitToWrite = (value >> i) & 1;
            
            const historyKey = `${physicalAddress}_${i}`;
            const oldValue = (this.cells[physicalAddress] >> i) & 1;
            this.transitionHistory.set(historyKey, oldValue);
            
            this._writeBit(physicalAddress, i, bitToWrite);
            
            // 處理 Bridging fault (Input-Input)
            const inInFault = this.faults.find(f => 
                f.type === 'BF_InIn' && 
                ((f.physicalAddr1 === physicalAddress && f.physicalBit1 === i) || 
                 (f.physicalAddr2 === physicalAddress && f.physicalBit2 === i))
            );
            
            if (inInFault) {
                const isAggressor = (f) => f.physicalAddr1 === physicalAddress && f.physicalBit1 === i;
                const victimAddr = isAggressor(inInFault) ? inInFault.physicalAddr2 : inInFault.physicalAddr1;
                const victimBit = isAggressor(inInFault) ? inInFault.physicalBit2 : inInFault.physicalBit1;
                
                this._writeBit(victimAddr, victimBit, bitToWrite);
            }
        }
    }

    /**
     * 位元寫入（使用物理位址）
     */
    _writeBit(physicalAddr, bit, val) {
        const outInVictim = this.faults.find(f => 
            f.type === 'BF_OutIn' && f.physicalAddr2 === physicalAddr && f.physicalBit2 === bit
        );
        if (outInVictim) {
            return;
        }

        const stuckFault = this.faults.find(f => 
            (f.type === 'SA0' || f.type === 'SA1') && 
            f.physicalAddr1 === physicalAddr && f.physicalBit1 === bit
        );
        if (stuckFault) {
            return;
        }

        const transitionFault = this.faults.find(f => 
            (f.type === 'TF_0to1' || f.type === 'TF_1to0') && 
            f.physicalAddr1 === physicalAddr && f.physicalBit1 === bit
        );
        if (transitionFault) {
            const oldValue = (this.cells[physicalAddr] >> bit) & 1;
            if ((transitionFault.type === 'TF_0to1' && oldValue === 0 && val === 1) ||
                (transitionFault.type === 'TF_1to0' && oldValue === 1 && val === 0)) {
                return;
            }
        }

        if (val) {
            this.cells[physicalAddr] |= (1 << bit);
        } else {
            this.cells[physicalAddr] &= ~(1 << bit);
        }
    }

    /**
     * 故障檢測（使用邏輯位址）
     */
    detectFaults(logicalAddr, expectedVal, actualVal) {
        const physicalAddr = this.logicalToPhysical(logicalAddr);
        const changedBits = expectedVal ^ actualVal;
        const detectedFaults = [];
        
        for (let i = 0; i < this.dataWidth; i++) {
            if ((changedBits >> i) & 1) {
                const affectedFaults = this.faults.filter(fault => {
                    if (fault.detected) return false;
                    
                    return (fault.physicalAddr1 === physicalAddr && fault.physicalBit1 === i) || 
                           (fault.physicalAddr2 === physicalAddr && fault.physicalBit2 === i);
                });
                
                affectedFaults.forEach(fault => {
                    if (!fault.detected) {
                        fault.detected = true;
                        fault.detectionCount++;
                        detectedFaults.push(fault);
                    }
                });
            }
        }
        
        return detectedFaults;
    }

    /**
     * 獲取映射資訊
     */
    getMappingInfo() {
        const mappingArray = [];
        for (let logical = 0; logical < this.addressCount; logical++) {
            const physical = this.addressMapping.get(logical);
            mappingArray.push({ logical, physical });
        }
        
        return {
            mapping: mappingArray,
            description: this.mappingDescription,
            type: this.detectMappingType()
        };
    }

    /**
     * 檢測映射類型
     */
    detectMappingType() {
        // 檢查是否為恆等映射
        let isIdentity = true;
        for (let i = 0; i < this.addressCount; i++) {
            if (this.addressMapping.get(i) !== i) {
                isIdentity = false;
                break;
            }
        }
        if (isIdentity) return 'identity';
        
        // 檢查是否為反向映射
        let isReverse = true;
        for (let i = 0; i < this.addressCount; i++) {
            if (this.addressMapping.get(i) !== this.addressCount - 1 - i) {
                isReverse = false;
                break;
            }
        }
        if (isReverse) return 'reverse';
        
        // 檢查是否為交錯映射
        let isInterleave = true;
        const half = Math.floor(this.addressCount / 2);
        for (let i = 0; i < half; i++) {
            if (this.addressMapping.get(i * 2) !== i || 
                this.addressMapping.get(i * 2 + 1) !== i + half) {
                isInterleave = false;
                break;
            }
        }
        if (isInterleave) return 'interleave';
        
        return 'custom';
    }

    /**
     * 匯出映射為CSV格式
     */
    exportMappingCSV() {
        let csv = 'logical,physical\n';
        for (let logical = 0; logical < this.addressCount; logical++) {
            const physical = this.addressMapping.get(logical);
            csv += `${logical},${physical}\n`;
        }
        return csv;
    }

    /**
     * 匯出映射為JSON格式
     */
    exportMappingJSON() {
        const mapping = {};
        for (let logical = 0; logical < this.addressCount; logical++) {
            mapping[logical] = this.addressMapping.get(logical);
        }
        
        return JSON.stringify({
            mapping,
            description: this.mappingDescription,
            addressCount: this.addressCount,
            dataWidth: this.dataWidth,
            timestamp: new Date().toISOString()
        }, null, 2);
    }

    /**
     * 獲取故障統計資訊
     */
    getFaultStatistics() {
        const total = this.faults.length;
        const detected = this.faults.filter(f => f.detected).length;
        const coverage = total > 0 ? (detected / total) * 100 : 0;
        
        return {
            total,
            detected,
            undetected: total - detected,
            coverage: coverage.toFixed(2),
            accessCount: this.accessCount,
            mappingType: this.detectMappingType()
        };
    }

    /**
     * 獲取故障詳細資訊
     */
    getFaultDetails() {
        return this.faults.map(fault => ({
            id: fault.id,
            type: fault.type,
            domain: fault.domain,
            logicalLocation: fault.type.startsWith('BF_') ? 
                `L${fault.logicalAddr1},${fault.logicalBit1} ↔ L${fault.logicalAddr2},${fault.logicalBit2}` :
                `L${fault.logicalAddr1},${fault.logicalBit1}`,
            physicalLocation: fault.type.startsWith('BF_') ? 
                `P${fault.physicalAddr1},${fault.physicalBit1} ↔ P${fault.physicalAddr2},${fault.physicalBit2}` :
                `P${fault.physicalAddr1},${fault.physicalBit1}`,
            detected: fault.detected,
            detectionCount: fault.detectionCount
        }));
    }

    /**
     * 匯出記憶體狀態
     */
    exportState() {
        return {
            addressCount: this.addressCount,
            dataWidth: this.dataWidth,
            cells: [...this.cells],
            faults: this.faults.map(f => ({...f})),
            mapping: this.getMappingInfo(),
            statistics: this.getFaultStatistics(),
            timestamp: new Date().toISOString()
        };
    }
}

// 如果在 Node.js 環境中，匯出模組
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnhancedMemoryModel;
}