# PowerNote Pro - Development Documentation

## Table of Contents
1. [Application Overview](#application-overview)
2. [Architecture and Components](#architecture-and-components)
3. [Core Variables](#core-variables)
4. [JavaScript Functions Reference](#javascript-functions-reference)
5. [CSS Classes and UI Components](#css-classes-and-ui-components)
6. [Data Flow and Storage](#data-flow-and-storage)
7. [Development Patterns](#development-patterns)

## Application Overview

PowerNote Pro is a comprehensive web-based note-taking and task management application built with HTML5, CSS3, and vanilla JavaScript. It features:

- **Markdown Editor**: CodeMirror-based editor with syntax highlighting
- **Dual Editor Mode**: Side-by-side editing of multiple files
- **Time Tracking**: Automatic and manual task timing
- **File Management**: Local storage and cloud synchronization
- **Presentation Mode**: Slide presentation from markdown
- **Collaboration**: Share notes via GitHub Gist
- **Task Management**: Hierarchical task organization with time tracking
- **Hashtag System**: Cross-file hashtag linking and navigation

### Key Technologies
- **CodeMirror**: Markdown editor with folding, syntax highlighting
- **Marked.js**: Markdown to HTML conversion
- **Mermaid**: Diagram rendering
- **KaTeX**: Mathematical formula rendering
- **Font Awesome**: Icon library
- **IndexedDB**: Local storage for files and data
- **GitHub API**: Cloud synchronization and sharing

## Architecture and Components

### Main HTML Structure
```html
<body>
  <div class="container" id="main-container">
    <!-- File Panel (Sidebar) -->
    <div id="file-panel" class="file-panel">
      <div class="file-panel-header">...</div>
      <div class="file-list" id="file-list">...</div>
      <div class="toc-container" id="toc-container">...</div>
    </div>
    
    <!-- Main Editor Panel -->
    <div class="main-panel">
      <div class="toolbar">...</div>
      <div class="editor-container">...</div>
      <div class="preview-container">...</div>
    </div>
    
    <!-- Dual Editor Panels -->
    <div class="dual-editor-container">...</div>
  </div>
</body>
```

### Component Hierarchy
```
PowerNote Application
├── File Management System
│   ├── File Panel (Sidebar)
│   ├── File List Rendering
│   └── File Operations (CRUD)
├── Editor System
│   ├── Single Editor (CodeMirror)
│   ├── Dual Editor Mode
│   ├── Preview Panel
│   └── Synchronization
├── Task Management
│   ├── Timer System
│   ├── Task History
│   └── Hierarchical Tasks
├── Storage System
│   ├── IndexedDB Integration
│   ├── LocalStorage Fallback
│   └── Cloud Sync (GitHub)
└── UI Components
    ├── Modal Dialogs
    ├── Dropdown Menus
    ├── Search System
    └── Settings Panel
```

## Core Variables

### Application State Variables
```javascript
// Core Data
let files = []                    // Array of file objects
let currentFile = null            // Currently active file
let tasks = []                    // Task array for time tracking
let currentTask = null            // Active timer task
let pinnedFiles = new Set()       // Pinned file IDs

// Editor State
let editor = null                 // Main CodeMirror instance
let currentViewMode = 'split'     // View mode: split/edit-only/preview-only
let currentFontSize = 22          // Editor font size
let currentEditorTheme = 'default' // Editor theme

// UI State
let sidebarVisible = false        // Sidebar visibility
let viewMode = 'files'            // Sidebar content: files/toc/dual
let mobileViewMode = 'edit'       // Mobile view mode
let isPresentationMode = false    // Presentation mode state

// Dual Editor System
let isDualEditorMode = false      // Dual editor mode flag
let dualEditorInstances = [null, null] // Two CodeMirror instances
let dualEditorFiles = [null, null]     // Files in dual editor
let activePaneIndex = 0           // Active pane (0 or 1)

// Timer System
let isTimerRunning = false        // Timer state
let autoTimerEnabled = true       // Auto-timer feature
let timerStartTime = null         // Timer start timestamp

// Search System
let allSearchResults = []         // Search results across files
let currentSearchScope = 'current' // Search scope
let selectedTags = new Set()      // Tag filter selection

// Synchronization
let isSyncing = false            // Scroll sync prevention
let syncScrollEnabled = true      // Sync scroll feature
let syncManager = null           // Cloud sync manager instance
```

### Configuration Objects
```javascript
// Sync Settings for cloud integration
let syncSettings = {
    github: {
        token: '',
        username: '',
        gist: {
            id: '',
            created_at: '',
            updated_at: ''
        }
    }
}

// File object structure
const fileStructure = {
    id: 'unique-id',
    name: 'filename.md',
    content: 'file content',
    lastModified: Date.now(),
    size: 1024,
    pinned: false
}

// Task object structure
const taskStructure = {
    name: 'Task Name',
    startTime: Date.now(),
    endTime: Date.now(),
    duration: 3600,  // seconds
    file: 'filename.md',
    section: 'Section Name'
}
```

## JavaScript Functions Reference

### Initialization Functions

#### `initialize()`
**Purpose**: Main initialization function that sets up the entire application
**Parameters**: None
**Returns**: Promise
**Usage**: Called on page load
**Dependencies**: All core systems

```javascript
async function initialize() {
    initEditor();
    configureMarked();
    await loadDataFromStorage();
    await loadSettingsFromStorage();
    // ... additional initialization
}
```

#### `initEditor()`
**Purpose**: Initializes the main CodeMirror editor
**Parameters**: None
**Returns**: void
**Dependencies**: CodeMirror library

```javascript
function initEditor() {
    editor = CodeMirror.fromTextArea(document.getElementById('editor'), {
        mode: 'markdown',
        theme: 'default',
        lineNumbers: true,
        lineWrapping: true,
        // ... additional options
    });
}
```

### File Management Functions

#### `createNewFile()`
**Purpose**: Creates a new markdown file
**Parameters**: None
**Returns**: Promise
**Usage**: Called by new file button
**Related**: `renderFileList()`, `saveFilesToStorage()`

```javascript
async function createNewFile() {
    const fileName = prompt('請輸入檔案名稱 (不需加.md):', '新檔案');
    if (fileName) {
        const newFile = {
            id: Date.now().toString(),
            name: fileName + '.md',
            content: '',
            lastModified: Date.now()
        };
        files.unshift(newFile);
        await saveFilesToStorage();
        renderFileList();
        loadFile(newFile.id);
    }
}
```

#### `loadFile(fileId)`
**Purpose**: Loads a file into the editor
**Parameters**: 
  - `fileId` (string): Unique file identifier
**Returns**: void
**Usage**: Called when selecting files from file list
**Related**: `saveCurrentFile()`, `updatePreview()`

```javascript
function loadFile(fileId) {
    const file = files.find(f => f.id === fileId);
    if (file) {
        saveCurrentFile(); // Save previous file
        currentFile = file;
        editor.setValue(file.content);
        updatePreview();
        // Handle large files with lazy loading
        if (file.content.length > 500000) {
            handleLargeFileLoading(fileId, file.content);
        }
    }
}
```

#### `saveCurrentFile()`
**Purpose**: Saves the current file content
**Parameters**: None
**Returns**: Promise
**Usage**: Called before switching files or on intervals
**Related**: `saveFilesToStorage()`

```javascript
async function saveCurrentFile() {
    if (currentFile && editor) {
        currentFile.content = editor.getValue();
        currentFile.lastModified = Date.now();
        await saveFilesToStorage();
    }
}
```

#### `deleteFile(fileId)`
**Purpose**: Deletes a file from the collection
**Parameters**:
  - `fileId` (string): File identifier to delete
**Returns**: Promise
**Usage**: Called from file context menu
**Related**: `renderFileList()`, `saveFilesToStorage()`

#### `togglePinFile(fileId)`
**Purpose**: Toggles file pin status
**Parameters**:
  - `fileId` (string): File identifier
**Returns**: Promise
**Usage**: Pin/unpin files for quick access
**Related**: `savePinnedFilesToConfig()`

### Editor Functions

#### `markdownHeaderFold(cm, start)`
**Purpose**: Custom folding function for markdown headers
**Parameters**:
  - `cm` (CodeMirror): CodeMirror instance
  - `start` (number): Starting line number
**Returns**: Object with range information
**Usage**: Called by CodeMirror folding system

#### `isFoldableHeader(lineText, cm, lineNum)`
**Purpose**: Determines if a line can be folded
**Parameters**:
  - `lineText` (string): Text content of line
  - `cm` (CodeMirror): Editor instance (optional)
  - `lineNum` (number): Line number (optional)
**Returns**: boolean
**Usage**: Used by folding system to identify foldable content

#### `foldAllContent()`
**Purpose**: Folds all foldable headers in the editor
**Parameters**: None
**Returns**: void
**Usage**: Called by fold all button
**Related**: `unfoldAllSections()`

#### `applyStructuralBold(cm)`
**Purpose**: Applies bold styling to structural elements
**Parameters**:
  - `cm` (CodeMirror): Editor instance
**Returns**: void
**Usage**: Visual enhancement for markdown structure

#### `hideMarkdownSyntax(cm)`
**Purpose**: Hides markdown syntax characters for cleaner view
**Parameters**:
  - `cm` (CodeMirror): Editor instance
**Returns**: void
**Usage**: Called after content changes to enhance readability

### Preview and Rendering Functions

#### `updatePreview()`
**Purpose**: Updates the markdown preview panel
**Parameters**: None
**Returns**: Promise
**Usage**: Called when editor content changes
**Dependencies**: marked.js, mermaid, KaTeX

```javascript
async function updatePreview() {
    if (!editor || !currentFile) return;
    
    const markdown = editor.getValue();
    const htmlContent = marked(markdown);
    
    const previewElement = document.getElementById('preview');
    previewElement.innerHTML = htmlContent;
    
    // Process special content
    await mermaid.run();
    enhanceCodeBlocks(previewElement);
    processLocalImages(previewElement);
}
```

#### `configureMarked()`
**Purpose**: Configures the marked markdown parser
**Parameters**: None
**Returns**: void
**Usage**: Called during initialization
**Dependencies**: marked.js, highlight.js

#### `enhanceCodeBlocks(container)`
**Purpose**: Adds copy buttons and language labels to code blocks
**Parameters**:
  - `container` (HTMLElement): Container element to process
**Returns**: void
**Usage**: Called after preview update

#### `generateToc()`
**Purpose**: Generates table of contents from markdown headers
**Parameters**: None
**Returns**: Array of heading objects
**Usage**: Called to populate TOC sidebar

### Timer and Task Management Functions

#### `startAutoTask(taskName)`
**Purpose**: Starts an automatic task timer
**Parameters**:
  - `taskName` (string): Name of the task
**Returns**: Promise
**Usage**: Called when auto-timer is triggered
**Related**: `stopCurrentTask()`, `addTaskToHistory()`

```javascript
async function startAutoTask(taskName) {
    if (isTimerRunning && currentTask) {
        await stopCurrentTask();
    }
    
    currentTask = {
        name: taskName,
        startTime: Date.now(),
        file: currentFile ? currentFile.name : null,
        section: getCurrentSection()
    };
    
    isTimerRunning = true;
    updateTimerUI();
}
```

#### `stopCurrentTask()`
**Purpose**: Stops the current running task
**Parameters**: None
**Returns**: Promise
**Usage**: Called when switching tasks or manually stopping
**Related**: `addTaskToHistory()`, `updateTimerUI()`

#### `addTaskToHistory(task)`
**Purpose**: Adds completed task to history
**Parameters**:
  - `task` (object): Task object with timing information
**Returns**: Promise
**Usage**: Called when tasks are completed
**Related**: `saveTimerHistory()`

#### `getCurrentSection()`
**Purpose**: Gets the current section based on cursor position
**Parameters**: None
**Returns**: string or null
**Usage**: Used for hierarchical task naming

#### `formatDuration(seconds)`
**Purpose**: Formats duration in seconds to HH:MM:SS
**Parameters**:
  - `seconds` (number): Duration in seconds
**Returns**: string
**Usage**: Display formatted time durations

#### `renderTimeline()`
**Purpose**: Renders task timeline visualization
**Parameters**: None
**Returns**: void
**Usage**: Called in timer modal to show task history

### Dual Editor System Functions

#### `toggleDualEditor()`
**Purpose**: Toggles dual editor mode on/off
**Parameters**: None
**Returns**: void
**Usage**: Called by dual editor button
**Related**: `initializeDualEditors()`, `setViewMode()`

#### `initializeDualEditors()`
**Purpose**: Initializes two CodeMirror instances for dual editing
**Parameters**: None
**Returns**: void
**Usage**: Called when entering dual editor mode
**Dependencies**: CodeMirror

#### `setActiveDualPane(paneIndex)`
**Purpose**: Sets which dual editor pane is active
**Parameters**:
  - `paneIndex` (number): Pane index (0 or 1)
**Returns**: void
**Usage**: Called when clicking on dual editor panes

#### `loadFileIntoDualPane(fileId)`
**Purpose**: Loads a file into the active dual editor pane
**Parameters**:
  - `fileId` (string): File identifier
**Returns**: void
**Usage**: Called when selecting files in dual editor mode

#### `updateDualPreview(paneIndex)`
**Purpose**: Updates preview for specific dual editor pane
**Parameters**:
  - `paneIndex` (number): Pane index
**Returns**: Promise
**Usage**: Called when dual editor content changes

#### `setDualLayout(layout)`
**Purpose**: Sets dual editor layout (horizontal/vertical)
**Parameters**:
  - `layout` (string): 'horizontal' or 'vertical'
**Returns**: void
**Usage**: Called by layout toggle button

### Search and Navigation Functions

#### `performSearch()`
**Purpose**: Performs search across files based on current scope
**Parameters**: None
**Returns**: void
**Usage**: Called when search is initiated
**Dependencies**: Search UI elements

```javascript
function performSearch() {
    const query = searchInput.value.trim();
    if (!query) return;
    
    clearAllSearchHighlights();
    allSearchResults = [];
    
    if (currentSearchScope === 'current') {
        // Search in current file only
        searchInCurrentFile(query);
    } else {
        // Search across all files
        searchAcrossAllFiles(query);
    }
    
    highlightAllSearchResults();
    updateSearchMatchCounter();
}
```

#### `jumpToSearchMatch(index)`
**Purpose**: Jumps to a specific search match
**Parameters**:
  - `index` (number): Match index
**Returns**: void
**Usage**: Navigate between search results

#### `toggleSearchScope()`
**Purpose**: Toggles between current file and all files search
**Parameters**: None
**Returns**: void
**Usage**: Called by search scope toggle button

#### `navigateToSection(sectionName)`
**Purpose**: Navigates to a specific section in the current file
**Parameters**:
  - `sectionName` (string): Section/header name
**Returns**: void
**Usage**: Called by TOC links and wiki links

#### `navigateToHashtag(hashtag)`
**Purpose**: Navigates to hashtag definition or usage
**Parameters**:
  - `hashtag` (string): Hashtag to navigate to
**Returns**: void
**Usage**: Called when clicking hashtag links

### Hashtag System Functions

#### `extractValidHashtags(content)`
**Purpose**: Extracts valid hashtags from content
**Parameters**:
  - `content` (string): Text content to analyze
**Returns**: Array of hashtags
**Usage**: Process content for hashtag references

#### `syncHashtagChanges(fileId, newContent)`
**Purpose**: Synchronizes hashtag changes across files
**Parameters**:
  - `fileId` (string): File identifier
  - `newContent` (string): New file content
**Returns**: void
**Usage**: Called when file content changes

#### `applyHashtagHighlighting()`
**Purpose**: Applies hashtag highlighting to the editor
**Parameters**: None
**Returns**: void
**Usage**: Visual enhancement for hashtag recognition

#### `initializeHashtagTracking()`
**Purpose**: Initializes hashtag tracking system
**Parameters**: None
**Returns**: void
**Usage**: Called during app initialization

### Cloud Sync and Sharing Functions

#### `handleSyncToCloud()`
**Purpose**: Synchronizes files to cloud storage (GitHub)
**Parameters**: None
**Returns**: Promise
**Usage**: Called by sync to cloud button
**Dependencies**: GitHub API

#### `handleLoadFromCloud()`
**Purpose**: Loads files from cloud storage
**Parameters**: None
**Returns**: Promise
**Usage**: Called by load from cloud button

#### `handlePublishShared()`
**Purpose**: Publishes shareable files to public Gist
**Parameters**: None
**Returns**: Promise
**Usage**: Creates public sharing links

#### `createBackup()`
**Purpose**: Creates a backup of all files and settings
**Parameters**: None
**Returns**: Promise
**Usage**: Called by backup button

### Storage Functions

#### `saveToIndexedDB(key, data)`
**Purpose**: Saves data to IndexedDB
**Parameters**:
  - `key` (string): Storage key
  - `data` (any): Data to store
**Returns**: Promise
**Usage**: Primary storage method

#### `loadFromIndexedDB(key)`
**Purpose**: Loads data from IndexedDB
**Parameters**:
  - `key` (string): Storage key
**Returns**: Promise with data or null
**Usage**: Primary data retrieval method

#### `saveFilesToStorage()`
**Purpose**: Saves all files to storage
**Parameters**: None
**Returns**: Promise
**Usage**: Called after file modifications

#### `loadDataFromStorage()`
**Purpose**: Loads all application data from storage
**Parameters**: None
**Returns**: Promise
**Usage**: Called during initialization

### UI and Modal Functions

#### `showNotification(message)`
**Purpose**: Displays a notification message to user
**Parameters**:
  - `message` (string): Message to display
**Returns**: void
**Usage**: User feedback for various actions

#### `openTimerModal()`
**Purpose**: Opens the timer management modal
**Parameters**: None
**Returns**: void
**Usage**: Called by timer button

#### `openDrawingModal()`
**Purpose**: Opens the drawing canvas modal
**Parameters**: None
**Returns**: void
**Usage**: Called by drawing button

#### `toggleSidebar()`
**Purpose**: Shows/hides the sidebar panel
**Parameters**: None
**Returns**: void
**Usage**: Called by sidebar toggle button

#### `updateViewModeUI()`
**Purpose**: Updates UI based on current view mode
**Parameters**: None
**Returns**: void
**Usage**: Called when view mode changes

### Presentation Functions

#### `togglePresentationMode()`
**Purpose**: Enters or exits presentation mode
**Parameters**: None
**Returns**: void
**Usage**: Called by presentation button

#### `createSlidesFromMarkdown(markdown)`
**Purpose**: Converts markdown to presentation slides
**Parameters**:
  - `markdown` (string): Markdown content
**Returns**: Array of slide elements
**Usage**: Called when entering presentation mode

#### `nextSlide()` / `prevSlide()`
**Purpose**: Navigate between presentation slides
**Parameters**: None
**Returns**: void
**Usage**: Keyboard navigation and button clicks

### Export Functions

#### `exportToMd()`
**Purpose**: Exports current file as markdown
**Parameters**: None
**Returns**: void
**Usage**: Called by export button

#### `exportToHtml()`
**Purpose**: Exports current file as HTML
**Parameters**: None
**Returns**: void
**Usage**: Called by export button

#### `exportToCsv()`
**Purpose**: Exports timer history as CSV
**Parameters**: None
**Returns**: void
**Usage**: Called by export timer data button

#### `exportWorkspace()`
**Purpose**: Exports entire workspace as JSON
**Parameters**: None
**Returns**: void
**Usage**: Called by export workspace button

### Utility Functions

#### `isMobileDevice()`
**Purpose**: Detects if running on mobile device
**Parameters**: None
**Returns**: boolean
**Usage**: Used for responsive behavior

#### `escapeRegExp(string)`
**Purpose**: Escapes special regex characters in string
**Parameters**:
  - `string` (string): String to escape
**Returns**: string
**Usage**: Used in search functionality

#### `downloadBlob(blob, filename)`
**Purpose**: Triggers download of blob data
**Parameters**:
  - `blob` (Blob): File data
  - `filename` (string): Download filename
**Returns**: void
**Usage**: Used by export functions

#### `generateUniqueId()`
**Purpose**: Generates unique identifier for files
**Parameters**: None
**Returns**: string
**Usage**: Used when creating new files

## CSS Classes and UI Components

### Layout Classes

#### `.container`
**Purpose**: Main application container
**Properties**: 
- `display: flex`
- `height: 100vh`
- `width: 100%`

#### `.file-panel`
**Purpose**: Sidebar panel for file management
**Properties**:
- `width: 300px`
- `flex-shrink: 0`
- `background: var(--secondary-bg)`
- `border-right: 1px solid var(--border-color)`

#### `.main-panel`
**Purpose**: Main editor and preview area
**Properties**:
- `flex: 1`
- `display: flex`
- `flex-direction: column`

#### `.editor-container`
**Purpose**: Container for CodeMirror editor
**Properties**:
- `flex: 1`
- `overflow: hidden`

#### `.preview-container`
**Purpose**: Container for markdown preview
**Properties**:
- `flex: 1`
- `overflow-y: auto`
- `padding: 20px`

### Component Classes

#### `.toolbar`
**Purpose**: Top toolbar with action buttons
**Properties**:
- `display: flex`
- `align-items: center`
- `padding: 8px 12px`
- `background: var(--header-bg)`
- `border-bottom: 1px solid var(--border-color)`

#### `.file-item`
**Purpose**: Individual file in file list
**Properties**:
- `padding: 8px 12px`
- `cursor: pointer`
- `border-left: 3px solid transparent`

#### `.file-item:hover`
**Properties**:
- `background: var(--primary-bg)`

#### `.file-item.active`
**Properties**:
- `background: var(--accent-color)`
- `color: white`
- `border-left-color: white`

#### `.file-item.pinned`
**Purpose**: Styling for pinned files
**Properties**:
- `background: #fff3cd`
- `border-left-color: #ffc107`

#### `.dual-editor-container`
**Purpose**: Container for dual editor layout
**Properties**:
- `display: flex`
- `height: 100%`

#### `.dual-pane`
**Purpose**: Individual pane in dual editor
**Properties**:
- `flex: 1`
- `display: flex`
- `flex-direction: column`

#### `.dual-pane.active`
**Purpose**: Active dual editor pane
**Properties**:
- `border: 2px solid var(--accent-color)`

### Modal Classes

#### `.modal`
**Purpose**: Base modal overlay
**Properties**:
- `position: fixed`
- `top: 0`
- `left: 0`
- `width: 100%`
- `height: 100%`
- `background: rgba(0, 0, 0, 0.5)`
- `z-index: 1000`

#### `.modal-content`
**Purpose**: Modal content container
**Properties**:
- `position: absolute`
- `top: 50%`
- `left: 50%`
- `transform: translate(-50%, -50%)`
- `background: var(--secondary-bg)`
- `border-radius: 8px`
- `padding: 20px`
- `max-width: 90vw`
- `max-height: 90vh`

### Button Classes

#### `.btn`
**Purpose**: Base button styling
**Properties**:
- `padding: 8px 16px`
- `border: none`
- `border-radius: 4px`
- `cursor: pointer`
- `background: var(--button-bg)`
- `color: white`

#### `.btn:hover`
**Properties**:
- `background: var(--button-hover-bg)`
- `transform: translateY(-1px)`

#### `.btn.active`
**Purpose**: Active button state
**Properties**:
- `background: var(--accent-color)`
- `box-shadow: 0 2px 4px rgba(0, 123, 255, 0.3)`

#### `.toolbar-btn`
**Purpose**: Toolbar button styling
**Properties**:
- `background: transparent`
- `border: 1px solid var(--border-color)`
- `padding: 6px 12px`

### Theme Classes

#### `.theme-default`
**Purpose**: Default theme variables
**Properties**:
- `--primary-bg: #f8f9fa`
- `--secondary-bg: #ffffff`
- `--text-color: #212529`
- `--accent-color: #007bff`

#### `.theme-dark`
**Purpose**: Dark theme variables
**Properties**:
- `--primary-bg: #1a1a1a`
- `--secondary-bg: #2d2d2d`
- `--text-color: #ffffff`
- `--accent-color: #4dabf7`

#### `.theme-monokai`
**Purpose**: Monokai theme for editor
**Properties**:
- Background: `#272822`
- Text: `#f8f8f2`
- Accent: `#a6e22e`

### Search and Highlighting Classes

#### `.search-highlight`
**Purpose**: Search result highlighting
**Properties**:
- `background: yellow`
- `border-radius: 2px`

#### `.search-highlight.current`
**Purpose**: Current search result
**Properties**:
- `background: orange`
- `box-shadow: 0 0 3px rgba(255, 165, 0, 0.8)`

#### `.hashtag-highlight`
**Purpose**: Hashtag highlighting in editor
**Properties**:
- `color: #007bff`
- `font-weight: bold`
- `cursor: pointer`

#### `.autocomplete-dropdown`
**Purpose**: Autocomplete suggestions dropdown
**Properties**:
- `position: absolute`
- `background: white`
- `border: 1px solid #ccc`
- `border-radius: 4px`
- `max-height: 200px`
- `overflow-y: auto`
- `z-index: 1000`

### Mobile Responsive Classes

#### `.mobile-only`
**Purpose**: Elements shown only on mobile
**Properties**:
- `display: none`

#### `@media (max-width: 768px) .mobile-only`
**Properties**:
- `display: block`

#### `.desktop-only`
**Purpose**: Elements hidden on mobile
**Properties**:
- `display: block`

#### `@media (max-width: 768px) .desktop-only`
**Properties**:
- `display: none`

#### `.mobile-overlay`
**Purpose**: Mobile overlay for sidebar
**Properties**:
- `position: fixed`
- `top: 0`
- `left: 0`
- `width: 100%`
- `height: 100%`
- `background: rgba(0, 0, 0, 0.5)`
- `z-index: 999`

## Data Flow and Storage

### Data Architecture
```
User Interface
    ↓
JavaScript Functions
    ↓
Application State (Variables)
    ↓
Storage Layer (IndexedDB/LocalStorage)
    ↓
Cloud Sync (Optional)
```

### Storage Strategy
1. **Primary**: IndexedDB for large data (files, tasks, history)
2. **Fallback**: LocalStorage for compatibility
3. **Sync**: GitHub Gist for cloud backup
4. **Configuration**: NoteConfig.md file for settings

### File Storage Format
```json
{
  "files": [
    {
      "id": "timestamp-string",
      "name": "filename.md",
      "content": "markdown content",
      "lastModified": 1234567890,
      "size": 1024,
      "pinned": false
    }
  ],
  "settings": {
    "theme": "default",
    "fontSize": 22,
    "autoTimer": true,
    "syncScroll": true
  }
}
```

### Task History Format
```json
{
  "tasks": [
    {
      "name": "Task Name",
      "startTime": 1234567890,
      "endTime": 1234567950,
      "duration": 60,
      "file": "filename.md",
      "section": "## Section Name",
      "hierarchy": ["Main Section", "Sub Section"]
    }
  ]
}
```

## Development Patterns

### Function Naming Conventions
- **Handlers**: `handle*` (e.g., `handleFileSelection`)
- **Toggles**: `toggle*` (e.g., `toggleSidebar`)
- **Updates**: `update*` (e.g., `updatePreview`)
- **Initialization**: `init*` (e.g., `initEditor`)
- **Navigation**: `navigateTo*` (e.g., `navigateToSection`)
- **Async Operations**: `async function` prefix

### Error Handling Pattern
```javascript
async function someAsyncFunction() {
    try {
        // Operation
        const result = await someAsyncOperation();
        return result;
    } catch (error) {
        console.error('Error in someAsyncFunction:', error);
        showNotification(`Error: ${error.message}`);
        return null;
    }
}
```

### Event Listener Pattern
```javascript
function attachEventListeners() {
    function safeAddEventListener(elementId, event, handler) {
        const element = document.getElementById(elementId);
        if (element) {
            element.addEventListener(event, handler);
        }
    }
    
    safeAddEventListener('button-id', 'click', handlerFunction);
}
```

### Performance Optimization Patterns
```javascript
// Throttling for frequent operations
let updateTimer;
editor.on('change', function() {
    clearTimeout(updateTimer);
    updateTimer = setTimeout(updatePreview, 300);
});

// Lazy loading for large content
function handleLargeFile(content) {
    if (content.length > 500000) {
        // Load in chunks
        loadFileChunks(content);
    } else {
        // Load normally
        loadFileNormally(content);
    }
}
```

### Mobile Detection Pattern
```javascript
function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// Conditional behavior
if (isMobileDevice()) {
    // Mobile-specific behavior
    disableAutofocus();
    enableTouchOptimizations();
}
```

### Modal Management Pattern
```javascript
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}
```

### Configuration Management
```javascript
// Save configuration to special file
async function saveConfiguration() {
    const config = {
        currentFile: currentFile?.id,
        viewMode: viewMode,
        fontSize: currentFontSize,
        theme: currentEditorTheme,
        // ... other settings
    };
    
    const configContent = JSON.stringify(config, null, 2);
    const configFile = {
        id: 'noteconfig',
        name: 'NoteConfig.md',
        content: `# PowerNote Configuration\n\`\`\`json\n${configContent}\n\`\`\``,
        lastModified: Date.now()
    };
    
    // Save to files array and storage
    await saveConfiguration(configFile);
}
```

This comprehensive documentation provides a complete reference for developing and maintaining PowerNote Pro. The application demonstrates modern web development practices with vanilla JavaScript, efficient data management, and responsive design principles.