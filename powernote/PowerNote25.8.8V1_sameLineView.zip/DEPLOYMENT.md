# PowerNote GitHub Pages 部署指南

## 📁 建議的資料夾結構

```
your-powernote-repo/
├── index.html                 # PowerNote 主程式
├── shared.html               # 分享頁面閱讀器 (重要!)
├── lib/                       # 所有依賴庫
│   ├── codemirror/
│   ├── marked/
│   ├── highlight.js/
│   └── ...
├── assets/                    # 靜態資源 (可選)
│   ├── images/
│   └── css/
└── README.md                  # 專案說明
```

## 🚀 部署步驟

### 1. 創建 GitHub 倉庫
```bash
# 在 GitHub 上創建新倉庫：your-username/powernote
git init
git add .
git commit -m "Initial PowerNote setup"
git branch -M main
git remote add origin https://github.com/your-username/powernote.git
git push -u origin main
```

### 2. 啟用 GitHub Pages
1. 前往 GitHub 倉庫設定
2. 滾動到 "Pages" 部分
3. Source 選擇 "Deploy from a branch"
4. Branch 選擇 "main"
5. 資料夾選擇 "/ (root)"
6. 點擊 "Save"

### 3. 訪問你的 PowerNote
- 主應用：`https://your-username.github.io/powernote/`
- 分享閱讀器：`https://your-username.github.io/powernote/shared.html`

## 📝 使用分享功能 (全自動!)

### 方法 1：快速分享單篇文章 ⚡
1. 在編輯器中打開要分享的文章
2. 點擊右上角的 📤 **分享按鈕**
3. 如果文章沒有 `#SHARE` 標籤，系統會詢問是否添加
4. 自動創建公開 Gist 並複製分享連結到剪貼簿
5. 直接發送連結給朋友！

### 方法 2：批量分享多篇文章 🚀
1. 在想分享的文章中添加 `#SHARE` 標籤：
   ```markdown
   #SHARE
   # 我的精彩文章
   
   這是我想分享給朋友們的內容...
   ```

2. 點擊 🌐 **發布分享頁面** 按鈕
3. 系統會：
   - 自動掃描所有含 `#SHARE` 標籤的文章
   - 創建公開 Gist
   - 生成每篇文章的專屬分享連結
   - 顯示美觀的分享連結列表

4. 複製任意連結分享給朋友

### 分享連結格式
```
https://your-username.github.io/powernote/shared.html?gist=GIST_ID&file=filename.md
```

## ✨ 分享功能特色

### 🔄 完全自動化
- ❌ 不需要手動上傳檔案
- ❌ 不需要管理HTML檔案
- ✅ 一鍵創建分享連結
- ✅ 自動同步最新內容

### 🎨 精美閱讀體驗
- 📱 響應式設計，支援手機閱讀
- ✨ 專業的文章排版
- 🎯 SEO 優化，搜索引擎友好
- 🏷️ 自動隱藏 `#SHARE` 標籤

### 🔒 隱私控制完善
- **私人筆記** `#UNSYNC`：不會同步到任何地方
- **一般筆記**：同步到私人 Gist（朋友看不到）
- **分享文章** `#SHARE`：創建公開 Gist 分享連結

## 🔧 技術原理

1. **分享時**：PowerNote 創建公開 Gist 存放文章
2. **閱讀時**：`shared.html` 從 GitHub API 讀取 Gist 內容
3. **渲染時**：使用 marked.js 將 Markdown 轉為 HTML
4. **顯示時**：應用精美樣式，移除 `#SHARE` 標籤

## 🌟 使用建議

### 最佳實踐
1. **標題優化**：每篇分享文章都以 `# 標題` 開始
2. **內容組織**：使用標題層級 (`##`, `###`) 組織內容
3. **圖片使用**：支援 Markdown 圖片語法
4. **定期整理**：定期檢查公開 Gist，刪除不需要的分享

### 進階技巧
1. **批量管理**：使用 🌐 按鈕一次分享多篇文章
2. **連結收藏**：將分享連結保存到書籤或筆記中
3. **社交分享**：分享連結會自動顯示文章標題和描述

## 📱 行動裝置完美支援

朋友在手機上點擊分享連結時會看到：
- 🎯 針對手機優化的閱讀界面
- 📖 舒適的字體大小和行距
- 🎨 深色/淺色主題自動適應
- ⚡ 快速載入，無需安裝APP

現在就開始分享你的精彩內容吧！ 🚀