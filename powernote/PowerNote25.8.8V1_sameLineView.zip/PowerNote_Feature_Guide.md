# PowerNote 功能開發與使用指南

## 📋 目錄
- [新增功能概覽](#新增功能概覽)
- [同步功能詳解](#同步功能詳解)
- [分享系統架構](#分享系統架構)
- [WebDAV 整合](#webdav-整合)
- [程式邏輯流程圖](#程式邏輯流程圖)
- [開發者指南](#開發者指南)
- [使用者手冊](#使用者手冊)

---

## 🆕 新增功能概覽

### 1. 智能同步系統
- **`#UNSYNC` 標籤**：排除同步，保護隱私
- **視覺化標識**：含 `#UNSYNC` 標籤的檔案在側邊欄顯示橘色外框
- **系統檔案保護**：自動識別並同步配置檔案
- **選擇性同步**：用戶完全控制哪些內容要同步
- **即時反饋**：添加/移除標籤時外框顏色即時更新

### 4. 智能連結管理
- **自動連結更新**：重新命名檔案時自動更新所有相關連結
- **Wiki 連結支援**：支援 `[[檔案名]]` 和 `[[檔案名#段落]]` 格式
- **標籤系統整合**：自動更新 NoteTag.md 中的檔案連結
- **即時通知**：顯示已更新多少個檔案的連結

### 2. 公開分享系統
- **`#SHARE` 標籤**：標記可分享文章
- **動態分享頁面**：`shared.html` 即時讀取 Gist 內容
- **一鍵分享**：自動創建公開 Gist 並生成分享連結
- **批量分享**：支援多篇文章同時分享

### 3. 雙端同步支援
- **GitHub Gist**：主要同步方案，支援版本控制
- **WebDAV**：企業級同步，支援私有伺服器
- **混合使用**：可同時配置多種同步方式

---

## 🔄 同步功能詳解

### 標籤系統邏輯

```markdown
文章標籤分類：
├── 無標籤        → 正常同步到私人 Gist
├── #UNSYNC      → 完全不同步，本地保存
├── #SHARE       → 同步 + 可創建公開分享
└── 系統檔案      → 強制同步（NoteTag.md、NoteConfig.md、NoteTask.md）
```

### 同步規則優先級

1. **最高優先級**：系統檔案（`NoteTag.md`、`NoteConfig.md`、`NoteTask.md`）
2. **排除規則**：含 `#UNSYNC` 標籤的檔案
3. **一般同步**：其他所有檔案

### 系統檔案詳細說明

| 檔案名稱 | 功能 | 內容格式 | 同步重要性 |
|----------|------|----------|------------|
| **NoteTag.md** | 標籤管理系統 | Markdown 格式的標籤定義 | ⭐⭐⭐ 極高 |
| **NoteConfig.md** | 應用程式配置 | JSON 格式的設定參數 | ⭐⭐⭐ 極高 |
| **NoteTask.md** | 任務計時記錄 | Markdown 格式的時間追蹤 | ⭐⭐⭐ 極高 |

#### NoteTag.md - 標籤管理
- **用途**：管理所有筆記的分類標籤
- **格式**：使用 `### 標籤名稱` 定義標籤
- **功能**：支援標籤自動完成、導航跳轉
- **同步原因**：確保標籤系統在各設備間一致

#### NoteConfig.md - 系統配置
- **用途**：儲存應用程式的所有設定
- **內容**：字體大小、主題、側邊欄狀態、檔案排序等
- **格式**：JSON 嵌入在 Markdown 中
- **同步原因**：保持使用體驗在各設備間一致

#### NoteTask.md - 任務記錄
- **用途**：記錄所有任務的計時資料
- **格式**：按日期組織的任務列表
- **功能**：自動計時、任務統計、歷史追蹤
- **同步原因**：重要的工作記錄不能遺失

### 支援的同步方式

| 方式 | 優點 | 缺點 | 適用場景 |
|------|------|------|----------|
| **GitHub Gist** | 免費、版本控制、API豐富 | 需要網路、有容量限制 | 個人使用、開發者 |
| **WebDAV** | 私有部署、無限容量、企業級 | 需要伺服器、配置複雜 | 企業、團隊協作 |

---

## 📤 分享系統架構

### 分享模式對比

| 模式 | 隱私等級 | 外框顏色 | 訪問方式 | 適用情境 |
|------|----------|----------|----------|----------|
| **私人筆記** `#UNSYNC` | 🔒 最高 | 🟠 橘色 | 僅本地保存 | 個人日記、敏感資訊 |
| **系統檔案** | 🔧 系統 | 🔵 藍色 | 私人 Gist，強制同步 | NoteTag.md、NoteConfig.md、NoteTask.md |
| **一般同步** | 🔐 中等 | ⚪ 白色 | 私人 Gist，需認證 | 工作筆記、備份 |
| **公開分享** `#SHARE` | 🌐 公開 | ⚪ 白色 | 任何人可訪問 | 技術文章、教學內容 |

### 分享連結結構

```
https://username.github.io/powernote/shared.html?gist=GIST_ID&file=filename.md
│                                    │               │          │
│                                    │               │          └─ 檔案名稱
│                                    │               └─ 公開 Gist ID
│                                    └─ 分享頁面閱讀器
└─ GitHub Pages 網域
```

---

## 🌐 WebDAV 整合

### 支援的 WebDAV 伺服器

- **Nextcloud**：開源雲端平台
- **ownCloud**：私有雲解決方案
- **Apache HTTP Server**：使用 mod_dav 模組
- **Nginx**：使用 nginx-dav-ext-module
- **Synology NAS**：群暉 NAS WebDAV
- **QNAP NAS**：威聯通 NAS WebDAV

### WebDAV 配置參數

```javascript
webdav: {
    url: 'https://your-server.com/webdav/',     // WebDAV 伺服器地址
    username: 'your-username',                  // 使用者名稱
    password: 'your-password',                  // 密碼或應用專用密碼
    path: '/PowerNote/',                        // 儲存路徑
    autoSync: false                             // 自動同步開關
}
```

---

## 📊 程式邏輯流程圖

### 1. 同步系統主流程

```mermaid
graph TD
    A[使用者點擊同步] --> B[檢查 GitHub Token]
    B -->|未設定| C[顯示設定頁面]
    B -->|已設定| D[掃描所有檔案]
    
    D --> E[應用過濾規則]
    E --> F{檔案類型判斷}
    
    F -->|系統檔案| G[強制包含]
    F -->|含 #UNSYNC| H[排除同步]
    F -->|一般檔案| I[包含同步]
    
    G --> J[組建工作區資料]
    I --> J
    J --> K[呼叫 GitHub API]
    K --> L{API 回應}
    
    L -->|成功| M[顯示成功訊息]
    L -->|失敗| N[顯示錯誤訊息]
    
    M --> O[更新最後同步時間]
    N --> P[記錄錯誤日誌]
```

### 2. 檔案過濾邏輯

```mermaid
graph TD
    A[檔案] --> B{是否為系統檔案?}
    B -->|是| C{檔案名稱檢查}
    C -->|NoteTag.md| D[✅ 強制同步 - 標籤管理]
    C -->|NoteConfig.md| E[✅ 強制同步 - 配置設定]
    C -->|NoteTask.md| F[✅ 強制同步 - 任務記錄]
    
    B -->|否| G{含有 #UNSYNC?}
    G -->|是| H[❌ 排除同步]
    G -->|否| I[✅ 正常同步]
    
    D --> J[加入同步清單]
    E --> J
    F --> J
    I --> J
    H --> K[跳過此檔案]
```

### 3. 分享系統流程

```mermaid
graph TD
    A[使用者觸發分享] --> B{分享方式}
    
    B -->|單檔分享| C[檢查當前檔案]
    B -->|批量分享| D[掃描 #SHARE 標籤]
    
    C --> E{含有 #SHARE?}
    E -->|否| F[詢問是否添加標籤]
    F -->|是| G[添加 #SHARE 到檔案開頭]
    F -->|否| H[取消分享]
    E -->|是| I[準備分享資料]
    G --> I
    
    D --> J[收集所有 #SHARE 檔案]
    J --> K{找到檔案?}
    K -->|否| L[顯示無檔案錯誤]
    K -->|是| I
    
    I --> M[建立 Gist 資料結構]
    M --> N[呼叫 GitHub API 建立公開 Gist]
    N --> O{API 成功?}
    
    O -->|否| P[顯示錯誤訊息]
    O -->|是| Q[生成分享連結]
    Q --> R[複製到剪貼簿]
    R --> S[顯示成功訊息]
```

### 4. shared.html 載入流程

```mermaid
graph TD
    A[使用者點擊分享連結] --> B[載入 shared.html]
    B --> C[解析 URL 參數]
    C --> D{參數完整?}
    
    D -->|否| E[顯示參數錯誤]
    D -->|是| F[呼叫 GitHub API]
    
    F --> G[請求 Gist 內容]
    G --> H{API 回應}
    
    H -->|404| I[顯示 Gist 不存在]
    H -->|其他錯誤| J[顯示 API 錯誤]
    H -->|成功| K[解析 Gist 資料]
    
    K --> L{檔案存在?}
    L -->|否| M[顯示檔案不存在]
    L -->|是| N[取得檔案內容]
    
    N --> O[移除 #SHARE 標籤]
    O --> P[提取文章標題]
    P --> Q[使用 marked.js 渲染 Markdown]
    Q --> R[更新頁面標題和 meta]
    R --> S[顯示渲染後內容]
    S --> T[隱藏載入畫面]
```

### 5. WebDAV 同步流程

```mermaid
graph TD
    A[使用者選擇 WebDAV 同步] --> B[檢查 WebDAV 配置]
    B -->|未配置| C[顯示 WebDAV 設定]
    B -->|已配置| D[測試 WebDAV 連線]
    
    D --> E{連線成功?}
    E -->|否| F[顯示連線錯誤]
    E -->|是| G[準備同步資料]
    
    G --> H[過濾檔案（同 GitHub 邏輯）]
    H --> I[建立工作區 JSON]
    I --> J[透過 WebDAV PUT 上傳]
    
    J --> K{上傳成功?}
    K -->|否| L[顯示上傳錯誤]
    K -->|是| M[更新最後同步時間]
    M --> N[顯示成功訊息]
    
    F --> O[記錄錯誤日誌]
    L --> O
```

### 6. 同步統計資訊流程

```mermaid
graph TD
    A[開始同步] --> B[掃描所有檔案]
    B --> C[分類檔案]
    
    C --> D[系統檔案計數]
    C --> E[#UNSYNC 檔案計數]
    C --> F[一般檔案計數]
    C --> G[#SHARE 檔案計數]
    
    D --> H{NoteTag.md 存在?}
    H -->|是| I[✅ 標籤管理]
    H -->|否| J[⚠️ 缺少標籤管理]
    
    D --> K{NoteConfig.md 存在?}
    K -->|是| L[✅ 配置設定]
    K -->|否| M[⚠️ 缺少配置]
    
    D --> N{NoteTask.md 存在?}
    N -->|是| O[✅ 任務記錄]
    N -->|否| P[⚠️ 缺少任務記錄]
    
    I --> Q[組建同步統計]
    L --> Q
    O --> Q
    F --> Q
    
    Q --> R[顯示詳細統計訊息]
    R --> S[執行同步操作]
    
    E --> T[記錄跳過原因]
    J --> U[建議建立缺少檔案]
    M --> U
    P --> U
```

### 7. 檔案外框顏色邏輯

```mermaid
graph TD
    A[檔案] --> B{是否為系統檔案?}
    B -->|是| C[🔵 藍色外框]
    C --> D[NoteTag.md/NoteConfig.md/NoteTask.md]
    
    B -->|否| E{含有 #UNSYNC 標籤?}
    E -->|是| F[🟠 橘色外框]
    F --> G[私人筆記，不同步]
    
    E -->|否| H[⚪ 白色外框]
    H --> I{含有 #SHARE 標籤?}
    I -->|是| J[一般同步 + 可分享]
    I -->|否| K[一般同步]
    
    style C fill:#e3f2fd
    style F fill:#fff3cd
    style H fill:#f8f9fa
```

### 8. 即時外框更新流程

```mermaid
graph TD
    A[編輯器內容變化] --> B[儲存檔案內容]
    B --> C{#UNSYNC 狀態改變?}
    
    C -->|添加 #UNSYNC| D[從白色變為橘色]
    C -->|移除 #UNSYNC| E[從橘色變為白色]
    C -->|狀態未變| F[保持原有外框]
    
    D --> G[重新渲染檔案列表]
    E --> G
    F --> H[不重新渲染]
    
    G --> I[使用者看到即時外框變化]
    
    style D fill:#fff3cd
    style E fill:#f8f9fa
```

### 9. 智能連結更新流程

```mermaid
graph TD
    A[用戶重新命名檔案] --> B[檔案：舊名稱.md → 新名稱.md]
    B --> C[掃描所有檔案]
    
    C --> D{檢查檔案內容}
    D --> E[搜尋 Wiki 連結模式]
    
    E --> F{找到 [[舊名稱]]}
    F -->|是| G[替換為 [[新名稱]]]
    F -->|否| H{找到 [[舊名稱#段落]]}
    
    H -->|是| I[替換為 [[新名稱#段落]]]
    H -->|否| J[檢查下一個檔案]
    
    G --> K[標記檔案已修改]
    I --> K
    K --> L[更新檔案時間戳]
    L --> J
    
    J --> M{還有檔案?}
    M -->|是| D
    M -->|否| N[特別處理 NoteTag.md]
    
    N --> O{NoteTag.md 存在?}
    O -->|是| P[更新標籤檔案中的連結]
    O -->|否| Q[統計更新結果]
    
    P --> Q
    Q --> R[顯示通知訊息]
    R --> S[如果當前檔案被更新，刷新編輯器]
    
    style G fill:#e8f5e8
    style I fill:#e8f5e8
    style K fill:#fff3cd
    style R fill:#d4edda
```

### 10. 連結類型支援

```mermaid
graph LR
    A[Wiki 連結格式] --> B[簡單連結]
    A --> C[段落連結]
    A --> D[標籤連結]
    
    B --> E["[[檔案名]]"]
    C --> F["[[檔案名#段落名]]"]
    D --> G["NoteTag.md 中的檔案連結"]
    
    E --> H[重新命名時自動更新]
    F --> H
    G --> H
    
    H --> I[保持連結完整性]
    
    style E fill:#e3f2fd
    style F fill:#e8f5e8
    style G fill:#fff3cd
    style I fill:#d4edda
```

### 11. 雙向同步衝突處理

```mermaid
graph TD
    A[檢測到同步衝突] --> B{本地修改時間 vs 遠端時間}
    
    B -->|本地較新| C[上傳本地版本]
    B -->|遠端較新| D[詢問使用者選擇]
    B -->|時間相同| E[比較內容雜湊]
    
    D --> F{使用者選擇}
    F -->|保留本地| C
    F -->|使用遠端| G[下載遠端版本]
    F -->|手動合併| H[顯示差異比較]
    
    E -->|內容相同| I[跳過同步]
    E -->|內容不同| D
    
    C --> J[更新遠端]
    G --> K[更新本地]
    H --> L[等待使用者合併]
    
    J --> M[同步完成]
    K --> M
    L --> M
    I --> M
```

---

## 👨‍💻 開發者指南

### 核心類別架構

```javascript
class CloudSyncManager {
    // 檔案過濾方法
    hasUnsyncTag(file)        // 檢查 #UNSYNC 標籤
    hasShareTag(file)         // 檢查 #SHARE 標籤
    isSystemFile(file)        // 檢查系統檔案 (NoteTag.md, NoteConfig.md, NoteTask.md)
    
    // 同步方法
    syncToGist()              // 同步到 GitHub Gist
    loadFromGist()            // 從 Gist 載入
    exportSyncFilteredWorkspace()  // 導出過濾後的工作區
    
    // 分享方法
    createPublicShareGist()   // 建立公開分享 Gist
    generateShareLinks()      // 生成分享連結
    extractTitle()            // 提取文章標題
    
    // WebDAV 方法
    syncToWebDAV()           // 同步到 WebDAV
    loadFromWebDAV()         // 從 WebDAV 載入
    testWebDAVConnection()   // 測試 WebDAV 連線
}

// 全域檔案管理函數
updateWikiLinksAfterRename(oldName, newName)  // 重新命名時更新連結
escapeRegExp(string)                          // 正則表達式轉義
saveCurrentFile()                             // 儲存當前檔案並更新狀態
```

### 重要配置物件

```javascript
// 同步設定結構
syncSettings = {
    provider: 'github',  // 'github' 或 'webdav'
    github: {
        token: '',       // GitHub Personal Access Token
        gistId: '',      // 私人 Gist ID
        autoSync: false  // 自動同步開關
    },
    webdav: {
        url: '',         // WebDAV 伺服器 URL
        username: '',    // 使用者名稱
        password: '',    // 密碼
        path: '/PowerNote/', // 儲存路徑
        autoSync: false  // 自動同步開關
    }
}
```

### API 端點整理

```javascript
// GitHub API
const GITHUB_API = 'https://api.github.com';
const endpoints = {
    user: `${GITHUB_API}/user`,                    // 使用者資訊
    gists: `${GITHUB_API}/gists`,                  // 建立 Gist
    gist: `${GITHUB_API}/gists/{gist_id}`,         // 特定 Gist
    gistHistory: `${GITHUB_API}/gists/{gist_id}/commits`  // Gist 歷史
};

// WebDAV 操作
const webdavOperations = {
    PUT: '上傳檔案',
    GET: '下載檔案', 
    PROPFIND: '列出檔案',
    DELETE: '刪除檔案',
    MKCOL: '建立資料夾'
};
```

### 錯誤處理機制

```javascript
// 標準錯誤處理模式
try {
    await syncOperation();
    showNotification('操作成功', 'success');
} catch (error) {
    console.error('操作失敗:', error);
    showNotification(`操作失敗: ${error.message}`, 'error');
    
    // 特定錯誤處理
    if (error.status === 401) {
        // 認證失敗，導向設定頁面
        openSyncSettings();
    } else if (error.status === 404) {
        // 資源不存在
        showNotification('找不到指定資源', 'error');
    }
}
```

---

## 📖 使用者手冊

### 快速開始指南

#### 1. 設定同步
1. 點擊 ⚙️ **同步設定** 按鈕
2. 選擇同步方式（GitHub Gist 或 WebDAV）
3. 填入必要的認證資訊
4. 點擊 **測試連接** 確認設定正確
5. 儲存設定

#### 2. 使用同步功能
- **同步到雲端**：☁️ 點擊同步按鈕上傳資料
- **從雲端載入**：📥 點擊載入按鈕下載資料
- **查看歷史版本**：📜 在載入介面查看版本記錄

#### 3. 分享文章
**方法一：快速分享**
1. 開啟要分享的文章
2. 點擊右上角 📤 **分享按鈕**
3. 確認添加 `#SHARE` 標籤
4. 分享連結自動複製到剪貼簿

**方法二：批量分享**
1. 在文章中手動添加 `#SHARE` 標籤
2. 點擊 🌐 **發布分享頁面** 按鈕
3. 從清單中複製所需的分享連結

### 標籤使用指南

| 標籤 | 用途 | 範例 | 同步行為 |
|------|------|------|----------|
| `#SHARE` | 標記可分享文章 | `#SHARE` `# 技術教學文章` | 同步 + 可公開分享 |
| `#UNSYNC` | 排除同步，完全本地 | `#UNSYNC` `# 私人日記` | 不同步，僅本地保存 |
| 無標籤 | 正常同步到私人 Gist | `# 工作筆記` | 同步到私人 Gist |
| 系統檔案 | 自動管理，無需手動標記 | `NoteTag.md` `NoteConfig.md` `NoteTask.md` | 強制同步，最高優先級 |

### 系統檔案說明

**重要提醒**：以下系統檔案會自動建立和管理，使用者無需手動操作：

- **NoteTag.md**：當你建立新標籤時自動更新
- **NoteConfig.md**：當你修改設定時自動儲存
- **NoteTask.md**：當你使用計時功能時自動記錄

這些檔案即使不加任何標籤也會優先同步，確保你的應用程式狀態在各設備間保持一致。

### 視覺化識別系統

PowerNote 使用顏色外框來幫助你快速識別檔案狀態：

| 外框顏色 | 含義 | 說明 |
|----------|------|------|
| 🟠 **橘色** | 私人檔案 | 含有 `#UNSYNC` 標籤，不會同步 |
| 🔵 **藍色** | 系統檔案 | 重要配置檔案，優先同步 |
| ⚪ **白色** | 一般檔案 | 正常同步到私人 Gist |

**即時更新**：當你在文章中添加或移除 `#UNSYNC` 標籤時，側邊欄的外框顏色會立即改變，無需重新載入。

### Wiki 連結與檔案管理

PowerNote 支援智能的 Wiki 連結系統，讓你可以輕鬆在筆記間建立連結：

#### 支援的連結格式

| 格式 | 用途 | 範例 |
|------|------|------|
| `[[檔案名]]` | 連結到其他筆記 | `[[會議記錄]]` |
| `[[檔案名#段落]]` | 連結到特定段落 | `[[專案計畫#時程安排]]` |

#### 自動連結更新

**重新命名檔案時**：
- ✅ 自動掃描所有檔案中的相關連結
- ✅ 更新簡單連結 `[[舊名稱]]` → `[[新名稱]]`
- ✅ 更新段落連結 `[[舊名稱#段落]]` → `[[新名稱#段落]]`
- ✅ 更新 NoteTag.md 中的標籤連結
- ✅ 即時通知更新了多少個檔案

**使用建議**：
1. **規劃檔案結構**：建立連結前先規劃好檔案命名
2. **使用有意義的名稱**：便於搜尋和自動補全
3. **定期整理**：利用重新命名功能整理檔案結構
4. **檢查連結**：重新命名後檢查重要連結是否正確更新

### 常見問題排除

#### Q1: 同步失敗怎麼辦？
1. 檢查網路連線
2. 確認 GitHub Token 是否正確
3. 檢查 Token 權限是否包含 Gist 操作
4. 查看瀏覽器開發者工具的錯誤訊息

#### Q2: 分享連結無法開啟？
1. 確認 GitHub Pages 已正確部署
2. 檢查 `shared.html` 檔案是否存在
3. 確認 Gist 是否為公開狀態
4. 檢查檔案名稱是否正確

#### Q3: WebDAV 同步失敗？
1. 確認 WebDAV 伺服器地址正確
2. 檢查使用者名稱和密碼
3. 確認伺服器支援 WebDAV 協定
4. 檢查網路防火牆設定

#### Q4: 重新命名後連結沒有更新？
1. 確認使用的是 Wiki 連結格式 `[[檔案名]]`
2. 檢查檔案名稱是否包含特殊字符
3. 查看瀏覽器控制台是否有錯誤訊息
4. 手動檢查並修復未更新的連結

### 效能優化建議

1. **定期清理**：刪除不需要的舊版本 Gist
2. **檔案大小**：單一檔案建議不超過 1MB
3. **同步頻率**：避免過於頻繁的同步操作
4. **標籤管理**：合理使用 `#UNSYNC` 減少同步量

---

## 📈 未來發展規劃

### 短期目標（下個版本）
- [ ] 增加同步衝突自動合併
- [ ] 支援離線模式編輯
- [ ] 添加分享文章預覽功能
- [ ] 優化 WebDAV 連線穩定性

### 中期目標（未來 3-6 個月）
- [ ] 支援更多同步服務（Dropbox、OneDrive）
- [ ] 增加團隊協作功能
- [ ] 文章評論和互動系統
- [ ] 進階搜尋和標籤系統

### 長期願景（未來一年）
- [ ] 行動 APP 開發
- [ ] AI 輔助寫作功能
- [ ] 多語言支援
- [ ] 企業版功能開發

---

## 🛠️ 技術規格

### 系統需求
- **瀏覽器**：Chrome 90+, Firefox 88+, Safari 14+, Edge 90+
- **網路**：需要穩定的網際網路連線
- **儲存**：本地 IndexedDB 支援

### 依賴套件
- **CodeMirror 5.x**：程式碼編輯器
- **Marked.js 4.x**：Markdown 解析器
- **Highlight.js 11.x**：語法高亮
- **Mermaid.js 10.x**：流程圖渲染
- **Font Awesome 6.x**：圖示字體

### 支援格式
- **輸入**：Markdown (.md), 純文字 (.txt)
- **輸出**：HTML, PDF, JSON
- **同步**：JSON 工作區格式
- **分享**：動態 HTML 渲染

---

*最後更新：2024年1月 | 版本：PowerNote Pro 2.5*